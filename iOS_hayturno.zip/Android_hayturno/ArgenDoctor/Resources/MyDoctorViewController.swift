//
//  MyDoctorViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/26/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

class MyDoctorViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    let GlobalVar = Global()
    
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var AddViewTemp: UIView!
    
    @IBOutlet weak var viewNoFind: UIView!
    
    @IBOutlet weak var GradientView: UIView!
    @IBOutlet weak var view_CheckButton: UIView!
    @IBOutlet weak var view_small: UIView!
    
    @IBOutlet weak var backgroundImageView: UIImageView!
    
    
    
    
    var cellFlag: Int = -1
    //Set Table Refresh Control
    var refreshControl = UIRefreshControl()
    
    
    var Schedule_DateArray = Array<String>()
    var Schedule_TimeArray = Array<String>()
    var Schedule_IdArray = Array<Int>()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        view_CheckButton.isHidden = true
        
        
        //Set Delegate Table View
        tableView.tableHeaderView = UIView()
        tableView.delegate = self
        tableView.dataSource = self
        
        
        //Set Table Refresh Control
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.handleRefresh(sender:)), for: UIControlEvents.valueChanged)
        self.tableView.addSubview(refreshControl)
        
        
        //========================================
        handleRefresh(sender: self)
        //========================================
        
        LoadNearestSchedules()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func handleRefresh(sender:AnyObject) {
        
//        g_myDoctor_Array.removeAll()
        //g_myDoctor_SelIndex_Int  = -1
        tableView.reloadData()
        
        //DownLoadPotential()
        //Test Code --------------------------------------
//        g_myDoctor_Array.append(contentsOf: ["Juan Carlos Ordonez", "Eric de Titta", "Roberto Gomez", "Cancelar turno", "Julieta Brandoni"])
        //--------------------------------------
        
        refreshControl.endRefreshing()
        tableView.reloadData()
    }

    
    func formattedDateFromString(dateString: String, withFormat format: String) -> String? {
        
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "dd-MM-yyyy"
        
        if let date = inputFormatter.date(from: dateString) {
            
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = format
            
            return outputFormatter.string(from: date)
        }
        
        return nil
    }
    
    //=========================================================================================
    //
    //  Table Delegates
    //
    //=========================================================================================
    
    func initView() {
        tableView.reloadData()
    }
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return g_favarite_Doctors_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == cellFlag {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "MyDoctorTableCell_2_large") as? MyDoctorTableCell_2_large
            
            cell?.largeCellView.layer.cornerRadius = 6.5
            cell?.TxtLabel.text    = g_favarite_Doctors_Array[indexPath.row].firstname + " " + g_favarite_Doctors_Array[indexPath.row].lastname
            cell?.LabelSpecialtyNombre.text = g_favarite_Doctors_Array[indexPath.row].special
            cell?.LabelHospitalNombre .text = g_favarite_Doctors_Array[indexPath.row].hospitalname
            cell?.LabelHospitalDireccion.text = g_favarite_Doctors_Array[indexPath.row].hospitaldireccion
            
            
            cell?.LabelDate.text = formattedDateFromString(dateString: Schedule_DateArray[indexPath.row], withFormat: "dd  MMMM, yyyy")
            //cell?.LabelDate.text = Schedule_DateArray[indexPath.row]
            
                    var str = Schedule_DateArray[indexPath.row]
                    let index = str.index(str.startIndex, offsetBy: 2) // index = 2 for 06 from 06:30:00
                    let int_Value = Int(str.substring(to: index))      // 06
                    
                    if int_Value! < 12 {
                        var str_1 = Schedule_DateArray[indexPath.row]
                        let index_1 = str_1.index(str_1.startIndex, offsetBy: 5)
                        
                        cell?.LabelTime.text = Schedule_TimeArray[indexPath.row] + " AM"
                    } else {
                        var str_2 = Schedule_DateArray[indexPath.row]
                        let index_2 = str_2.index(str_2.startIndex, offsetBy: 5)
                        
                        cell?.LabelTime.text = Schedule_TimeArray[indexPath.row] + " PM"
                    }
            //cell?.LabelTime.text = Schedule_TimeArray[indexPath.row]
            
            
            Schedule_DateArray.append("17-09-1989")
            Schedule_TimeArray.append("12:30:30")
            Schedule_IdArray.append(9999)
            
            if Schedule_DateArray[indexPath.row] == "17-09-1989" && Schedule_TimeArray[indexPath.row] == "12:30:30" && Schedule_IdArray[indexPath.row] == 9999 {
                cell?.btnCancel.isHidden = true
                cell?.LabelTime.isHidden = true
                cell?.LabelDate.isHidden = true
            } else {
                cell?.btnCancel.isHidden = false
                cell?.LabelTime.isHidden = false
                cell?.LabelDate.isHidden = false
            }
            

            self.tableView.rowHeight = 270
            cell?.largeSideButton.tag = indexPath.row
            
            cell?.btnCancel.tag  =  indexPath.row
            cell?.btnAddButton.tag  =  indexPath.row
            
            return cell!
            
        } else {        //cellFlag == -1
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "MyDoctorTableCell_1_small") as? MyDoctorTableCell_1_small
            
            cell?.smallCellView.layer.cornerRadius = 6.5
            cell?.TxtLabel.text    = g_favarite_Doctors_Array[indexPath.row].firstname + " " + g_favarite_Doctors_Array[indexPath.row].lastname
            
            self.tableView.rowHeight = 80
            cell?.largeSideButton.tag = indexPath.row
            //cell?.largeLikeButton.tag  =  indexPath.row
            
            return cell!
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if cellFlag == -1 {
            let cell = tableView.cellForRow(at: IndexPath(row: indexPath.row, section: 0)) as? MyDoctorTableCell_1_small
            g_myDoctor_SelIndex_Int = indexPath.row
        } else {
            let cell = tableView.cellForRow(at: IndexPath(row: indexPath.row, section: 0)) as? MyDoctorTableCell_2_large
            g_myDoctor_SelIndex_Int = indexPath.row
        }
        
        
    }
    
//    var SECTION_INDEX: Int = -1
//    //Change cell size
//    func tableView(_ tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
//        
//        if indexPath.row == SECTION_INDEX {
//            return (263 + 0)
//        } else {
//            return (80 + 0)
//        }
//    }

    
    //====================================================================================================================
    //
    //  Cell Button Methods
    //
    //====================================================================================================================
    
    // Right Button for smallCell
    @IBAction func onTappedRightButton_1_small(_ sender: Any) {
        
        let index = (sender as! UIButton).tag
        let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? MyDoctorTableCell_1_small
        
        AddViewTemp.isHidden = true
        cellFlag = index
        tableView.reloadData()
    }
    @IBAction func onTappedUnderButton_2_large(_ sender: Any) {
        cellFlag = -1
        AddViewTemp.isHidden = false
        tableView.reloadData()
    }
 
    
    
    
    
    
    
    @IBAction func onTappedCancelButton(_ sender: Any) {
        print("~~~~~ Cancel Event ~~~~~~")
        
        g_Current_Index = (sender as! UIButton).tag
        //let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? MyDoctorTableCell_1_small
     
        //=====================================================================
        
        view_CheckButton.isHidden = false
        tableView.isUserInteractionEnabled = false
        
        backgroundImageView.isHidden = false
        
//        self.AddViewTemp.backgroundColor = UIColor(red: 150.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
//        self.tableView.backgroundColor = UIColor(red: 150.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
//        self.GradientView.backgroundColor = UIColor(red: 150.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
//        self.view_small.backgroundColor = UIColor(red: 150.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
        
        //=====================================================================
    }
    
    @IBAction func onTappedCancelYep(_ sender: Any) {
        view_CheckButton.isHidden = true
        tableView.isUserInteractionEnabled = true
        
        backgroundImageView.isHidden = true
//        self.AddViewTemp.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
//        self.tableView.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
//        self.GradientView.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
//        self.view_small.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
        
        tryCancel_Schedule(appointmentID: Schedule_IdArray[g_Current_Index])
    }
    
    @IBAction func onTappedCancelNo(_ sender: Any) {
        view_CheckButton.isHidden = true
        tableView.isUserInteractionEnabled = true
        
        backgroundImageView.isHidden = true
        
//        self.AddViewTemp.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
//        self.tableView.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
//        self.GradientView.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
//        self.view_small.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208.0/255.0, alpha: 1.0)
    }
    
    
    // 3. http://67.205.136.161:8070/DocAppointments/rest/appointment/cancel
    func tryCancel_Schedule(appointmentID: Int) {
        
        //print(appointmentID)
        
        let params: NSDictionary = [
            "authorization" :
                ["patientID": 1,
                 "loginPolicy": "USRPASSWD",
                 "eml": "juanperez@gmail.com",
                 "psswd": "Prueba123"
            ],
            "patientID":        g_patientID, //g_Step_5_Array[g_Step_SelIndex_Array[4]].information.patientID,
            "appointmentID":    appointmentID, //23,
            "status":           3
        ]
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue_NSDictionary(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Cancel_Schedule, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                var temp: schedule_Info = schedule_Info(STATUS: "", MSG_: "")
                temp.STATUS = responseObject?["STATUS"] as! String
                temp.MSG_ = responseObject?["MSG_"] as! String
                
                if temp.STATUS == "SUCCESS" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                    
                    // Cancel Time Schedule Code ======================================
                    
                    self.LoadNearestSchedules()
                    
                    //=================================================================
                    
                }
                if temp.STATUS == "ERROR" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                }
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    //=================================================================================
    func LoadNearestSchedules() {
        
        Schedule_DateArray.removeAll()
        Schedule_TimeArray.removeAll()
        Schedule_IdArray.removeAll()
        
        if g_favarite_Doctors_Array.count > 0 {
            viewNoFind.isHidden = true
        } else {
            viewNoFind.isHidden = false
        }
        
        for i in 0 ..< g_favarite_Doctors_Array.count {
            
            tryGet_AllSchedules(cnt: i)
        }
        
        tableView.reloadData()
        
    }
    //=================================================================================
    // 1. http://67.205.136.161:8070/DocAppointments/rest/appointment/all
    func tryGet_AllSchedules(cnt: Int) {
        
        var ODate:NSDate = NSDate()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm:ss"
        
        let currentDate = dateFormatter.string(from: ODate as Date)
        let TodayDate = dateFormatter.date(from: currentDate) //according to date format your date string
        print(TodayDate ?? "") //Convert String to Date

        Schedule_DateArray.append("17-09-1989")
        Schedule_TimeArray.append("12:30:30")
        Schedule_IdArray.append(9999)
        var TempDate = dateFormatter.date(from: currentDate)
        var flag_0: Int = 0
        
        
        let params: NSDictionary = [    "authorization":
                                            ["patientID": 1,
                                             "loginPolicy": "USRPASSWD",
                                             "eml": "juanperez@gmail.com",
                                             "psswd":"Prueba123"
                                            ],
                                         "patientID": g_patientID
                                    ]
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Get_All_Schedules, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
//                print(responseObject)
                
                for data in responseObject! {
                    //print(data)
                    
                    
                    var temp_doctor_Info = doctor_Info(
                        id:           -1,
                        personID:     -1,
                        specialtyID:  -1,
                        assistantID:  -1,
                        lastName:     "",
                        name:         ""
                    )
                    var temp_specialty_Info = specialty_Info(
                        id:            -1,
                        nombre:        ""
                    )
                    var temp_hospital_Info = hospital_Info(
                        id:           -1,
                        nombre:       "",
                        direccion:    "",
                        telefono:     "",
                        email:        "",
                        estado:       -1,
                        locationID:   -1
                    )
                    var temp_Doctor_Schedules_Infor = Doctor_Schedules_Infor(
                        id:           -1,
                        fecha:        "",
                        horaInicio:   "",
                        horaFin:      "",
                        fechaCreacion:"",
                        
                        doctor:       temp_doctor_Info,
                        
                        estado:       -1,
                        hospitalID:   -1,
                        patientID:    -1,
                        doctorID:     -1,
                        
                        specialty:    temp_specialty_Info,
                        
                        hospital:     temp_hospital_Info
                    )
                    
                    let dict = data as! [String: AnyObject]
                    
                    //                    print(dict["fecha"] as! String)
                    //                    print(dict["id"] as! Int)
                    
                    if let doctor_dict = dict["doctor"] as? [String: AnyObject]
                    {
                        temp_doctor_Info.id = doctor_dict["id"] as! Int
                        temp_doctor_Info.personID = doctor_dict["personID"] as! Int
                        temp_doctor_Info.specialtyID = doctor_dict["specialtyID"] as! Int
                        temp_doctor_Info.assistantID = doctor_dict["assistantID"] as! Int
                        temp_doctor_Info.lastName = doctor_dict["lastName"] as! String
                        temp_doctor_Info.name = doctor_dict["name"] as! String

                    }
                    else {
                        return
                    }
                    
                    
                    let specialty_dict = dict["specialty"] as! [String: AnyObject]
                    temp_specialty_Info.id = specialty_dict["id"] as! Int
                    temp_specialty_Info.nombre = specialty_dict["nombre"] as! String
                    
                    let hospital_dict = dict["hospital"] as! [String: AnyObject]
                    temp_hospital_Info.id = hospital_dict["id"] as! Int
                    temp_hospital_Info.nombre = hospital_dict["nombre"] as! String
                    temp_hospital_Info.direccion = hospital_dict["direccion"] as! String
                    temp_hospital_Info.telefono = hospital_dict["telefono"] as! String
                    temp_hospital_Info.email = hospital_dict["email"] as! String
                    temp_hospital_Info.estado = hospital_dict["estado"] as! Int
                    temp_hospital_Info.locationID = hospital_dict["locationID"] as! Int
                    
                    //g_All_Schedules
                    
                    var temp: Doctor_Schedules_Infor = Doctor_Schedules_Infor(
                        id:           dict["id"] as! Int,
                        fecha:        dict["fecha"] as! String,
                        horaInicio:   dict["horaInicio"] as! String,
                        horaFin:      dict["horaFin"] as! String,
                        fechaCreacion:dict["fechaCreacion"] as! String,
                        
                        doctor:       temp_doctor_Info,
                        
                        estado:       dict["estado"] as! Int,
                        hospitalID:   dict["hospitalID"] as! Int,
                        patientID:    dict["patientID"] as! Int,
                        doctorID:     dict["doctorID"] as! Int,
                        
                        specialty:    temp_specialty_Info,
                        
                        hospital:     temp_hospital_Info
                    )
                    
                    //*************************************************************************
                    
                    //g_All_Schedules.append(temp)
                    //self.g_All_SchedulesID.append(temp.id)
                    
                    if temp.doctor.lastName == g_favarite_Doctors_Array[cnt].lastname {
                        if temp.doctor.name == g_favarite_Doctors_Array[cnt].firstname {
                            let str_DateTime = temp.fecha + " " + temp.horaInicio   //"29-06-2017 10:00:00"
                            let date_DateTime = dateFormatter.date(from: str_DateTime)
                            
                            if date_DateTime! > TodayDate! {
                                
                                flag_0 = flag_0 + 1
                                if flag_0 > 1 {
                                    
                                    if TempDate! > date_DateTime! {
                                        TempDate = date_DateTime
                                        
                                        self.Schedule_DateArray[cnt] = temp.fecha
                                        self.Schedule_TimeArray[cnt] = temp.horaInicio
                                        self.Schedule_IdArray[cnt] = temp.id
                                    }
                                    
                                } else {
                                    TempDate = date_DateTime
                                    
                                    self.Schedule_DateArray[cnt] = temp.fecha
                                    self.Schedule_TimeArray[cnt] = temp.horaInicio
                                    self.Schedule_IdArray[cnt] = temp.id
                                }
                            }
                            
                        }
                    }
                }
                
                self.tableView.reloadData()
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedGoToDiary_1(_ sender: Any) { //Large Add Button
        
        performSegue(withIdentifier: StorySegues.FromMyDoctorToStepSearch.rawValue, sender: self)
    }
    
    @IBAction func onTappedGoToDiary_2(_ sender: Any) { //Small Add Button
        
        g_bool_byFavarite = true
        
        g_Current_Index = (sender as! UIButton).tag
        
        self.performSegue(withIdentifier: StorySegues.FromMyDoctorToSearchDiary.rawValue, sender: self)
    }

}
