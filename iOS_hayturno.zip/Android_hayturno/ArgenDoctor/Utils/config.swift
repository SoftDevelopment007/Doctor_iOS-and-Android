//
//  Config.swift
//  Onefortheride
//
//  Created by mac on 25/11/15.
//  Copyright © 2015 mac. All rights reserved.
//

import Foundation
/*
 enum ProfileViewIndex: Int {
 case RESTAURANTS    = 0
 case SEARCHES       = 1
 case FRIENDS        = 2
 case REWARDS        = 3
 }*/

enum StorySegues: String {
    case FromMainToStepSearch           = "MainToStepSearch"
    case FormStepSearchToConfirm        = "StepSearchToConfirm"
    case FromConfirmToSearchDiary       = "ConfirmToSearchDiary"
    case FromSearchDiaryToConfirmacion  = "SearchDiaryToConfirmacion"
    case FromConfirmacionToRegister     = "ConfirmacionToRegister"
    case FromRegisterToCreateAccount    = "RegisterToCreateAccount"
    case FromCreateAccountToPersonalInformation     = "CreateAccountToPersonalInformation"
    case FromPersonalInformationToHome  = "PersonalInformationToHome"
    //case FromRegisterToHome             = "RegisterToHome"
    case FromResgisterToPersonalInfor   = "ResgisterToPersonalInfor"
    case FromHomeToStepSearch           = "HomeToStepSearch"
    case FromHomeToDataPersonales       = "HomeToDataPersonales"
    case FromHomeToMyDoctor             = "HomeToMyDoctor"
    case FromHomeToRegister             = "HomeToRegister"
    case FromHomeToMyShift              = "HomeToMyShift"
    case FromCalendarToStepSearch       = "CalendarToStepSearch"
    case FromMyDoctorToSearchDiary      = "MyDoctorToSearchDiary"
    case FromSignInToHomView            = "SignInToHomView"
    case FromMainToSignIn               = "MainToSignIn"
    case FromHomeToSignIn               = "HomeToSignIn"
    case FromMyDoctorToStepSearch       = "MyDoctorToStepSearch"


    
    case FromConfirmacionToAprobacion   = "ConfirmacionToAprobacion"
    case FromConfirmacionToMyShift      = "ConfirmacionToMyShift"
    case FromAprobacionToMyShift        = "AprobacionToMyShift"
    case FromMainToMyShift              = "MainToMyShift"
    case FromPersonalInformationToMyShift   = "PersonalInformationToMyShift"
    case FromCalendarToUpdatePersonal   = "CalendarToUpdatePersonal"
    case FromCalendarToMyDoctor     = "CalendarToMyDoctor"
    case FromCalendarToSignIn       = "CalendarToSignIn"
    
    
}

enum UserDialogs: String {
    /*case SigninIncorrect        = "Your login information is incorrect."
     case EmailIsTaken           = "That email address is already taken."*/
    case CompleteRequireFields  = "Please complete all required fields."
    /*case RequireEmailAddress    = "Email address should be required."
     case PasswordRecoveryFailed = "Recovery is failed. Try again."*/
    case PasswordNotMatch       = "Passwords do not match"
    case FacebookSignOK       = "success Login with Facebook"
    case GoogleSignOK       = "success Login with Google"
}
