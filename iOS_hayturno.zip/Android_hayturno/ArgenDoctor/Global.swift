//
//  Global.swift
//  Amoureuse
//
//  Created by LEE on 3/30/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import UIKit


//Local Notification date
var g_NotificationDate_beforeDay = Date()
var g_NotificationDate_Today = Date()


//adminView
var curSel: Int = 0
var g_LoginFlag:   Bool = false



// 21. http://67.205.136.161:8070/DocAppointments/rest/patient/user/add
/*{
 "STATUS": "SUCCESS",
 "MSG_": "El usuario ha sido creado exitosamente",
 "patientID": 227
 }*/
struct User_Add_Infor {
    var STATUS:     String
    var MSG_:       String
    var patientID:  Int
}
//PatientID
var g_patientID: Int = -1


// Global Variables For Search Diary
var g_Diary_Date: String = ""       //"16-05-2017"
var g_Diary_Time: String = ""       //"06:00 AM"
var g_Diary_Time_Start: String = "" //"06:00:00"
var g_Diary_Time_End: String = ""   //"06:30:00"


struct ProfileInfo{
    
    var firstname:      String
    var lastname:       String
    var name:           String  // [FirstName + " " + LastName]
    var email:          String  // maria@mail.com
    var password:       String
    var birthday:       String  // 01-01-1980
    var phone:          String  // "123456789"
    var gender:         Int     // 1-male, 2-female     String  // male female
    var dni:            String  // 12345678
    var socialwork:     Int  // Boreal Prensa
    var afiliadonumber: String  // "123"
    var avatarimage:    UIImage // #imageLiteral(resourceName: "Icon_Red_Alert")
}

var g_ProfileInfo: ProfileInfo = ProfileInfo(
    firstname: "",
    
    lastname: "",
    name: "",
    
    email: "",
    password: "",
    
    
    birthday: "",
    phone: "",
    gender: -1,
    dni: "",
    socialwork: -1,
    afiliadonumber: "",
    avatarimage: #imageLiteral(resourceName: "7_AnonymousImag.png")  // 7_AnonymousImag.png 3_RegisterCenterPhoto.png
)




// App Is LogIn?
var g_RegisteredFlag: Bool = false

//My Doctor Page
//var g_myDoctor_Array   =   Array<String>()
var g_myDoctor_SelIndex_Int: Int = -1




//let OBRASOCIAL_ALL = "patient/obrasocial/all"        //http://67.205.136.161:8070/DocAppointments/rest/patient/obrasocial/all
var g_InitSocialWork_Array = Array<String>()           //var g_InitSocialWork_Array = ["Boreal", "Prensa"]





// Step ===========================================================================================================
var g_Step_CurSel_Int:     Int = 0
var g_Step_SelIndex_Array  = [-1, -1, -1, -1, -1]


/*    {
            "id": 24,
            "nombre": "Tucumán"
       }
 */
struct Step1_Info{
    var id:         Int
    var nombre:     String
}
var g_Step_1_Array:        Array<Step1_Info>   = Array<Step1_Info>()



/*    {
        "id": 27859,
        "nombre": "Acheral   ",
        "provinceID": 24
      }
*/
struct Step2_Info{
    var id:             Int
    var nombre:         String
    var provinceID:    Int
}
var g_Step_2_Array:        Array<Step2_Info>   = Array<Step2_Info>()



/*    {
         "id": 1,
         "nombre": "Cardiologia"
      }
 */
struct Step3_Info{
    var id:             Int
    var nombre:         String
}
var g_Step_3_Array:        Array<Step3_Info>   = Array<Step3_Info>()



/*    {
            "id": 2,
            "nombre": "Sanatorio Norte",
            "direccion": "Salta 122",
            "telefono": "4312233",
            "email": "info@sanatorionorte.com",
            "estado": 1,
            "locationID": 27859
      }
 */
struct Step4_Info{
    var id:             Int
    var nombre:         String
    var direccion:      String
    var telefono:       String
    var email:          String
    var estado:         Int
    var locationID:     Int
}
var g_Step_4_Array:        Array<Step4_Info>   = Array<Step4_Info>()



/*    {
        "specialty": {
            "id": 1,
            "nombre": "Cardiologia"
        },
        "doctorID": 6,
        "information": {
            "nombre": "Luciana",
            "apellido": "Perez",
            "dni": "32233643",
            "sexo": 1,
            "fechaNacimiento": "01-01-1986",
            "telefono": "123-45699",
            "celular": "5678-123499",
            "email": "algo@gmai2l.com",
            "estado": 1,
            "numObraSocial": null,
            "googleUserId": null,
            "hospitalID": 2,
            "provinceID": 24,
            "obraSocialInfo": null,
            "personType": "DOCTOR",
            "patientID": null,
            "doctorID": 6,
            "assistantID": null,
            "locationID": 27859,
            "personID": 24
        }
    }
*/
struct specialty_Info{
    var id:             Int
    var nombre:         String
}
struct information_Info{
    var nombre:           String
    var apellido:         String
    var dni:              String
    var sexo:             Int
    var fechaNacimiento:  String
    var telefono:         String
    var celular:          String
    var email:            String
    var estado:           Int
    var numObraSocial:    String
    var googleUserId:     String
    var hospitalID:       Int
    var provinceID:       Int
    var obraSocialInfo:   String
    var personType:       String
    var patientID:        String
    var doctorID:         Int
    var assistantID:      String
    var locationID:       Int
    var personID:         Int
}
struct Step5_Info{
    var specialty:        specialty_Info
    var doctorID:         Int
    var information:      information_Info
}
var g_Step_5_Array:        Array<Step5_Info>   = Array<Step5_Info>()

// Add new Schedule to doctor.
/*  {
        "STATUS": "SUCCESS",
        "MSG_": "El turno ya habia sido calendarizado para el paciente"
    }*/
struct schedule_Info{
    var STATUS:           String
    var MSG_:             String
}


// Get All favarite Doctors with PatientID
//http://67.205.136.161:8070/DocAppointments/rest/patient/favorite/all
/* "favoriteID": 4,
 "doctorID": 2,
"hospital": {
    "id": 1,
*/
struct  favarite_Doctor_Infor {
    var favoriteID:         Int
    var doctorID:           Int
    var hospital_id:        Int
    
    var firstname:          String
    var lastname:           String
    var special:            String
    var hospitalname:       String
    var hospitaldireccion:  String
    
    var hospitaltelefono:   String
}
var g_favarite_Doctors_Array: Array<favarite_Doctor_Infor> = Array<favarite_Doctor_Infor>()

//By Favarite
var g_bool_byFavarite:  Bool = false
var g_Current_Index:    Int  = -1




// Get Doctor schedules ===============================================================================
/*    {
        "appointments":
        [
            {
                "id": 153,
                "fecha": "15-06-2018",
                "horaInicio": "17:00:00",
                "horaFin": "17:30:00",
                "fechaCreacion": "31-05-2017 20:36:28",
        
                "doctor": {
                    "id": 1,
                    "personID": 2,
                    "specialtyID": 1,
                    "assistantID": 1,
                    "lastName": "Rodriguez",
                    "name": "Maximiliano"
                },
        
                "estado": 1,
                "hospitalID": 1,
                "patientID": 1,
                "doctorID": 1,
        
                "specialty": {
                    "id": 1,
                    "nombre": "Cardiologia"
                },
        
                "hospital": {
                    "id": 1,
                    "nombre": "Hospital de Tucuman",
                    "direccion": "Hipolito Yrigoyen 2912",
                    "telefono": "4242-8573",
                    "email": "hospital@minindancia.gov.ar",
                    "estado": 1,
                    "locationID": 27909
                }
            }
        ],
        "schedules": []
    }
*/
struct doctor_Info{
    var id:           Int
    var personID:     Int
    var specialtyID:  Int
    var assistantID:  Int
    var lastName:     String
    var name:         String
}
//struct specialty_Info{
//    var id:             Int
//    var nombre:         String
//}
struct hospital_Info{
    var id:           Int
    var nombre:       String
    var direccion:    String
    var telefono:     String
    var email:        String
    var estado:       Int
    var locationID:   Int
}
struct Doctor_Schedules_Infor {
    var id:           Int
    var fecha:        String
    var horaInicio:   String
    var horaFin:      String
    var fechaCreacion:String
    
    var doctor:       doctor_Info
    
    var estado:       Int
    var hospitalID:   Int
    var patientID:    Int
    var doctorID:     Int
    
    var specialty:    specialty_Info
    
    var hospital:     hospital_Info
}
var g_Doctor_Schedules:   Array<Doctor_Schedules_Infor>   = Array<Doctor_Schedules_Infor>()     // for Step 5 Page

var g_All_Schedules:   Array<Doctor_Schedules_Infor>   = Array<Doctor_Schedules_Infor>()        //for diary Page





/*import ImageSlideshow

//adminView
var curSel: Int = 0



struct ProfileInfo{
 
    var title:  String
 
    //Private
    var dob:  String
    var role: String
 
    //Public
    var avatarStandard:     String
    var avatarThumb:        String
    var coverImageStandard: String
    var coverImageThumb:    String
 
    var bio:                String
    var gender:             String
    var interests:          String
    var name:               String
    var yearOfBirth:        String
 
    var gridImage:          Array<String>
}

//This is necessary for update, since using last "CreatedAt"
var g_NewProfileFlag_private: Int = 0
var g_NewProfileFlag_public: Int = 0
//-----------------------------------------------------------

//This is necessary for only once read from firebase data.
var initialDataLoaded_private   = false;
var initialDataLoaded_public    = false;
var initialGridPictures         = false;
var initialSearchingUsers       = false;
var initialPotential            = false;
var initialMatch                = false;

//home
var initialChatList             = false;
var initialChannelHeaders       = false;
var initialConversations        = false;

//var g_AutoUpLoadChannelHeaders_locations_Flag = false;
//-----------------------------------------------------------

var curProfileInfo: ProfileInfo = ProfileInfo(
                                              title: "",
    
                                              dob: "",
                                              role: "",
                                              
                                              avatarStandard: "",
                                              avatarThumb: "",
                                              coverImageStandard: "",
                                              coverImageThumb: "",
                                              bio: "",
                                              gender: "",
                                              interests: "",
                                              name: "",
                                              yearOfBirth: "",
                                              gridImage: []
                                             )

var avatarThumb_UI:        UIImage =  #imageLiteral(resourceName: "profile.png")        // profile.png
var coverImageThumb_UI:    UIImage = #imageLiteral(resourceName: "splash")   //splash

var Temp_avatarThumb_UI:     UIImage = #imageLiteral(resourceName: "profile.png")
var Temp_coverImageThumb_UI: UIImage = #imageLiteral(resourceName: "splash")


var g_gridImage   =   Array<UIImage>()

//This is necessary for slideshow
var g_localSource = Array<ImageSource>()
//-----------------------------------------------------------

//Settings
var g_gender:      Int = 3
var g_maxDistance: Int = 5
var g_age_maximum: Int = 56
var g_age_minimum: Int = 18
//-----------------------------------------------------------

//Current Location
var g_latitude:  Double = 0.0
var g_longitude: Double = 0.0
//-----------------------------------------------------------

//Potential data
struct UserInfo {
    //var backgroundUrl: String
    //var avatarUrl: String
    
    var title:        String
    
    
    var avatarUrl:    String
    var coverUrl:     String
    
    var name:         String
    var bio:          String
    var gender:       String
    var interests:    String
    
    var avatarImage:  UIImage
    var coverImage:   UIImage
    
    var uid:          String
}

//====================================================================================================================
var g_Potential_Array: [UserInfo] = []

//This is necessary for slideshow
var g_Potential_localSource = Array<ImageSource>()

//var Potential_Grid_standardUrl:     Array<String>   = Array<String>()
var g_Potential_Grid_thumbUrl:        Array<String>   = Array<String>()
//var Potential_Grid_standardImage:   Array<UIImage>  = Array<UIImage>()
var g_Potential_Grid_thumbImage:      Array<UIImage>  = Array<UIImage>()

var g_Potential_index: Int = -1

//====================================================================================================================
var g_Match_Array: [UserInfo] = []

//This is necessary for slideshow
var g_Match_localSource = Array<ImageSource>()

//var Match_Grid_standardUrl:     Array<String>   = Array<String>()
var g_Match_Grid_thumbUrl:        Array<String>   = Array<String>()
//var Match_Grid_standardImage:   Array<UIImage>  = Array<UIImage>()
var g_Match_Grid_thumbImage:      Array<UIImage>  = Array<UIImage>()

var g_Match_index: Int = -1




//Potential data
struct ChatListInfo {
    
    var name:           String
    var lastMessage:    String
    var time:           Date
    
    var avatarImage:    UIImage
    
    var uid:            String
}

//====================================================================================================================
var g_ChatList_Array: [ChatListInfo] = []
var g_ChatList_index: Int = -1



//ChatViewController
 var temp_avatarImage: UIImage?
 var temp_title: String?
 var temp_name: String?
 var temp_uid: String?
*/











