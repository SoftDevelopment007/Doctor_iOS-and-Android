//
//  ServiceClass.swift
//  Wealth
//
//  Created by Rohit Ajmera on 12/17/16.
//  Copyright © 2016 Rohit Ajmera. All rights reserved.
//

import UIKit
import AFNetworking

class Global: NSObject {
    
    let IDIOM = UI_USER_INTERFACE_IDIOM()
    let IPAD =  UIUserInterfaceIdiom.pad
    let IPHONE = UIUserInterfaceIdiom.phone
    
    let kOFFSET_FOR_KEYBOARD:Float = 80.0
    static let APP_TIMEOUT:TimeInterval = 100.0
    
    
    let APIHEADER            =   "http://67.205.136.161:8070/DocAppointments/rest/"
    
    //let USER_VERIFY =  "user/verify/"
    //let USER_REGISTER =  "api/v1/registrations/"
    let USER_SIGNIN          =  "patient/login"
    
    
    
    let OBRASOCIAL_ALL       = "patient/obrasocial/all"
    
    
    //Step
    let step1_PROVICIA       = "location/provinces/all"
    let step2_CIUDAD         = "location/locationsperprovince"
    let step3_ESPESIALIDAD   = "location/specialtiesperlocation"
    let step4_INSTITUTO      = "location/hospitalsperspeciality"
    let step5_ESPECIALISTA   = "doctor/byinstitutionandspecialty"
    
    // Add Schedule
    let Add_Schedule   = "appointment/schedule"
    
    // Get Schedules
    let Get_Schedules   = "doctor/schedules"
    
    // Get All infors for Patient
    let Get_All_Schedules = "appointment/all"
    
    // Delete one Schedule
    let Cancel_Schedule = "appointment/cancel"
    
    // Add User
    let Add_User = "patient/user/add"

    // Get favarite doctors
    let Get_Favarite_Doctors = "patient/favorite/all"
    
    // Add favarite doctor
    let Add_Favarite_Doctor = "patient/favorite/add"
    
    // Remove favarite doctor
    let Remove_Favarite_Doctor = "/patient/favorite/remove"
    
    // Patient SignIn
    let SignIn_Patient = "/patient/login"
    

}


class ServiceClass: NSObject {
    
    func servicePostMethodWithAPIHeaderValue(apiValue: String, headerValue: String, parameters params: [NSObject : AnyObject], timeout: TimeInterval = Global.APP_TIMEOUT, completion completionBlock: (((Array<Any>)?) -> Void)?) -> () {
        
        let url = "\(apiValue)\(headerValue)"
        let manager = AFHTTPSessionManager()
        manager.requestSerializer = AFJSONRequestSerializer()
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "content-type")
        manager.requestSerializer.setAuthorizationHeaderFieldWithUsername("DSFKJ#lmkdsf@&&", password: "5sdf42151SDF5JKNHDSF@#LMDSFL")
        manager.requestSerializer.timeoutInterval = timeout
        manager.responseSerializer = AFJSONResponseSerializer()
        
        manager.post(url, parameters: params, progress: { (nil) in
            
        }, success: { (task, responseObject) in
            
            let responseObject = responseObject as! Array<AnyObject>
            
            completionBlock!(responseObject)
            
        })
        
        { (task, error) in
            
            ProgressHUD.dismiss()
            
            let alertView = UIAlertController(title: "", message: "\(error.localizedDescription)", preferredStyle: .alert)
                            alertView.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alertAction) -> Void in
            
                            }))
                            alertView.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
                            UIApplication.shared.delegate?.window!!.rootViewController?.present(alertView, animated: true, completion: nil)

        }
        
    }

    func servicePostMethodWithAPIHeaderValue_NSDictionary(apiValue: String, headerValue: String, parameters params: [NSObject : AnyObject], timeout: TimeInterval = Global.APP_TIMEOUT, completion completionBlock: (((NSDictionary)?) -> Void)?) -> () {
        
        let url = "\(apiValue)\(headerValue)"
        let manager = AFHTTPSessionManager()
        manager.requestSerializer = AFJSONRequestSerializer()
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "content-type")
        manager.requestSerializer.setAuthorizationHeaderFieldWithUsername("DSFKJ#lmkdsf@&&", password: "5sdf42151SDF5JKNHDSF@#LMDSFL")
        manager.requestSerializer.timeoutInterval = timeout
        manager.responseSerializer = AFJSONResponseSerializer()
        
        manager.post(url, parameters: params, progress: { (nil) in
            
        }, success: { (task, responseObject) in
            
            let responseObject = responseObject as! NSDictionary
            
            completionBlock!(responseObject)
            
        }) { (task, error) in
            
            ProgressHUD.dismiss()
            
            if headerValue == "/patient/login" {
                UIApplication.shared.delegate?.window!!.rootViewController?.view.makeToast("Credenciales de acceso invalidas", duration: 3.0, position: .bottom)
                return
            }
            
            let alertView = UIAlertController(title: "", message: "\(error.localizedDescription)", preferredStyle: .alert)
            alertView.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alertAction) -> Void in
                
            }))
            alertView.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
            UIApplication.shared.delegate?.window!!.rootViewController?.present(alertView, animated: true, completion: nil)
            
        }
        
    }
    
    
    func serviceGetMethodWithAPIHeaderValue(apiValue: String, headerValue: String, params: String, completion completionBlock: @escaping (NSDictionary) -> Void) {
        let requestLink = "\(apiValue)\(headerValue)"
        let urlWithParams = requestLink + params
        let myUrl = NSURL(string: urlWithParams);
        print(urlWithParams)
        let request = NSMutableURLRequest(url: myUrl! as URL)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: {
            data, response, error in
            if error != nil
            {
                print("error=\(error)")
                return
            }
            do {
                let dictonary = try JSONSerialization.jsonObject(with: data!, options: []) as? [String:AnyObject]
                completionBlock(NSDictionary(dictionary: dictonary!))
                    
            } catch let error as NSError {
                print(error)
            }
        })
        task.resume()
    }
}

