//
//  DataPersonalesViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/26/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

import JVFloatLabeledTextField
import DatePickerDialog

import SDWebImage
import Toast_Swift

class DataPersonalesViewController: UIViewController, WDImagePickerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate {

    @IBOutlet weak var ImageBasePic: UIImageView!
    
    @IBOutlet weak var ImagePicFrame: UIImageView!
    @IBOutlet weak var AvatatButton: UIButton!
    
    
    @IBOutlet weak var TextName: JVFloatLabeledTextField!
    @IBOutlet weak var TextDNI: JVFloatLabeledTextField!
    @IBOutlet weak var TextEmail: JVFloatLabeledTextField!
    @IBOutlet weak var TextBirthday: JVFloatLabeledTextField!
    @IBOutlet weak var TextPhone: JVFloatLabeledTextField!
    
    @IBOutlet weak var TextDNI_1: UITextField!
    @IBOutlet weak var TextPhone_1: UITextField!
    
    
    //WDImagePicker
    var imagePicker: WDImagePicker!
    var fixedImage: UIImage?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        TextPhone_1.delegate = self
        TextPhone_1.keyboardType = .numberPad
        TextDNI_1.delegate = self
        TextDNI_1.keyboardType = .numberPad
        
        //Init Values
        ImageBasePic.isHidden = true
        ImagePicFrame.isHidden = false
        AvatatButton.isHidden = false
        
        InitShow()
    }
    
    override func viewDidAppear(_ animated: Bool) {
       InitShow()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        if textField == self.TextPhone_1 {
            
            let invalidCharacters = CharacterSet(charactersIn: "+0123456789").inverted
            return string.rangeOfCharacter(from: invalidCharacters, options: [], range: string.startIndex ..< string.endIndex) == nil
        } else {
            let invalidCharacters = CharacterSet(charactersIn: "0123456789").inverted
            return string.rangeOfCharacter(from: invalidCharacters, options: [], range: string.startIndex ..< string.endIndex) == nil
        }
    }
    
    func InitShow(){
        
        self.TextName.text = g_ProfileInfo.name
        self.TextDNI.text = g_ProfileInfo.dni
        self.TextEmail.text = g_ProfileInfo.email
        self.TextBirthday.text = g_ProfileInfo.birthday
        self.TextPhone.text = g_ProfileInfo.phone
        
        self.AvatatButton.setBackgroundImage(g_ProfileInfo.avatarimage, for: .normal)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func GetProfileInfor() -> Bool {
        
        var Flag: Bool = true
        
        if TextName.text != "" {
            g_ProfileInfo.name = TextName.text!
            
            let fullName = g_ProfileInfo.name //"First Last"
            let fullNameArr : [String] = fullName.components(separatedBy: " ")
            
            // And then to access the individual words:
            g_ProfileInfo.firstname = fullNameArr[0]
            g_ProfileInfo.lastname = fullNameArr[1]
            
            print(g_ProfileInfo.firstname)
            print(g_ProfileInfo.lastname)
            
            
        } else {
            Flag = false
        }
        
        if TextDNI.text != "" {
            g_ProfileInfo.dni = TextDNI.text!
        } else {
            Flag = false
        }
        
        if TextEmail.text?.isEmail != false {
            
            g_ProfileInfo.email = TextEmail.text!
        } else {
            Flag = false
        }
        
        if TextBirthday.text != "" {
            g_ProfileInfo.birthday = TextBirthday.text!
        } else {
            Flag = false
        }
        
        if TextPhone.text != "" {
            g_ProfileInfo.phone = TextPhone.text!
        } else {
            Flag = false
        }
        
        if Flag == false {
            self.view.makeToast("Inserte Infors correctos en todos los campos.")
        } else {
        }
        return Flag
    }
    
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        if GetProfileInfor() {
            
            //===================================================
            // update
            //===================================================
            
            ImageBasePic.isHidden = true
            ImagePicFrame.isHidden = false
            AvatatButton.isHidden = false
            
            UserDefaults.standard.set(UIImageJPEGRepresentation(g_ProfileInfo.avatarimage, 100), forKey: "avatarImage")
            
            
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func imageWithImage(image: UIImage, newSize: CGSize) -> UIImage{
        UIGraphicsBeginImageContext(newSize)
        image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let newImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    @IBAction func onTappedAddAvatarImageButton(_ sender: Any) {
        
        g_ProfileInfo.name = self.TextName.text!
        g_ProfileInfo.dni = self.TextDNI.text!
        g_ProfileInfo.email = self.TextEmail.text!
        g_ProfileInfo.birthday = self.TextBirthday.text!
        g_ProfileInfo.phone = self.TextPhone.text!
        
        
        imagePicker = WDImagePicker()
        imagePicker.cropSize = CGSize(width: 280, height: 200)
        imagePicker.delegate = self
        let alert = UIAlertController(title: "opción", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Cámara", style: .default, handler:{
            action in
            self.imagePicker.imagePickerController.sourceType = .camera
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Biblioteca de fotografías", style: .default, handler: {
            action in
            self.imagePicker.imagePickerController.sourceType = .photoLibrary
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    func imagePicker(_ imagePicker: WDImagePicker, pickedImage: UIImage) {
        
        self.fixedImage = self.imageWithImage(image: pickedImage, newSize: CGSize(width: 110, height: 110))
        self.fixedImage = Utils.profileImage(image: self.fixedImage!)
        g_ProfileInfo.avatarimage = fixedImage!
        self.AvatatButton.setBackgroundImage(g_ProfileInfo.avatarimage, for: .normal)
        
        ImageBasePic.isHidden = true
        ImagePicFrame.isHidden = false
        AvatatButton.isHidden = false
        
        InitShow()
        
        self.imagePicker.imagePickerController.dismiss(animated: true, completion: nil)
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo:[AnyHashable: Any]!)
        {
            picker.dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func onTappedDateButton(_ sender: Any) {
        DatePickerDialog().show(title: "Cumpleaños selecto", doneButtonTitle: "Salvar", cancelButtonTitle: "Cancelar", minimumDate: nil, maximumDate: nil, datePickerMode: .date) { (date) in
            if date != nil {
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd-MM-yyyy"
                //dateFormatter.dateStyle = .medium
                var strDate = dateFormatter.string(from: date!)
                
                self.TextBirthday?.text = strDate
                g_ProfileInfo.birthday = strDate
            }
        }
    }
}



