//
//  HomeViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/26/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit


class AprobacionViewController: UIViewController {
    
    let GlobalVar = Global()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
 
    @IBAction func onTappedMisTurnosButton(_ sender: Any) {
        
        g_Step_CurSel_Int = 1
        
        tryAddSchedule()
         
         let when = DispatchTime.now() + 2 // change 2 to desired number of seconds
         DispatchQueue.main.asyncAfter(deadline: when) {
         let frontView = self.storyboard?.instantiateViewController(withIdentifier: "MyShiftViewControllerVC") as! MyShiftViewController
         let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
         rearView.delegate = frontView
         let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
         self.navigationController?.pushViewController(swViewController!, animated: true)
         
         }
    }
    
    // Add Schedule  -----------------------------------------------------------------------------------------------
    //2. http://67.205.136.161:8070/DocAppointments/rest/appointment/schedule
    func tryAddSchedule() {
        
        
        var params: NSDictionary =
            
            [
            "authorization" :
                
                ["patientID": 1,
                 "loginPolicy": "USRPASSWD",
                 "eml": "juanperez@gmail.com",
                 "psswd": "Prueba123"],
                                        
                                        "patientID":        g_patientID, //g_Step_5_Array[g_Step_SelIndex_Array[4]].information.patientID,
                
                "date":             g_Diary_Date,           //"20-09-2016",
                "startTime":        g_Diary_Time_Start,      //"10:00:00",
                "endTime":          g_Diary_Time_End,        //"10:30:00",
                "hospitalID":       "",
                "doctorID":         ""
        ]
        
        if g_bool_byFavarite == true {
            params = ["authorization" :
                ["patientID": 1,
                 "loginPolicy": "USRPASSWD",
                 "eml": "juanperez@gmail.com",
                 "psswd": "Prueba123"],
                      
                      "patientID":        g_patientID, //g_Step_5_Array[g_Step_SelIndex_Array[4]].information.patientID,
                
                "date":             g_Diary_Date,           //"20-09-2016",
                "startTime":        g_Diary_Time_Start,      //"10:00:00",
                "endTime":          g_Diary_Time_End,        //"10:30:00",
                "hospitalID":       g_favarite_Doctors_Array[g_Current_Index].hospital_id,
                "doctorID":         g_favarite_Doctors_Array[g_Current_Index].doctorID
            ]
        } else {
            params = ["authorization" :
                ["patientID": 1,
                 "loginPolicy": "USRPASSWD",
                 "eml": "juanperez@gmail.com",
                 "psswd": "Prueba123"],
                      
                      "patientID":        g_patientID, //g_Step_5_Array[g_Step_SelIndex_Array[4]].information.patientID,
                
                "date":             g_Diary_Date,           //"20-09-2016",
                "startTime":        g_Diary_Time_Start,      //"10:00:00",
                "endTime":          g_Diary_Time_End,        //"10:30:00",
                "hospitalID":       g_Step_5_Array[g_Step_SelIndex_Array[4]].information.hospitalID,
                "doctorID":         g_Step_5_Array[g_Step_SelIndex_Array[4]].information.doctorID
            ]
        }
        
        
        
        
        
        
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue_NSDictionary(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Add_Schedule, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                var temp: schedule_Info = schedule_Info(STATUS: "", MSG_: "")
                temp.STATUS = responseObject?["STATUS"] as! String
                temp.MSG_ = responseObject?["MSG_"] as! String
                
                if temp.STATUS == "SUCCESS" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                    
                    
                    if temp.MSG_ != "El turno ya habia sido calendarizado para el paciente" {   //"El turno ha sido calendarizado exitosamente"
                        //Please Add Local Notification Code.
                        if g_LoginFlag {
                            self.AddLocalNotification_Before1day()
                            self.AddLocalNotification_Before1hour()
                            
                            g_bool_byFavarite = false
                        }
                    }
                    
                }
                if temp.STATUS == "ERROR" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                }
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    func AddLocalNotification_Before1day() {
        
        let dateFormatter1 = DateFormatter()
        dateFormatter1.dateFormat = "yyyy-MM-dd"
        
        let currentDate = dateFormatter1.string(from: g_NotificationDate_beforeDay)
        let dateTime = currentDate + " " + g_Diary_Time_Start   //"UTC"
        //let dateTime = "2017-06-26 08:05:00"
        
        dateFormatter1.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        let Finaldate = dateFormatter1.date(from: dateTime) //according to date format your date string
        print(Finaldate ?? "") //Convert String to Date
        
        var localNotification:UILocalNotification = UILocalNotification()
        //let newDate = Date(timeInterval: 10, since: Date())
        //let temp = Date()
        //print(temp)
        localNotification.fireDate = Finaldate  //temp.addingTimeInterval(60)
        localNotification.soundName = "Notification.mp3"
        localNotification.repeatInterval = NSCalendar.Unit.weekOfYear   //NSCalendar.Unit.weekday
        
        localNotification.alertBody = "Tienes una cita en 1 día. Si deseas cancelarla toca aquí."
        let app = UIApplication.shared
        app.scheduleLocalNotification(localNotification)
        
    }
    
    func AddLocalNotification_Before1hour() {
        
        let dateFormatter1 = DateFormatter()
        dateFormatter1.dateFormat = "yyyy-MM-dd"
        
        let currentDate = dateFormatter1.string(from: g_NotificationDate_Today)
        let dateTime = currentDate + " " + g_Diary_Time_Start   //"UTC"
        //let dateTime = "2017-06-27 09:57:00"
        
        dateFormatter1.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        let Finaldate = dateFormatter1.date(from: dateTime) //according to date format your date string
        print(Finaldate ?? "") //Convert String to Date
        
        var localNotification:UILocalNotification = UILocalNotification()
        //let newDate = Date(timeInterval: 10, since: Date())
        //let temp = Date()
        //print(temp)
        localNotification.fireDate = Finaldate?.addingTimeInterval(-3600)  //temp.addingTimeInterval(60)
        
        localNotification.soundName = "Notification.mp3"
        
        localNotification.repeatInterval = NSCalendar.Unit.weekOfYear   //NSCalendar.Unit.weekday
        
        localNotification.alertBody = "Tienes una cita dentro de 1 hora. Si deseas cancelarla toca aquí."
        let app = UIApplication.shared
        app.scheduleLocalNotification(localNotification)
        
    }
    
    
    
}
