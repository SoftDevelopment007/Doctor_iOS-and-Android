//
//  StepSearchViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/24/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

class StepSearchViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let GlobalVar = Global()
    
    @IBOutlet weak var tableView: UITableView!
    
    //Step No 1 ~ 5
    @IBOutlet weak var BTNStepNo1: UIButton!
    @IBOutlet weak var BTNStepNo2: UIButton!
    @IBOutlet weak var BTNStepNo3: UIButton!
    @IBOutlet weak var BTNStepNo4: UIButton!
    @IBOutlet weak var BTNStepNo5: UIButton!
    
    @IBOutlet weak var VIEWStepNo1: UIView!
    @IBOutlet weak var VIEWStepNo2: UIView!
    @IBOutlet weak var VIEWStepNo3: UIView!
    @IBOutlet weak var VIEWStepNo4: UIView!
    @IBOutlet weak var VIEWStepNo5: UIView!
    
    //Bottom Confirm Button
    @IBOutlet weak var BTNBottomConfirm: UIButton!
    
    //Set Table Refresh Control
    var refreshControl = UIRefreshControl()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        //Set Delegate Table View
        tableView.tableHeaderView = UIView()
        tableView.delegate = self
        tableView.dataSource = self
        
        g_Step_CurSel_Int = 1
        
        //Set Table Refresh Control
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        
        
        refreshControl.addTarget(self, action: #selector(self.handleRefresh(sender:)), for: UIControlEvents.valueChanged)
        self.tableView.addSubview(refreshControl)
        
        
        //========================================
        // handleRefresh(sender: self)
        //========================================
        
        if CheckConfirm() {
            
            BTNBottomConfirm.isEnabled = true
        } else {
            
            BTNBottomConfirm.isEnabled = false
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        switch g_Step_CurSel_Int  {
        case 1: onTappedNo1Button(self)
        case 2: onTappedNo2Button(self)
        case 3: onTappedNo3Button(self)
        case 4: onTappedNo4Button(self)
        case 5: onTappedNo5Button(self)
            
        default: print(g_Step_CurSel_Int)
        }
        tableView.reloadData()
    }
    
    
    //Loading Infors =======================================================================================
    
    //step1 - PROVICIA -------------------------------------------------------------------------------------
    //14. http://67.205.136.161:8070/DocAppointments/rest/location/provinces/all
    func tryStep1_PROVICIA() {
        let params: NSDictionary = [:]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.step1_PROVICIA, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                for data in responseObject! {
                    //print(data)
                    
                    let dict = data as! [String: AnyObject]
                    
                    var temp: Step1_Info = Step1_Info(id: -1, nombre: "")
                    temp.id = dict["id"] as! Int
                    temp.nombre = dict["nombre"] as! String
                    
                    g_Step_1_Array.append(temp)
                }
                
                print(g_Step_1_Array[0])
                
                self.tableView.reloadData()
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    
    //step2 - CIUDAD ----------------------------------------------------------------------------------------
    //15. http://67.205.136.161:8070/DocAppointments/rest/location/locationsperprovince
    func tryStep2_CIUDAD() {
        
        if g_Step_SelIndex_Array[0] == -1 {
            
            var temp: Step2_Info = Step2_Info(id: -1, nombre: "No se encontraron resultados, por favor seleccione otros criterios de búsqueda", provinceID: -1)
            g_Step_2_Array.append(temp)
            
            return
        }
        
        let params: NSDictionary = ["provinceID" : g_Step_1_Array[g_Step_SelIndex_Array[0]].id]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.step2_CIUDAD, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                for data in responseObject! {
                    //print(data)
                    
                    let dict = data as! [String: AnyObject]
                    
                    var temp: Step2_Info = Step2_Info(id: -1, nombre: "", provinceID: -1)
                    temp.id = dict["id"] as! Int
                    temp.nombre = dict["nombre"] as! String
                    temp.provinceID = dict["provinceID"] as! Int
                    
                    g_Step_2_Array.append(temp)
                }
                
                
                if g_Step_2_Array.count == 0 {
                    
                    var temp: Step2_Info = Step2_Info(id: -1, nombre: "No se encontraron resultados, por favor seleccione otros criterios de búsqueda", provinceID: -1)
                    
                    if temp.nombre != "" {
                        print(g_Step_2_Array[0])
                        //g_Step_2_Array.append(temp)
                    }
                }
                
                self.tableView.reloadData()
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    
    //step3 - ESPESIALIDAD --------------------------------------------------------------------------------------
    //16. http://67.205.136.161:8070/DocAppointments/rest/location/specialtiesperlocation
    func tryStep3_ESPESIALIDAD() {
        
        if g_Step_SelIndex_Array[1] == -1 {
            
            var temp: Step3_Info = Step3_Info(id: -1, nombre: "No se encontraron resultados, por favor seleccione otros criterios de búsqueda")
            g_Step_3_Array.append(temp)
            
            return
        }
        
        let params: NSDictionary = ["locationID" : g_Step_2_Array[g_Step_SelIndex_Array[1]].id]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.step3_ESPESIALIDAD, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                for data in responseObject! {
                    //print(data)
                    
                    let dict = data as! [String: AnyObject]
                    
                    var temp: Step3_Info = Step3_Info(id: -1, nombre: "")
                    temp.id = dict["id"] as! Int
                    temp.nombre = dict["nombre"] as! String
                    
                    if temp.nombre != "" {
                        g_Step_3_Array.append(temp)
                    }
                    
                }
                
                if g_Step_3_Array.count == 0 {
                    
                    var temp: Step3_Info = Step3_Info(id: -1, nombre: "No se encontraron resultados, por favor seleccione otros criterios de búsqueda")
                    g_Step_3_Array.append(temp)
                } else {
                    print(g_Step_3_Array[0])
                }
                
                self.tableView.reloadData()
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    
    
    
    //step4 - INSTITUTO ----------------------------------------------------------------------------------------
    //17. http://67.205.136.161:8070/DocAppointments/rest/location/hospitalsperspeciality
    func tryStep4_INSTITUTO() {
        
        if g_Step_SelIndex_Array[2] == -1 {
            
            var temp: Step4_Info = Step4_Info(id: -1, nombre: "No se encontraron resultados, por favor seleccione otros criterios de búsqueda", direccion: "", telefono: "-1", email: "", estado: -1, locationID: -1)
            g_Step_4_Array.append(temp)
            
            return
        }
        
        let params: NSDictionary = ["specialtyID": g_Step_3_Array[g_Step_SelIndex_Array[2]].id, "locationID" : g_Step_2_Array[g_Step_SelIndex_Array[1]].id]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.step4_INSTITUTO, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                for data in responseObject! {
                    //print(data)
                    
                    let dict = data as! [String: AnyObject]
                    
                    var temp: Step4_Info = Step4_Info(id: -1, nombre: "", direccion: "", telefono: "-1", email: "", estado: -1, locationID: -1)
                    temp.id = dict["id"] as! Int
                    temp.nombre = dict["nombre"] as! String
                    temp.direccion = dict["direccion"] as! String
                    temp.telefono = dict["telefono"] as! String
                    temp.email = dict["email"] as! String
                    temp.estado = dict["estado"] as! Int
                    temp.locationID = dict["locationID"] as! Int
                    
                    if temp.nombre != "" {
                        g_Step_4_Array.append(temp)
                    }
                    
                }
                
                
                if g_Step_4_Array.count == 0 {
                    
                    var temp: Step4_Info = Step4_Info(id: -1, nombre: "No se encontraron resultados, por favor seleccione otros criterios de búsqueda", direccion: "", telefono: "-1", email: "", estado: -1, locationID: -1)
                    g_Step_4_Array.append(temp)
                } else {
                    print(g_Step_4_Array[0])
                }
                
                self.tableView.reloadData()
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    //step5 - ESPECIALISTA --------------------------------------------------------------------------------------
    //5. http://67.205.136.161:8070/DocAppointments/rest/doctor/byinstitutionandspecialty
    func tryStep5_ESPECIALISTA() {
        
        if g_Step_SelIndex_Array[3] == -1 {
            
            var temp_specialty = specialty_Info(id: -1, nombre: "No se encontraron resultados, por favor seleccione otros criterios de búsqueda")
            var temp_information = information_Info(nombre:           "",
                                                    apellido:         "",
                                                    dni:              "",
                                                    sexo:             -1,
                                                    fechaNacimiento:  "",
                                                    telefono:         "",
                                                    celular:          "",
                                                    email:            "",
                                                    estado:           -1,
                                                    numObraSocial:    "",
                                                    googleUserId:     "",
                                                    hospitalID:       -1,
                                                    provinceID:       -1,
                                                    obraSocialInfo:   "",
                                                    personType:       "",
                                                    patientID:        "",
                                                    doctorID:         -1,
                                                    assistantID:      "",
                                                    locationID:       -1,
                                                    personID:         -1)
            var temp: Step5_Info = Step5_Info(specialty: temp_specialty, doctorID: -1, information: temp_information)
            g_Step_5_Array.append(temp)
            
            return
        }
        
        let params: NSDictionary = ["authorization":
            ["patientID": 1,
             "loginPolicy": "USRPASSWD",
             "eml": "juanperez@gmail.com",
             "psswd":"Prueba123"],
                                    "specialtyID": g_Step_3_Array[g_Step_SelIndex_Array[2]].id,
                                    "hospitalID" : g_Step_4_Array[g_Step_SelIndex_Array[3]].id]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.step5_ESPECIALISTA, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                for data in responseObject! {
                    //print(data)
                    
                    let dict = data as! [String: AnyObject]
                    
                    var temp_specialty = specialty_Info(id: -1, nombre: "No se encontraron resultados, por favor seleccione otros criterios de búsqueda")
                    var temp_information = information_Info(nombre:           "",
                                                            apellido:         "",
                                                            dni:              "",
                                                            sexo:             -1,
                                                            fechaNacimiento:  "",
                                                            telefono:         "",
                                                            celular:          "",
                                                            email:            "",
                                                            estado:           -1,
                                                            numObraSocial:    "",
                                                            googleUserId:     "",
                                                            hospitalID:       -1,
                                                            provinceID:       -1,
                                                            obraSocialInfo:   "",
                                                            personType:       "",
                                                            patientID:        "",
                                                            doctorID:         -1,
                                                            assistantID:      "",
                                                            locationID:       -1,
                                                            personID:         -1)
                    var temp: Step5_Info = Step5_Info(specialty: temp_specialty, doctorID: -1, information: temp_information)
                    
                    let dict_1 = dict["specialty"] as! NSDictionary
                    temp.specialty.id = dict_1["id"] as! Int
                    temp.specialty.nombre = dict_1["nombre"] as! String
                    
                    temp.doctorID = dict["doctorID"] as! Int
                    
                    let dict_2 = dict["information"] as! NSDictionary
                    temp.information.nombre = dict_2["nombre"] as! String
                    temp.information.apellido = dict_2["apellido"] as! String
                    temp.information.dni = dict_2["dni"] as! String
                    temp.information.sexo = dict_2["sexo"] as! Int
                    temp.information.fechaNacimiento = dict_2["fechaNacimiento"] as! String
                    temp.information.telefono = dict_2["telefono"] as! String
                    temp.information.celular = dict_2["celular"] as! String
                    temp.information.email = dict_2["email"] as! String
                    temp.information.estado = dict_2["estado"] as! Int
                    
                    
                    //temp.information.numObraSocial = dict_2["numObraSocial"]
                    if let numObraSocial = dict["numObraSocial"] as? String
                    {
                        temp.information.numObraSocial = numObraSocial
                    }
                    else {
                        temp.information.numObraSocial = "" //"null"
                    }
                    
                    //temp.information.googleUserId = dict_2["googleUserId"] as! String
                    if let googleUserId = dict["googleUserId"] as? String
                    {
                        temp.information.googleUserId = googleUserId
                    }
                    else {
                        temp.information.googleUserId = "" //"null"
                    }
                    
                    temp.information.hospitalID = dict_2["hospitalID"] as! Int
                    temp.information.provinceID = dict_2["provinceID"] as! Int
                    
                    //temp.information.obraSocialInfo = dict_2["obraSocialInfo"] as! String
                    if let obraSocialInfo = dict["obraSocialInfo"] as? String
                    {
                        temp.information.obraSocialInfo = obraSocialInfo
                    }
                    else {
                        temp.information.obraSocialInfo = "" //"null"
                    }
                    
                    temp.information.personType = dict_2["personType"] as! String
                    
                    //temp.information.patientID = dict_2["patientID"] as! String
                    if let patientID = dict["patientID"] as? String
                    {
                        temp.information.patientID = patientID
                    }
                    else {
                        temp.information.patientID = "" //"null"
                    }
                    
                    
                    temp.information.doctorID = dict_2["doctorID"] as! Int
                    
                    //temp.information.assistantID = dict_2["assistantID"] as! String
                    if let assistantID = dict["assistantID"] as? String
                    {
                        temp.information.assistantID = assistantID
                    }
                    else {
                        temp.information.assistantID = "" //"null"
                    }
                    
                    temp.information.locationID = dict_2["locationID"] as! Int
                    temp.information.personID = dict_2["personID"] as! Int
                    
                    if  temp.specialty.nombre != "" {
                        g_Step_5_Array.append(temp)
                    }
                    
                }
                
                if g_Step_5_Array.count == 0 {
                    
                    var temp_specialty = specialty_Info(id: -1, nombre: "No se encontraron resultados, por favor seleccione otros criterios de búsqueda")
                    var temp_information = information_Info(nombre:           "",
                                                            apellido:         "",
                                                            dni:              "",
                                                            sexo:             -1,
                                                            fechaNacimiento:  "",
                                                            telefono:         "",
                                                            celular:          "",
                                                            email:            "",
                                                            estado:           -1,
                                                            numObraSocial:    "",
                                                            googleUserId:     "",
                                                            hospitalID:       -1,
                                                            provinceID:       -1,
                                                            obraSocialInfo:   "",
                                                            personType:       "",
                                                            patientID:        "",
                                                            doctorID:         -1,
                                                            assistantID:      "",
                                                            locationID:       -1,
                                                            personID:         -1)
                    var temp: Step5_Info = Step5_Info(specialty: temp_specialty, doctorID: -1, information: temp_information)
                    g_Step_5_Array.append(temp)
                } else {
                    print(g_Step_5_Array[0])
                }
                
                self.tableView.reloadData()
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    func handleRefresh(sender:AnyObject) {
        
        switch g_Step_CurSel_Int  {
            
        case 1:
            g_Step_1_Array.removeAll()
            g_Step_2_Array.removeAll()
            g_Step_3_Array.removeAll()
            g_Step_4_Array.removeAll()
            g_Step_5_Array.removeAll()
            g_Step_SelIndex_Array  = [-1, -1, -1, -1, -1]
            
            tryStep1_PROVICIA()
            
        case 2:
            g_Step_2_Array.removeAll()
            g_Step_3_Array.removeAll()
            g_Step_4_Array.removeAll()
            g_Step_5_Array.removeAll()
            g_Step_SelIndex_Array  = [g_Step_SelIndex_Array[0], -1, -1, -1, -1]
            
            tryStep2_CIUDAD()
            
        case 3:
            g_Step_3_Array.removeAll()
            g_Step_4_Array.removeAll()
            g_Step_5_Array.removeAll()
            g_Step_SelIndex_Array  = [g_Step_SelIndex_Array[0], g_Step_SelIndex_Array[1], -1, -1, -1]
            
            tryStep3_ESPESIALIDAD()
            
        case 4:
            g_Step_4_Array.removeAll()
            g_Step_5_Array.removeAll()
            g_Step_SelIndex_Array  = [g_Step_SelIndex_Array[0], g_Step_SelIndex_Array[1], g_Step_SelIndex_Array[2], -1, -1]
            
            tryStep4_INSTITUTO()
            
        case 5:
            g_Step_5_Array.removeAll()
            g_Step_SelIndex_Array  = [g_Step_SelIndex_Array[0], g_Step_SelIndex_Array[1], g_Step_SelIndex_Array[2], g_Step_SelIndex_Array[3], -1]
            
            tryStep5_ESPECIALISTA()
        default: print(g_Step_CurSel_Int)
        }
        
        if CheckConfirm() {
            
            BTNBottomConfirm.isEnabled = true
        } else {
            
            BTNBottomConfirm.isEnabled = false
        }
        
        refreshControl.endRefreshing()
        tableView.reloadData()
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    //=========================================================================================
    //
    //  Table Delegates
    //
    //=========================================================================================
    
    func initView() {
        tableView.reloadData()
    }
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var ReturnCnt: Int = 0
        switch g_Step_CurSel_Int  {
            
        case 1: ReturnCnt = g_Step_1_Array.count
        case 2: ReturnCnt = g_Step_2_Array.count
        case 3: ReturnCnt = g_Step_3_Array.count
        case 4: ReturnCnt = g_Step_4_Array.count
        case 5: ReturnCnt = g_Step_5_Array.count
            
        default: print(g_Step_CurSel_Int)
        }
        
        return ReturnCnt
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "StepSearchTableCell") as? StepSearchTableCell
        
        switch g_Step_CurSel_Int  {
            
        case 1: cell?.TxtLabel.text    = g_Step_1_Array[indexPath.row].nombre
        case 2: cell?.TxtLabel.text    = g_Step_2_Array[indexPath.row].nombre
        case 3: cell?.TxtLabel.text    = g_Step_3_Array[indexPath.row].nombre
        case 4: cell?.TxtLabel.text    = g_Step_4_Array[indexPath.row].nombre
        case 5: cell?.TxtLabel.text    = g_Step_5_Array[indexPath.row].information.nombre + " " + g_Step_5_Array[indexPath.row].information.apellido
            
        default: print(g_Step_CurSel_Int)
        }
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: IndexPath(row: indexPath.row, section: 0)) as? StepSearchTableCell
        
        switch g_Step_CurSel_Int  {
            
        case 1:
            g_Step_SelIndex_Array[g_Step_CurSel_Int - 1] = indexPath.row
            print(g_Step_SelIndex_Array[g_Step_CurSel_Int - 1])
            onTappedNo2Button(self)
            
        case 2:
            g_Step_SelIndex_Array[g_Step_CurSel_Int - 1] = indexPath.row
            print(g_Step_SelIndex_Array[g_Step_CurSel_Int - 1])
            onTappedNo3Button(self)
            
        case 3:
            g_Step_SelIndex_Array[g_Step_CurSel_Int - 1] = indexPath.row
            print(g_Step_SelIndex_Array[g_Step_CurSel_Int - 1])
            onTappedNo4Button(self)
            
        case 4:
            g_Step_SelIndex_Array[g_Step_CurSel_Int - 1] = indexPath.row
            print(g_Step_SelIndex_Array[g_Step_CurSel_Int - 1])
            onTappedNo5Button(self)
            
        case 5:
            g_Step_SelIndex_Array[g_Step_CurSel_Int - 1] = indexPath.row
            print(g_Step_SelIndex_Array[g_Step_CurSel_Int - 1])
            
            if CheckConfirm() {
                
                self.performSegue(withIdentifier: StorySegues.FormStepSearchToConfirm.rawValue, sender: self)
            }
            
        default: print(g_Step_CurSel_Int)
        }
        
        if CheckConfirm() {
            
            BTNBottomConfirm.isEnabled = true
        } else {
            
            BTNBottomConfirm.isEnabled = false
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, didHighlightRowAt indexPath: IndexPath) {
        let cell  = tableView.cellForRow(at: indexPath)
        cell!.contentView.backgroundColor = UIColor(red: 50.0/255.0, green: 135.0/255.0, blue: 235.0/255.0, alpha: 1.0)
    }
    
    func tableView(_ tableView: UITableView, didUnhighlightRowAt indexPath: IndexPath) {
        let cell  = tableView.cellForRow(at: indexPath)
        cell!.contentView.backgroundColor = .clear
    }
    
    
    
    //Step Buttons
    @IBAction func onTappedNo1Button(_ sender: Any) {
        
        g_Step_CurSel_Int = 1
        
        BTNBottomConfirm.setTitle("PROVINCIA", for: .normal)
        ChangeColorStep()
        
        handleRefresh(sender: self)
        tableView.reloadData()
        
    }
    
    @IBAction func onTappedNo2Button(_ sender: Any) {
        
        g_Step_CurSel_Int = 2
        
        BTNBottomConfirm.setTitle("CIUDAD", for: .normal)
        ChangeColorStep()
        
        handleRefresh(sender: self)
        tableView.reloadData()
        
    }
    
    @IBAction func onTappedNo3Button(_ sender: Any) {
        
        g_Step_CurSel_Int = 3
        
        BTNBottomConfirm.setTitle("ESPECIALIDAD", for: .normal)
        ChangeColorStep()
        
        handleRefresh(sender: self)
        tableView.reloadData()
    }
    
    @IBAction func onTappedNo4Button(_ sender: Any) {
        
        g_Step_CurSel_Int = 4
        
        BTNBottomConfirm.setTitle("INSTITUCION", for: .normal)
        ChangeColorStep()
        
        handleRefresh(sender: self)
        tableView.reloadData()
    }
    
    @IBAction func onTappedNo5Button(_ sender: Any) {
        
        g_Step_CurSel_Int = 5
        
        BTNBottomConfirm.setTitle("PROFESIONAL", for: .normal)
        ChangeColorStep()
        
        handleRefresh(sender: self)
        tableView.reloadData()
    }
    
    @IBAction func onTappedStepConfirmButton(_ sender: Any) {
        
        if CheckConfirm() {
            
            self.performSegue(withIdentifier: StorySegues.FormStepSearchToConfirm.rawValue, sender: self)
        }
    }
    
    func CheckConfirm() -> Bool {
        
        var Flag: Bool = true
        
        for i in 0 ..< 5 {
            
            if g_Step_SelIndex_Array[i] == -1 {
                Flag = false
            }
        }
        return Flag
    }
    
    
    
    func ChangeColorStep() {
        
        switch g_Step_CurSel_Int  {
            
        case 1:
            BTNStepNo1.setTitleColor(UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo1.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208/255.0, alpha: 1.0)
            
            BTNStepNo2.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo2.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo3.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo3.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo4.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo4.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo5.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo5.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            
        case 2:
            BTNStepNo2.setTitleColor(UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo2.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208/255.0, alpha: 1.0)
            
            BTNStepNo1.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo1.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo3.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo3.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo4.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo4.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo5.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo5.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
        case 3:
            BTNStepNo3.setTitleColor(UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo3.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208/255.0, alpha: 1.0)
            
            BTNStepNo2.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo2.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo1.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo1.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo4.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo4.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo5.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo5.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
        case 4:
            BTNStepNo4.setTitleColor(UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo4.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208/255.0, alpha: 1.0)
            
            BTNStepNo2.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo2.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo3.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo3.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo1.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo1.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo5.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo5.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
        case 5:
            BTNStepNo5.setTitleColor(UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo5.backgroundColor = UIColor(red: 50.0/255.0, green: 186.0/255.0, blue: 208/255.0, alpha: 1.0)
            
            BTNStepNo2.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo2.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo3.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo3.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo4.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo4.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
            BTNStepNo1.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0), for: UIControlState.normal)
            VIEWStepNo1.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170/255.0, alpha: 1.0)
            
        default: print(g_Step_CurSel_Int)
        }
    }
}
