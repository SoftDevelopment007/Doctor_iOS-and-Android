//
//  SearchDiaryViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/25/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation

import UIKit
import Toast_Swift

class SearchDiaryViewController: UIViewController {

    let GlobalVar = Global()
    
    @IBOutlet weak var TxtLabelDate: UILabel!
    @IBOutlet weak var myDatePicker: UIDatePicker!
    
    @IBOutlet weak var ViewAM: UIView!
    @IBOutlet weak var ViewPM: UIView!
    
    
    @IBOutlet weak var Image1: UIImageView!
    @IBOutlet weak var Image2: UIImageView!
    @IBOutlet weak var Image3: UIImageView!
    @IBOutlet weak var Image4: UIImageView!
    @IBOutlet weak var Image5: UIImageView!
    @IBOutlet weak var Image6: UIImageView!
    @IBOutlet weak var Image7: UIImageView!
    @IBOutlet weak var Image8: UIImageView!
    @IBOutlet weak var Image9: UIImageView!
    @IBOutlet weak var Image10: UIImageView!
    @IBOutlet weak var Image11: UIImageView!
    @IBOutlet weak var Image12: UIImageView!
    
    @IBOutlet weak var LabelTime1: UILabel!
    @IBOutlet weak var LabelTime2: UILabel!
    @IBOutlet weak var LabelTime3: UILabel!
    @IBOutlet weak var LabelTime4: UILabel!
    @IBOutlet weak var LabelTime5: UILabel!
    @IBOutlet weak var LabelTime6: UILabel!
    @IBOutlet weak var LabelTime7: UILabel!
    @IBOutlet weak var LabelTime8: UILabel!
    @IBOutlet weak var LabelTime9: UILabel!
    @IBOutlet weak var LabelTime10: UILabel!
    @IBOutlet weak var LabelTime11: UILabel!
    @IBOutlet weak var LabelTime12: UILabel!
    
    @IBOutlet weak var ButtonSet1: UIButton!
    @IBOutlet weak var ButtonSet2: UIButton!
    @IBOutlet weak var ButtonSet3: UIButton!
    @IBOutlet weak var ButtonSet4: UIButton!
    @IBOutlet weak var ButtonSet5: UIButton!
    @IBOutlet weak var ButtonSet6: UIButton!
    @IBOutlet weak var ButtonSet7: UIButton!
    @IBOutlet weak var ButtonSet8: UIButton!
    @IBOutlet weak var ButtonSet9: UIButton!
    @IBOutlet weak var ButtonSet10: UIButton!
    @IBOutlet weak var ButtonSet11: UIButton!
    @IBOutlet weak var ButtonSet12: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        myDatePicker.setValue(UIColor.white, forKeyPath: "textColor")
        
        datePickerAction(self)
        
        onTappedAMButton(self)
        
        //g_Diary_Date = ""
        g_Diary_Time = ""
    }

    override func viewWillAppear(_ animated: Bool) {
        //g_Diary_Date = ""
        g_Diary_Time = ""
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
   

    @IBAction func datePickerAction(_ sender: AnyObject) {
        
        //Today
        let date = Date()
        let calendar_1 = Calendar.current
        let components = calendar_1.dateComponents([.year, .month, .day], from: date)
        
        let year_1 =  components.year
        let month_1 = components.month
        let day_1 = components.day
        
        // Today to 01/01/2020
        let calendar = Calendar.current
        var minDateComponent = calendar.dateComponents([.day,.month,.year], from: Date())
        /*minDateComponent.day = day_1
        minDateComponent.month = month_1
        minDateComponent.year = year_1*/
        minDateComponent.day = 01
        minDateComponent.month = 01
        minDateComponent.year = 1980
        
        let minDate = calendar.date(from: minDateComponent)
        print(" min date : \(minDate)")
        
        var maxDateComponent = calendar.dateComponents([.day,.month,.year], from: Date())
        maxDateComponent.day = 01
        maxDateComponent.month = 01
        maxDateComponent.year = 2050
        
        let maxDate = calendar.date(from: maxDateComponent)
        print("max date : \(maxDate)")
        
        self.myDatePicker.minimumDate = minDate! as Date
        self.myDatePicker.maximumDate =  maxDate! as Date
        
        
        //Set Date
        myDatePicker.datePickerMode = .date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let selectedDate = dateFormatter.string(from: myDatePicker.date)
        
        
        //===================================================================
        //
        //
        g_NotificationDate_beforeDay = myDatePicker.date
        g_NotificationDate_Today = g_NotificationDate_beforeDay
        
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: g_NotificationDate_beforeDay)
        g_NotificationDate_beforeDay = yesterday!
        //
        //
        //===================================================================
        
        
        print(selectedDate)
        
        //===================================================================
        //here it is  necessary Roading Time Schedules.
        self.TxtLabelDate.text = selectedDate
        g_Diary_Date = selectedDate
        
        if g_RegisteredFlag {
//            tryGetSchedules()     //  <- Enable and dissbale other controlles.
        }
        
        //test Code - No, As unauthentication user, can see doctor shedules.
        tryGetSchedules()         //  <- Enable and dissbale other controlles. -----------------------------------------
        //===================================================================
        
        
    }

    func Init() {
        ViewAM.backgroundColor = UIColor.white
        ViewPM.backgroundColor = UIColor(red: 92.0/255.0, green: 94.0/255.0, blue: 102/255.0, alpha: 1.0)
        
        //5_TimeSet_Off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime1.text = "06:00";      ButtonSet1.isEnabled = true
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime2.text = "06:30";      ButtonSet2.isEnabled = true
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime3.text = "07:00";      ButtonSet3.isEnabled = true
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime4.text = "07:30";      ButtonSet4.isEnabled = true
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime5.text = "08:00";      ButtonSet5.isEnabled = true
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime6.text = "08:30";      ButtonSet6.isEnabled = true
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime7.text = "09:00";      ButtonSet7.isEnabled = true
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime8.text = "09:30";      ButtonSet8.isEnabled = true
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime9.text = "10:00";      ButtonSet9.isEnabled = true
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");   LabelTime10.text = "10:30";      ButtonSet10.isEnabled = true
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");   LabelTime11.text = "11:00";      ButtonSet11.isEnabled = true
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");   LabelTime12.text = "11:30";      ButtonSet12.isEnabled = true
        
        LabelTime1.textColor = UIColor.white
        LabelTime2.textColor = UIColor.white
        LabelTime3.textColor = UIColor.white
        LabelTime4.textColor = UIColor.white
        LabelTime5.textColor = UIColor.white
        LabelTime6.textColor = UIColor.white
        LabelTime7.textColor = UIColor.white
        LabelTime8.textColor = UIColor.white
        LabelTime9.textColor = UIColor.white
        LabelTime10.textColor = UIColor.white
        LabelTime11.textColor = UIColor.white
        LabelTime12.textColor = UIColor.white
    }
    
    
    @IBAction func onTappedAMButton(_ sender: Any) {
        
        ViewAM.backgroundColor = UIColor.white
        ViewPM.backgroundColor = UIColor(red: 92.0/255.0, green: 94.0/255.0, blue: 102.0/255.0, alpha: 1.0)

        //5_TimeSet_Off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime1.text = "06:00";      ButtonSet1.isEnabled = true
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime2.text = "06:30";      ButtonSet2.isEnabled = true
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime3.text = "07:00";      ButtonSet3.isEnabled = true
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime4.text = "07:30";      ButtonSet4.isEnabled = true
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime5.text = "08:00";      ButtonSet5.isEnabled = true
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime6.text = "08:30";      ButtonSet6.isEnabled = true
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime7.text = "09:00";      ButtonSet7.isEnabled = true
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime8.text = "09:30";      ButtonSet8.isEnabled = true
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime9.text = "10:00";      ButtonSet9.isEnabled = true
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");   LabelTime10.text = "10:30";      ButtonSet10.isEnabled = true
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");   LabelTime11.text = "11:00";      ButtonSet11.isEnabled = true
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");   LabelTime12.text = "11:30";      ButtonSet12.isEnabled = true
        
        LabelTime1.textColor = UIColor.white
        LabelTime2.textColor = UIColor.white
        LabelTime3.textColor = UIColor.white
        LabelTime4.textColor = UIColor.white
        LabelTime5.textColor = UIColor.white
        LabelTime6.textColor = UIColor.white
        LabelTime7.textColor = UIColor.white
        LabelTime8.textColor = UIColor.white
        LabelTime9.textColor = UIColor.white
        LabelTime10.textColor = UIColor.white
        LabelTime11.textColor = UIColor.white
        LabelTime12.textColor = UIColor.white
        
        CheckActiveTime()
        
    }
    
    @IBAction func onTappedPMButton(_ sender: Any) {
        
        ViewAM.backgroundColor = UIColor(red: 92.0/255.0, green: 94.0/255.0, blue: 102.0/255.0, alpha: 1.0)
        ViewPM.backgroundColor = UIColor.white
        
        //5_TimeSet_Off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime1.text = "14:00";      ButtonSet1.isEnabled = true
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime2.text = "14:30";      ButtonSet2.isEnabled = true
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime3.text = "15:00";      ButtonSet3.isEnabled = true
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime4.text = "15:30";      ButtonSet4.isEnabled = true
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime5.text = "16:00";      ButtonSet5.isEnabled = true
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime6.text = "16:30";      ButtonSet6.isEnabled = true
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime7.text = "17:00";      ButtonSet7.isEnabled = true
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime8.text = "17:30";      ButtonSet8.isEnabled = true
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");    LabelTime9.text = "18:00";      ButtonSet9.isEnabled = true
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");   LabelTime10.text = "18:30";      ButtonSet10.isEnabled = true
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");   LabelTime11.text = "19:00";      ButtonSet11.isEnabled = true
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png");   LabelTime12.text = "19:30";      ButtonSet12.isEnabled = true
        
        LabelTime1.textColor = UIColor.white
        LabelTime2.textColor = UIColor.white
        LabelTime3.textColor = UIColor.white
        LabelTime4.textColor = UIColor.white
        LabelTime5.textColor = UIColor.white
        LabelTime6.textColor = UIColor.white
        LabelTime7.textColor = UIColor.white
        LabelTime8.textColor = UIColor.white
        LabelTime9.textColor = UIColor.white
        LabelTime10.textColor = UIColor.white
        LabelTime11.textColor = UIColor.white
        LabelTime12.textColor = UIColor.white
        
        CheckActiveTime()
    }
    
    @IBAction func onTappedButton1(_ sender: Any) {
        
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime1.text! + " AM"
        } else {
            g_Diary_Time = LabelTime1.text! + " PM"
        }
        
        g_Diary_Time_Start = LabelTime1.text! + ":00"
        g_Diary_Time_End = LabelTime2.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
        
    }
    
    @IBAction func onTappedButton2(_ sender: Any) {
        
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime2.text! + " AM"
        } else {
            g_Diary_Time = LabelTime2.text! + " PM"
        }
        g_Diary_Time_Start = LabelTime2.text! + ":00"
        g_Diary_Time_End = LabelTime3.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedButton3(_ sender: Any) {
        
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime3.text! + " AM"
        } else {
            g_Diary_Time = LabelTime3.text! + " PM"
        }
        g_Diary_Time_Start = LabelTime3.text! + ":00"
        g_Diary_Time_End = LabelTime4.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedButton4(_ sender: Any) {
        
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime4.text! + " AM"
        } else {
            g_Diary_Time = LabelTime4.text! + " PM"
        }
        g_Diary_Time_Start = LabelTime4.text! + ":00"
        g_Diary_Time_End = LabelTime5.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedButton5(_ sender: Any) {
        
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime5.text! + " AM"
        } else {
            g_Diary_Time = LabelTime5.text! + " PM"
        }
        g_Diary_Time_Start = LabelTime5.text! + ":00"
        g_Diary_Time_End = LabelTime6.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedButton6(_ sender: Any) {
        
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime6.text! + " AM"
        } else {
            g_Diary_Time = LabelTime6.text! + " PM"
        }
        g_Diary_Time_Start = LabelTime6.text! + ":00"
        g_Diary_Time_End = LabelTime7.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedButton7(_ sender: Any) {
        
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime7.text! + " AM"
        } else {
            g_Diary_Time = LabelTime7.text! + " PM"
        }
        g_Diary_Time_Start = LabelTime7.text! + ":00"
        g_Diary_Time_End = LabelTime8.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedButton8(_ sender: Any) {
        
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime8.text! + " AM"
        } else {
            g_Diary_Time = LabelTime8.text! + " PM"
        }
        g_Diary_Time_Start = LabelTime8.text! + ":00"
        g_Diary_Time_End = LabelTime9.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedButton9(_ sender: Any) {
        
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime9.text! + " AM"
        } else {
            g_Diary_Time = LabelTime9.text! + " PM"
        }
        g_Diary_Time_Start = LabelTime9.text! + ":00"
        g_Diary_Time_End = LabelTime10.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedButton10(_ sender: Any) {
        
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime10.text! + " AM"
        } else {
            g_Diary_Time = LabelTime10.text! + " PM"
        }
        g_Diary_Time_Start = LabelTime10.text! + ":00"
        g_Diary_Time_End = LabelTime11.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedButton11(_ sender: Any) {
        
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime11.text! + " AM"
        } else {
            g_Diary_Time = LabelTime11.text! + " PM"
        }
        g_Diary_Time_Start = LabelTime11.text! + ":00"
        g_Diary_Time_End = LabelTime12.text! + ":00"
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedButton12(_ sender: Any) {
        
        Image12.image = #imageLiteral(resourceName: "5_TimeSet_On.png")  //on
        Image2.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image3.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image4.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image5.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image6.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image7.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image8.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image9.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image10.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image11.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        Image1.image = #imageLiteral(resourceName: "5_TimeSet_Off.png")  //off
        
        if ViewAM.backgroundColor == UIColor.white {
            g_Diary_Time = LabelTime12.text! + " AM"
            g_Diary_Time_Start = LabelTime12.text! + ":00"
            g_Diary_Time_End = "12:00:00"
        } else {
            g_Diary_Time = LabelTime12.text! + " PM"
            g_Diary_Time_Start = LabelTime12.text! + ":00"
            g_Diary_Time_End = "20:00:00"
        }
        
        CheckActiveTime()
        DayCheck()
    }
    
    @IBAction func onTappedConfirmButton(_ sender: Any) {
        
        if g_Diary_Date == "" || g_Diary_Time == "" {
            
            self.view.makeToast("Pease Select Date and Time.")
            return
        } else {
            
//            let Arr : [String] = g_Diary_Time_Start.components(separatedBy: " ")
//            g_Diary_Time_Start = Arr[0]
         
            
            var ODate:NSDate = NSDate()
            
            let dateFormatter0 = DateFormatter()
            dateFormatter0.dateFormat = "dd-MM-yyyy"
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy HH:mm:ss"        //"yyyy-MM-dd HH:mm:ss ZZZ"
            
            
            let currentDate = dateFormatter.string(from: ODate as Date)
            let currentDate0 = dateFormatter0.string(from: ODate as Date)
            let TodayDate = dateFormatter.date(from: currentDate) //according to date format your date string
            print(TodayDate ?? "") //Convert String to Date
            
            let str_DateTime = g_Diary_Date + " " + g_Diary_Time_Start   //"29-06-2017 10:00:00"
            let date_DateTime = dateFormatter.date(from: str_DateTime)
            let date_aDayafterTomorrow = dateFormatter.date(from: "\(currentDate0) 23:30:00")
            
            if date_DateTime! < TodayDate! {
                self.view.makeToast("No puede reservar turno con fechas anteriores o del dia actual. elija otra fecha.", duration: 3.0, position: .bottom)
            } else {
                if date_DateTime! > (date_aDayafterTomorrow?.addingTimeInterval(172800))! {
                    self.view.makeToast("Puede seleccionar para mañana o después de mañana.", duration: 3.0, position: .bottom)
                } else {
                    self.performSegue(withIdentifier: StorySegues.FromSearchDiaryToConfirmacion.rawValue, sender: self)
                }
            }
        }
    }
    
    func DayCheck() {
        var ODate:NSDate = NSDate()
        
        let dateFormatter0 = DateFormatter()
        dateFormatter0.dateFormat = "dd-MM-yyyy"
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm:ss"        //"yyyy-MM-dd HH:mm:ss ZZZ"
        
        
        let currentDate = dateFormatter.string(from: ODate as Date)
        let currentDate0 = dateFormatter0.string(from: ODate as Date)
        let TodayDate = dateFormatter.date(from: currentDate) //according to date format your date string
        print(TodayDate ?? "") //Convert String to Date
        
        let str_DateTime = g_Diary_Date + " " + g_Diary_Time_Start   //"29-06-2017 10:00:00"
        let date_DateTime = dateFormatter.date(from: str_DateTime)
        let date_aDayafterTomorrow = dateFormatter.date(from: "\(currentDate0) 23:30:00")
        
        if date_DateTime! < TodayDate! {
            self.view.makeToast("No puede reservar turno con fechas anteriores o del dia actual. elija otra fecha.", duration: 2.0, position: .bottom)
            g_Diary_Time = ""
            
        } else {
            if date_DateTime! > (date_aDayafterTomorrow?.addingTimeInterval(172800))! {
                self.view.makeToast("Puede seleccionar para mañana o después de mañana.", duration: 2.0, position: .bottom)
                g_Diary_Time = ""
                
            } else {
                
            }
        }
    }
    
    // Get Schedules  -----------------------------------------------------------------------------------------------
    // 5. http://67.205.136.161:8070/DocAppointments/rest/doctor/schedules
    func tryGetSchedules() {
        
        g_Doctor_Schedules.removeAll()
        
        
        var params: NSDictionary = ["doctorID": "",
                                    "hospitalID": "",
                                    "appointmentDateStart": self.TxtLabelDate.text,     //"15-06-2017",
                                    "appointmentDateEnd": self.TxtLabelDate.text        //"15-06-2017"
                                    ]
        
        if g_bool_byFavarite == true {
            params = [  "doctorID": g_favarite_Doctors_Array[g_Current_Index].doctorID,
                                    //g_Step_5_Array[g_Step_SelIndex_Array[4]].information.doctorID,
                        "hospitalID": g_favarite_Doctors_Array[g_Current_Index].hospital_id,
                                    // g_Step_5_Array[g_Step_SelIndex_Array[4]].information.hospitalID,
                        "appointmentDateStart": self.TxtLabelDate.text,     //"15-06-2017",
                        "appointmentDateEnd": self.TxtLabelDate.text        //"15-06-2017"
                        ]
        } else {
            params = [  "doctorID": g_Step_5_Array[g_Step_SelIndex_Array[4]].information.doctorID,
                        "hospitalID": g_Step_5_Array[g_Step_SelIndex_Array[4]].information.hospitalID,
                        "appointmentDateStart": self.TxtLabelDate.text,     //"15-06-2017",
                        "appointmentDateEnd": self.TxtLabelDate.text        //"15-06-2017"
                     ]
        }
        
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue_NSDictionary(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Get_Schedules, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                let appointments_dict = responseObject?["appointments"] as! Array<AnyObject>
                
                for data in appointments_dict {
                    print(data)
                    
                    
                    var temp_doctor_Info = doctor_Info(
                        id:           -1,
                        personID:     -1,
                        specialtyID:  -1,
                        assistantID:  -1,
                        lastName:     "",
                        name:         ""
                    )
                    var temp_specialty_Info = specialty_Info(
                        id:            -1,
                        nombre:        ""
                    )
                    var temp_hospital_Info = hospital_Info(
                        id:           -1,
                        nombre:       "",
                        direccion:    "",
                        telefono:     "",
                        email:        "",
                        estado:       -1,
                        locationID:   -1
                    )
                    var temp_Doctor_Schedules_Infor = Doctor_Schedules_Infor(
                        id:           -1,
                        fecha:        "",
                        horaInicio:   "",
                        horaFin:      "",
                        fechaCreacion:"",
                        
                        doctor:       temp_doctor_Info,
                        
                        estado:       -1,
                        hospitalID:   -1,
                        patientID:    -1,
                        doctorID:     -1,
                        
                        specialty:    temp_specialty_Info,
                        
                        hospital:     temp_hospital_Info
                    )
                    
                    let dict = data as! [String: AnyObject]
                    
                    let doctor_dict = dict["doctor"] as! [String: AnyObject]
                    temp_doctor_Info.id = doctor_dict["id"] as! Int
                    temp_doctor_Info.personID = doctor_dict["personID"] as! Int
                    temp_doctor_Info.specialtyID = doctor_dict["specialtyID"] as! Int
                    temp_doctor_Info.assistantID = doctor_dict["assistantID"] as! Int
                    temp_doctor_Info.lastName = doctor_dict["lastName"] as! String
                    temp_doctor_Info.name = doctor_dict["name"] as! String
                    
                    let specialty_dict = dict["specialty"] as! [String: AnyObject]
                    temp_specialty_Info.id = specialty_dict["id"] as! Int
                    temp_specialty_Info.nombre = specialty_dict["nombre"] as! String
                    
                    let hospital_dict = dict["hospital"] as! [String: AnyObject]
                    temp_hospital_Info.id = hospital_dict["id"] as! Int
                    temp_hospital_Info.nombre = hospital_dict["nombre"] as! String
                    temp_hospital_Info.direccion = hospital_dict["direccion"] as! String
                    temp_hospital_Info.telefono = hospital_dict["telefono"] as! String
                    temp_hospital_Info.email = hospital_dict["email"] as! String
                    temp_hospital_Info.estado = hospital_dict["estado"] as! Int
                    temp_hospital_Info.locationID = hospital_dict["locationID"] as! Int
                    
                    //g_Doctor_Schedules
                    
                    var temp: Doctor_Schedules_Infor = Doctor_Schedules_Infor(
                                                                                id:           dict["id"] as! Int,
                                                                                fecha:        dict["fecha"] as! String,
                                                                                horaInicio:   dict["horaInicio"] as! String,
                                                                                horaFin:      dict["horaFin"] as! String,
                                                                                fechaCreacion:dict["fechaCreacion"] as! String,
                                                                                
                                                                                doctor:       temp_doctor_Info,
                                                                                
                                                                                estado:       dict["estado"] as! Int,
                                                                                hospitalID:   dict["hospitalID"] as! Int,
                                                                                patientID:    dict["patientID"] as! Int,
                                                                                doctorID:     dict["doctorID"] as! Int,
                                                                                
                                                                                specialty:    temp_specialty_Info,
                                                                                
                                                                                hospital:     temp_hospital_Info
                                                                            )
                    
                    g_Doctor_Schedules.append(temp)
                }
                
                if g_Doctor_Schedules.count != 0 {
                    print(g_Doctor_Schedules[0])
                    
                    self.Init()
                    self.CheckActiveTime()
                    
                } else {
                    self.Init()
                    //self.view.makeToast("Server is busy now.", duration: 3.0, position: .bottom)
                }
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
     
    func CheckActiveTime() {
 
        for i in 0 ..< g_Doctor_Schedules.count {
            
            if g_Doctor_Schedules[i].horaInicio == (LabelTime1.text! + ":00") {
                Image1.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime1.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet1.isEnabled = false
            }
            if g_Doctor_Schedules[i].horaInicio == (LabelTime2.text! + ":00") {
                Image2.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime2.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet2.isEnabled = false
            }
            if g_Doctor_Schedules[i].horaInicio == (LabelTime3.text! + ":00") {
                Image3.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime3.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet3.isEnabled = false
            }
            if g_Doctor_Schedules[i].horaInicio == (LabelTime4.text! + ":00") {
                Image4.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime4.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet4.isEnabled = false
            }
            
            if g_Doctor_Schedules[i].horaInicio == (LabelTime5.text! + ":00") {
                Image5.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime5.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet5.isEnabled = false
            }
            if g_Doctor_Schedules[i].horaInicio == (LabelTime6.text! + ":00") {
                Image6.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime6.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet6.isEnabled = false
            }
            if g_Doctor_Schedules[i].horaInicio == (LabelTime7.text! + ":00") {
                Image7.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime7.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet7.isEnabled = false
            }
            if g_Doctor_Schedules[i].horaInicio == (LabelTime8.text! + ":00") {
                Image8.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime8.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet8.isEnabled = false
            }
            
            if g_Doctor_Schedules[i].horaInicio == (LabelTime9.text! + ":00") {
                Image9.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime9.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet9.isEnabled = false
            }
            if g_Doctor_Schedules[i].horaInicio == (LabelTime10.text! + ":00") {
                Image10.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime10.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet10.isEnabled = false
            }
            if g_Doctor_Schedules[i].horaInicio == (LabelTime11.text! + ":00") {
                Image11.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime11.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet11.isEnabled = false
            }
            if g_Doctor_Schedules[i].horaInicio == (LabelTime12.text! + ":00") {
                Image12.image = #imageLiteral(resourceName: "5_TimeSet_None.png")    //5_TimeSet_None.png
                LabelTime12.textColor = UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0)
                ButtonSet12.isEnabled = false
            }
            
        }
 
    }

}
