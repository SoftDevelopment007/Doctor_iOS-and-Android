//
//  MyShiftViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/26/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import UIKit

import EventKit
import FSCalendar

var str_selectDate : String = ""
//var date_selectDate: Date!

import Toast_Swift


import GoogleSignIn
import FBSDKCoreKit
import FBSDKLoginKit



class MyShiftViewController: UIViewController, FSCalendarDataSource, FSCalendarDelegate, SideMenuViewDelegate {

    
    @IBOutlet weak var adminsidemenu_btn: UIButton!
    
    
    
    let GlobalVar = Global()
    
    @IBOutlet weak var myCalendar: FSCalendar!
    
    @IBOutlet weak var view_NoneEvent: UIView!
    @IBOutlet weak var view_ExistEvent: UIView!
    
    @IBOutlet weak var Btn_CancelShift: UIButton!
    @IBOutlet weak var view_CheckButton: UIView!
    
    @IBOutlet weak var GradientView: UIView!
    
    @IBOutlet weak var Label_TurnoMedico: UILabel!
    @IBOutlet weak var Label_Dirreccion: UILabel!
    @IBOutlet weak var Label_Horario: UILabel!    
    @IBOutlet weak var Label_Profesional: UILabel!
    
    var TurnoMedicoArray = Array<String>()
    var DirreccionArray = Array<String>()
    var HorarioArray = Array<String>()
    var ProfesionalArray = Array<String>()
    
    var appointmentID = Array<Int>()
    var All_SchedulesID = Array<Int>()
    /////////////////////////////////////////////////////////
    //
    //
    var DataArray = Array<String>()
    //
    //
    /////////////////////////////////////////////////////////
    
    
    
    var datesWithEvent: [NSDate] = []
   
    /*var eventsArray =       [     "10-05-2017",     //"dd-MM-yyyy"
                                  "18-05-2017",
                                  "15-05-2017",
                                  "16-05-2017",
                                  "23-05-2017",
                                  "06-06-2017",
                                  "03-06-2017",
                                  "01-06-2017"
                            ];*/
    var eventsArray = Array<String>()

   
    // Swipe View
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var Swiped_View: UIView!
    
    var viewFlag: Bool = false // None: false, Exist: true
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //
        //Register True
        g_RegisteredFlag = true
        g_bool_byFavarite = false
        
        //Side View
        if self.revealViewController() != nil {
            adminsidemenu_btn.addTarget(self.revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        //
        
        
        
        viewFlag = false
        pageControl.isHidden = true
        view_ExistEvent.isHidden = true
        view_NoneEvent.isHidden = false
        
        view_CheckButton.isHidden = true
        
        
//        let calendar = FSCalendar(frame: CGRect(x: 0, y: 0, width: 320, height: 320))
//        myCalendar.dataSource = self
//        myCalendar.delegate = self
//        view.addSubview(myCalendar)
//        self.myCalendar = calendar
        
        myCalendar.appearance.weekdayTextColor = UIColor.init(red: 128.0/225.0, green: 0.0, blue: 1.0, alpha: 1.0)
        myCalendar.appearance.titleWeekendColor = UIColor.init(red: 200.0/225.0, green: 0.0, blue: 128.0/255.0, alpha: 1.0)
        //calendar.appearance.headerTitleColor = UIColor.red
        myCalendar.appearance.eventColor = UIColor.blue
        //calendar.appearance.selectionColor = UIColor.blue
        myCalendar.appearance.todayColor = UIColor.orange
        //calendar.appearance.todaySelectionColor = UIColor.black
        
        myCalendar.appearance.borderRadius = 1 //0 -> rect type, 1 -> circle type
        
        
        /*var testArray = ["25 Jun, 2016", "30 Jun, 2016", "28 Jun, 2016", "2 Jul, 2016"]
        var eventsArray: [Date] = []
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        for dat in testArray {
            var date = dateFormatter.date(from: dat)
            eventsArray.append(date!)
        }*/
        
        
        
        // Swipe View
        let swiperight = UISwipeGestureRecognizer(target: self, action: #selector(self.getSwipeAction(_:)))
        swiperight.direction = .right
        Swiped_View.addGestureRecognizer(swiperight)
        let swipeleft = UISwipeGestureRecognizer(target: self, action: #selector(self.getSwipeAction(_:)))
        swiperight.direction = .left
        Swiped_View.addGestureRecognizer(swipeleft)
        
        
        //============================================
        
        /*let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy" //"yyyy-MM-dd"
        
        var todaysDate:NSDate = NSDate()
        var todayString: String = dateFormatter.string(from: todaysDate as Date)
        
        str_selectDate = todayString
        
        tryGet_AllSchedules()*/
        
        //============================================
    }
    
    func Init_Today_Set_Event() {
        // Init Hidden Set
        // Today has Some Event now ?
        for data in eventsArray{
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy" //"yyyy-MM-dd"
            
            var todaysDate:NSDate = NSDate()
            var todayString: String = dateFormatter.string(from: todaysDate as Date)
            
            //let dateString = dateFormatter.date(from: data)
            
            if data == todayString {
                viewFlag = true
                pageControl.isHidden = false
                view_ExistEvent.isHidden = false
                view_NoneEvent.isHidden = true
            } else {
                /*viewFlag = false
                 pageControl.isHidden = true
                 view_ExistEvent.isHidden = true
                 view_NoneEvent.isHidden = false*/
            }
        }
    }
    
    
    func getSwipeAction( _ recognizer : UISwipeGestureRecognizer){
        
        if viewFlag == false {
            return
        }
        
        if pageControl.numberOfPages == 0 || pageControl.numberOfPages == 1 {
            return
        }
        var index = (recognizer.direction == .right) ? -1 : 1
        index = (pageControl.currentPage + index < 0) ? pageControl.numberOfPages - 1 : index
        pageControl.currentPage = (pageControl.currentPage + index) % pageControl.numberOfPages
        let direction = (recognizer.direction == .right) ? kCATransitionFromLeft :  kCATransitionFromRight
        animateImageView(direction: direction)
        
        self.Label_TurnoMedico.text = "\(TurnoMedicoArray[pageControl.currentPage])"
        self.Label_Dirreccion.text = "\(DirreccionArray[pageControl.currentPage])"
        self.Label_Horario.text = "\(HorarioArray[pageControl.currentPage])"
        self.Label_Profesional.text = "\(ProfesionalArray[pageControl.currentPage])"
        
    }
    
    func animateImageView(direction: String) {
        CATransaction.begin()
        CATransaction.setAnimationDuration(0.5)
        
        let transition = CATransition()
        transition.type = kCATransitionPush
        transition.subtype = direction
        
        self.Swiped_View.layer.add(transition, forKey: kCATransition)
        
//        let token = self.singleton.token as String
//        let url = "\(GlobalVar.ART_DOWNLOAD_URL)img?url=\(dataArray[pageControl.currentPage].articlePhoto)&token=\(token)"
//        imageLatestPhoto.sd_setImage(with: URL(string: url))
        
        CATransaction.commit()
    }
    
    
    func InitLoad_SwipeDate() {
        
        //dataArray.sort(by: { $0.createdAt > $1.createdAt })
        //self.getPartFiltered()

        if DataArray.count > 4 {
            self.pageControl.numberOfPages = DataArray.count
            
        } else {
            self.pageControl.numberOfPages = DataArray.count
        }
        
        self.updateUI()
    }
    
    func updateUI() {
        pageControl.currentPage = 0
        
        //==============================================================
        // Init Write to all infors
        
        if DataArray.count > 0 {
            //Label_Horario.text = DataArray[pageControl.currentPage]
            
            self.Label_TurnoMedico.text = "\(TurnoMedicoArray[pageControl.currentPage])"
            self.Label_Dirreccion.text = "\(DirreccionArray[pageControl.currentPage])"
            self.Label_Horario.text = "\(HorarioArray[pageControl.currentPage])"
            self.Label_Profesional.text = "\(ProfesionalArray[pageControl.currentPage])"
        }
        //==============================================================
        
        let scaleX: Int = (4 - pageControl.numberOfPages) * 8
        pageControl.transform = CGAffineTransform(translationX: CGFloat(scaleX), y: 0)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        //============================================
         let dateFormatter = DateFormatter()
         dateFormatter.dateFormat = "dd-MM-yyyy" //"yyyy-MM-dd"
         
         var todaysDate:NSDate = NSDate()
         var todayString: String = dateFormatter.string(from: todaysDate as Date)
         
         str_selectDate = todayString
         
         tryGet_AllSchedules()
        //============================================
        
        UserDefaults.standard.set(true, forKey: "SignIned")
        UserDefaults.standard.set(g_ProfileInfo.email, forKey: "email")
        UserDefaults.standard.set(g_ProfileInfo.password, forKey: "password")
        
        
        g_bool_byFavarite = false
        
        view_CheckButton.isHidden = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    //SideMenuViewDelegate - onTapEditProfileButton
    func onTapNuevoTurnoButton(sender: AnyObject) {
        
        g_Step_CurSel_Int = 1
        g_bool_byFavarite = false
        
        self.performSegue(withIdentifier: StorySegues.FromCalendarToStepSearch.rawValue, sender: self)
    }
    func onTapMisTurnosButton(sender: AnyObject) {
        g_bool_byFavarite = false
        
        //self.performSegue(withIdentifier: StorySegues.FromHomeToMyShift.rawValue, sender: self)
    }
    func onTapMisMedicosButton(sender: AnyObject) {
        self.performSegue(withIdentifier: StorySegues.FromCalendarToMyDoctor.rawValue, sender: self)
    }
    func onTapDatosPersonalesButton(sender: AnyObject) {
        g_bool_byFavarite = false
        
        self.performSegue(withIdentifier: StorySegues.FromCalendarToUpdatePersonal.rawValue, sender: self)
    }
    func onTapCerrarSesionButton(sender: AnyObject) {
        
        g_bool_byFavarite = false
        g_LoginFlag = false
        
        UserDefaults.standard.set(false, forKey: "SignIned")
        UserDefaults.standard.set("", forKey: "email")
        UserDefaults.standard.set("", forKey: "password")
        UserDefaults.standard.set(UIImageJPEGRepresentation(#imageLiteral(resourceName: "7_AnonymousImag.png"), 100), forKey: "avatarImage") //7_AnonymousImag
        
        g_ProfileInfo.avatarimage = Utils.profileImage(image: #imageLiteral(resourceName: "7_AnonymousImag.png"))
        
        
        
        GIDSignIn.sharedInstance().signOut()
        dismiss(animated: true, completion: nil)
        
        if FBSDKAccessToken.current() != nil {
            let logout = FBSDKLoginManager()
            logout.logOut()
        }
        
        
        g_favarite_Doctors_Array.removeAll()
        g_Step_1_Array.removeAll()
        g_Step_2_Array.removeAll()
        g_Step_3_Array.removeAll()
        g_Step_4_Array.removeAll()
        g_Step_5_Array.removeAll()
        self.revealViewController().revealToggle(animated: true)
        
        
        
        /*let bSignUped = UserDefaults.standard.bool(forKey: "bSignUped")
         if (!bSignUped) {
         
         //Go to SignUp
         self.performSegue(withIdentifier: StorySegues.FromHomeToRegister.rawValue, sender: self)
         } else {
         
         //Got to SignIn
         self.performSegue(withIdentifier: StorySegues.FromHomeToSignIn.rawValue, sender: self)
         }*/
        self.performSegue(withIdentifier: StorySegues.FromCalendarToSignIn.rawValue, sender: self)
        
    }
    
    
    
    
    
    
    
    
    //Select Point
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        //=======================================================
        //
        // Data Load
/*        DataArray = ["A", "B", "C", "D", "E"]
            
            //, "F", "G", "H",
         //"I", "J", "K", "L", "M", "N", "O", "P"]
//        ,
//         "Q", "R", "S", "T", "U", "V", "W", "X"
//        ]
*/
        //
        //=======================================================
        
        if monthPosition == .next || monthPosition == .previous {
            calendar.setCurrentPage(date, animated: true)
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy" //yyyy-MM-dd"
        

        str_selectDate = dateFormatter.string(from: date)
        //date_selectDate = dateFormatter.date(from: str_selectDate)
        //print(date_selectDate)

        
        //=======================================================
        // Here in Get Time Shecdules.
        //
        Get_TimeSchedules_For_OneDay()
        InitLoad_SwipeDate()
        //
        //=======================================================
        
        
        
        if eventsArray.contains(where: { $0.lowercased() == str_selectDate.lowercased() })
        {
            viewFlag = true
            pageControl.isHidden = false
            view_ExistEvent.isHidden = false
            view_NoneEvent.isHidden = true
        } else {
            viewFlag = false
            pageControl.isHidden = true
            view_ExistEvent.isHidden = true
            view_NoneEvent.isHidden = false
        }
        
        //self.revealViewController().revealToggle(animated: true)
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    //Init Event Color
    func calendar(_ calendar: FSCalendar!, appearance: FSCalendarAppearance!, titleDefaultColorForDate date: NSDate!) -> UIColor!
    {
        //From Calendar
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy" //"yyyy-MM-dd"
        
        let dateString: String = dateFormatter.string(from: date as Date)
        
//        let things = ["foo", "Bar"]
//        let searchString = "FOO"
//        
//        if things.contains(where: { $0.lowercased() == searchString.lowercased() }) {
//            print("found searchString")
//        } else {
//            print("searchString not found")
//        }

        if eventsArray.contains(where: { $0.lowercased() == dateString.lowercased() })
        {
            return UIColor.red
        }
        else
        {
            return nil
        }
    }
    

    
    
    
    
    //Init Add Event
    func calendar(_ calendar: FSCalendar, hasEventFor date: Date) -> Bool {
        
        for data in eventsArray{
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy" //"yyyy-MM-dd"
           
            let dateString = dateFormatter.date(from: data)
            
            let order = NSCalendar.current.compare(dateString!, to: date as Date, toGranularity: .day)
            if order == ComparisonResult.orderedSame{
                let unitFlags: NSCalendar.Unit = [ .day, .month, .year]
                let calendar2: NSCalendar = NSCalendar.current as NSCalendar
                let components: NSDateComponents = calendar2.components(unitFlags, from: dateString!) as NSDateComponents
                datesWithEvent.append(calendar2.date(from: components as DateComponents)! as NSDate)
            }
        }
        return datesWithEvent.contains(date as NSDate)
    }
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
        for data in eventsArray{
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy" //"yyyy-MM-dd"
            
            var todaysDate:NSDate = NSDate()
            var todayString: String = dateFormatter.string(from: todaysDate as Date)
            
            let dateString = dateFormatter.date(from: data)
            
            let order = NSCalendar.current.compare(dateString!, to: date as Date, toGranularity: .day)

            if order == ComparisonResult.orderedSame{
                
                let dateString_Temp: String = dateFormatter.string(from: date as Date)
                if dateString_Temp == todayString {
                    /*viewFlag = true
                    pageControl.isHidden = false
                    view_ExistEvent.isHidden = false
                    view_NoneEvent.isHidden = true*/
                } else {
                    /*viewFlag = false
                    pageControl.isHidden = true
                    view_ExistEvent.isHidden = true
                    view_NoneEvent.isHidden = false*/
                }
                
                return 1  //number of events
            }
        }
        return 0
    }

    
    
    // Or image for some days
    /*func calendar(_ calendar: FSCalendar!, imageFor date: NSDate!) -> UIImage! {
        
        //From Calendar
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let dateString: String = dateFormatter.string(from: date as Date)

        if absentDatesArray.contains(where: { $0.lowercased() == dateString.lowercased() })
        {
            return #imageLiteral(resourceName: "5_TimeSet_On.png")
        }
        else
        {
            return nil
        }
    }*/

    
    
    
//    @IBAction func onTappedBackButton(_ sender: Any) {
//        self.navigationController?.popViewController(animated: true)
//    }
    
    @IBAction func onTappedCancelEvent(_ sender: Any) {
        
        if str_selectDate == "" {
            self.view.makeToast("Seleccione la fecha para eliminar el Evento.")
            return
        }
        
        self.GradientView.backgroundColor = UIColor(red: 200.0/255.0, green: 200.0/255.0, blue: 200.0/255.0, alpha: 1.0)
        
        self.myCalendar.isUserInteractionEnabled = false
        self.Btn_CancelShift.isEnabled = false
        
        view_CheckButton.isHidden = false
        
    }
    
    @IBAction func onTappedCancelShift(_ sender: Any) {
        
        if let search_index = eventsArray.index(of: str_selectDate) {       //str_selectDate = 03-06-2017
            //eventsArray.remove(at: search_index)
            
            if DataArray.count < 2 {
                eventsArray.remove(at: search_index)
                
                viewFlag = false
                pageControl.isHidden = true
                view_ExistEvent.isHidden = true
                view_NoneEvent.isHidden = false
                
                view_CheckButton.isHidden = true
                self.myCalendar.isUserInteractionEnabled = true
                self.Btn_CancelShift.isEnabled = true
                
                self.GradientView.backgroundColor = UIColor.clear

                
                // Cancel Time Schedule Code
                tryCancel_Schedule()
                /*appointmentID.remove(at: pageControl.currentPage)
                
                DataArray.remove(at: pageControl.currentPage)
                
                TurnoMedicoArray.remove(at: pageControl.currentPage)
                DirreccionArray.remove(at: pageControl.currentPage)
                HorarioArray.remove(at: pageControl.currentPage)
                ProfesionalArray.remove(at: pageControl.currentPage)
                
                InitLoad_SwipeDate()
                myCalendar.reloadData()*/
                
            } else {
                view_CheckButton.isHidden = true
                self.myCalendar.isUserInteractionEnabled = true
                self.Btn_CancelShift.isEnabled = true
                
                self.GradientView.backgroundColor = UIColor.clear
                // Cancel Time Schedule Code
                tryCancel_Schedule()
                /*appointmentID.remove(at: pageControl.currentPage)
                
                DataArray.remove(at: pageControl.currentPage)
                
                TurnoMedicoArray.remove(at: pageControl.currentPage)
                DirreccionArray.remove(at: pageControl.currentPage)
                HorarioArray.remove(at: pageControl.currentPage)
                ProfesionalArray.remove(at: pageControl.currentPage)
                
                InitLoad_SwipeDate()
                myCalendar.reloadData()*/
            }
        }
    }
    
    @IBAction func onTappedNopShift(_ sender: Any) {
        
        view_CheckButton.isHidden = true
        
        self.myCalendar.isUserInteractionEnabled = true
        self.Btn_CancelShift.isEnabled = true
        
        self.GradientView.backgroundColor = UIColor.clear
    }
    
    // Cancel Schedule  --------------------------------------------------------------------------------
    // 3. http://67.205.136.161:8070/DocAppointments/rest/appointment/cancel
    func tryCancel_Schedule() {
        
        let params: NSDictionary = [
            "authorization" :
                                ["patientID": 1,
                                 "loginPolicy": "USRPASSWD",
                                 "eml": "juanperez@gmail.com",
                                 "psswd": "Prueba123"
                                ],
            "patientID":        g_patientID, //g_Step_5_Array[g_Step_SelIndex_Array[4]].information.patientID,
            "appointmentID":    appointmentID[pageControl.currentPage], //23,
            "status":           3
        ]
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue_NSDictionary(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Cancel_Schedule, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                var temp: schedule_Info = schedule_Info(STATUS: "", MSG_: "")
                temp.STATUS = responseObject?["STATUS"] as! String
                temp.MSG_ = responseObject?["MSG_"] as! String
                
                if temp.STATUS == "SUCCESS" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                    
                    // Cancel Time Schedule Code ======================================
                    
                    if let search_index = self.All_SchedulesID.index(of: self.appointmentID[self.pageControl.currentPage]){
                        
                        self.All_SchedulesID.remove(at: search_index)
                        g_All_Schedules.remove(at: search_index)
                        
                        self.appointmentID.remove(at: self.pageControl.currentPage)
                        
                        self.DataArray.remove(at: self.pageControl.currentPage)
                        
                        self.TurnoMedicoArray.remove(at: self.pageControl.currentPage)
                        self.DirreccionArray.remove(at: self.pageControl.currentPage)
                        self.HorarioArray.remove(at: self.pageControl.currentPage)
                        self.ProfesionalArray.remove(at: self.pageControl.currentPage)
                        
                        self.InitLoad_SwipeDate()
                        self.myCalendar.reloadData()
                    }
                    
                    
                    //=================================================================
                    
                }
                if temp.STATUS == "ERROR" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                }
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    //=========================================================================
    // Get Time All Schedules
    //=========================================================================
    // Get All Schedules  -----------------------------------------------------------------------------------------------
    // 1. http://67.205.136.161:8070/DocAppointments/rest/appointment/all
    func tryGet_AllSchedules() {
        
        g_All_Schedules.removeAll()
        All_SchedulesID.removeAll()
        eventsArray.removeAll()

        let params: NSDictionary = ["authorization":
                                                    ["patientID": 1,
                                                     "loginPolicy": "USRPASSWD",
                                                     "eml": "juanperez@gmail.com",
                                                     "psswd":"Prueba123"
                                                    ],
                                    "patientID": g_patientID
                                   ]
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Get_All_Schedules, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
//                print(responseObject)
                
                for data in responseObject! {
                    //print(data)
                    
                    
                    var temp_doctor_Info = doctor_Info(
                        id:           -1,
                        personID:     -1,
                        specialtyID:  -1,
                        assistantID:  -1,
                        lastName:     "",
                        name:         ""
                    )
                    var temp_specialty_Info = specialty_Info(
                        id:            -1,
                        nombre:        ""
                    )
                    var temp_hospital_Info = hospital_Info(
                        id:           -1,
                        nombre:       "",
                        direccion:    "",
                        telefono:     "",
                        email:        "",
                        estado:       -1,
                        locationID:   -1
                    )
                    var temp_Doctor_Schedules_Infor = Doctor_Schedules_Infor(
                        id:           -1,
                        fecha:        "",
                        horaInicio:   "",
                        horaFin:      "",
                        fechaCreacion:"",
                        
                        doctor:       temp_doctor_Info,
                        
                        estado:       -1,
                        hospitalID:   -1,
                        patientID:    -1,
                        doctorID:     -1,
                        
                        specialty:    temp_specialty_Info,
                        
                        hospital:     temp_hospital_Info
                    )
                    
                    let dict = data as! [String: AnyObject]
                    
//                    print(dict["fecha"] as! String)
//                    print(dict["id"] as! Int)
                    
                    let doctor_dict = dict["doctor"] as! [String: AnyObject]
                    temp_doctor_Info.id = doctor_dict["id"] as! Int
                    temp_doctor_Info.personID = doctor_dict["personID"] as! Int
                    temp_doctor_Info.specialtyID = doctor_dict["specialtyID"] as! Int
                    temp_doctor_Info.assistantID = doctor_dict["assistantID"] as! Int
                    temp_doctor_Info.lastName = doctor_dict["lastName"] as! String
                    temp_doctor_Info.name = doctor_dict["name"] as! String
                    
                    let specialty_dict = dict["specialty"] as! [String: AnyObject]
                    temp_specialty_Info.id = specialty_dict["id"] as! Int
                    temp_specialty_Info.nombre = specialty_dict["nombre"] as! String
                    
                    let hospital_dict = dict["hospital"] as! [String: AnyObject]
                    temp_hospital_Info.id = hospital_dict["id"] as! Int
                    temp_hospital_Info.nombre = hospital_dict["nombre"] as! String
                    temp_hospital_Info.direccion = hospital_dict["direccion"] as! String
                    temp_hospital_Info.telefono = hospital_dict["telefono"] as! String
                    temp_hospital_Info.email = hospital_dict["email"] as! String
                    temp_hospital_Info.estado = hospital_dict["estado"] as! Int
                    temp_hospital_Info.locationID = hospital_dict["locationID"] as! Int
                    
                    //g_All_Schedules
                    
                    var temp: Doctor_Schedules_Infor = Doctor_Schedules_Infor(
                        id:           dict["id"] as! Int,
                        fecha:        dict["fecha"] as! String,
                        horaInicio:   dict["horaInicio"] as! String,
                        horaFin:      dict["horaFin"] as! String,
                        fechaCreacion:dict["fechaCreacion"] as! String,
                        
                        doctor:       temp_doctor_Info,
                        
                        estado:       dict["estado"] as! Int,
                        hospitalID:   dict["hospitalID"] as! Int,
                        patientID:    dict["patientID"] as! Int,
                        doctorID:     dict["doctorID"] as! Int,
                        
                        specialty:    temp_specialty_Info,
                        
                        hospital:     temp_hospital_Info
                    )
                    
                    //*************************************************************************
                    
                    g_All_Schedules.append(temp)
                    self.All_SchedulesID.append(temp.id)
                    
                    if let search_index = self.eventsArray.index(of: temp.fecha) {
                        
                    } else {
                        self.eventsArray.append(temp.fecha)                           //"dd-MM-yyyy"
                    }
                    
                    
                    //*************************************************************************
                    
                    
                }
                
                
                self.Init_Today_Set_Event()
                self.Get_TimeSchedules_For_OneDay()
                self.InitLoad_SwipeDate()

                
//                print(self.eventsArray)
                
                self.myCalendar.reloadData()
//                if g_All_Schedules.count != 0 {
//                    print(g_All_Schedules[0])
//                    
//                    self.Init()
//                    self.CheckActiveTime()
//                    
//                } else {
//                    self.Init()
//                    //self.view.makeToast("Server is busy now.", duration: 3.0, position: .bottom)
//                }
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    /////////////////////////////////////////////////////////
    //
    // Get: DataArray = Array<String>()
    //
    /////////////////////////////////////////////////////////
    func Get_TimeSchedules_For_OneDay()  {
        
        DataArray.removeAll()
        
        appointmentID.removeAll()
        TurnoMedicoArray.removeAll()
        DirreccionArray.removeAll()
        HorarioArray.removeAll()
        ProfesionalArray.removeAll()
        
        if g_All_Schedules.count < 1 {
            return
        }
        
        for data in g_All_Schedules {
//            print(data)
            
            if data.fecha == str_selectDate {       // "dd-MM-yyyy" for equal select day?
                
                DataArray.append("TEST")
                
                appointmentID.append(data.id)
//                print(appointmentID)
                
                TurnoMedicoArray.append(data.hospital.nombre)
                
                DirreccionArray.append(data.hospital.direccion)
                
                /*var str = "Hello, playground"
                let index = str.index(str.startIndex, offsetBy: 5)
                str.substring(to: index)  // Hello
                let index = str.index(str.startIndex, offsetBy: 7)
                str.substring(from: index)  // playground
                
                let Arr : [String] = data.horaInicio.components(separatedBy: ":00")
                g_Diary_Time_Start = Arr[0]*/
                
                //06:30:00 -> 06:30 AM
                
                var str = data.horaInicio
                let index = str.index(str.startIndex, offsetBy: 2) // index = 2 for 06 from 06:30:00
                let int_Value = Int(str.substring(to: index))      // 06
                
                if int_Value! < 12 {
                    var str_1 = data.horaInicio
                    let index_1 = str_1.index(str_1.startIndex, offsetBy: 5)
                    //str_1.substring(to: index_1)

                    HorarioArray.append(str_1.substring(to: index_1) + " AM")
                } else {
                    var str_2 = data.horaInicio
                    let index_2 = str_2.index(str_2.startIndex, offsetBy: 5)
                    //str_2.substring(to: index_2)
                    
                    HorarioArray.append(str_2.substring(to: index_2) + " PM")
                }
                
                ProfesionalArray.append(data.doctor.lastName + " " + data.doctor.name)
            }
        }
    }

    
    @IBAction func onTappedAddTimeSchedule(_ sender: Any) {
        self.performSegue(withIdentifier: StorySegues.FromCalendarToStepSearch.rawValue, sender: self)
    }
    

}







