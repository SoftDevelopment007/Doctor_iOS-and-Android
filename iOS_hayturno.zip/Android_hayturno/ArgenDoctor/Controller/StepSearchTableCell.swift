//
//  StepSearchTableCell.swift
//  ArgenDoctor
//
//  Created by LEE on 5/24/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import Foundation
import UIKit



class StepSearchTableCell: UITableViewCell {

    @IBOutlet weak var TxtLabel: UILabel!
}
