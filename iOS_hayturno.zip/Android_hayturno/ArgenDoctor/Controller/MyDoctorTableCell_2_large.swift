//
//  MyDoctorTableCell.swift
//  ArgenDoctor
//
//  Created by LEE on 5/26/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import Foundation
import UIKit



class MyDoctorTableCell_2_large: UITableViewCell {
    
    @IBOutlet weak var smallSideButton_Under: UIButton!
    
    @IBOutlet weak var largeSideButton: UIButton!
    
    @IBOutlet weak var TxtLabel: UILabel!
    
    @IBOutlet weak var smallLikeButton: UIButton!
    //@IBOutlet weak var largeLikeButton: UIButton!

    @IBOutlet weak var largeCellView: UIView!
    
    
    @IBOutlet weak var LabelSpecialtyNombre: UILabel!
    @IBOutlet weak var LabelHospitalNombre: UILabel!
    @IBOutlet weak var LabelHospitalDireccion: UILabel!
    @IBOutlet weak var LabelDate: UILabel!
    @IBOutlet weak var LabelTime: UILabel!
    
    
    @IBOutlet weak var btnCancel: UIButton!
    
    @IBOutlet weak var btnAddButton: UIButton!
    
    
}
