//
//  PersonalInformationViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/25/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

import JVFloatLabeledTextField
import DatePickerDialog

import SDWebImage
import DownPicker

import Toast_Swift

class PersonalInformationViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, WDImagePickerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate {

    let GlobalVar = Global()
    
    
    @IBOutlet weak var ImageBasePic: UIImageView!
    
    @IBOutlet weak var ImagePicFrame: UIImageView!
    @IBOutlet weak var AvatatButton: UIButton!
    
    @IBOutlet weak var LabelName: UILabel!
    @IBOutlet weak var LabelEmail: UILabel!
    
    @IBOutlet weak var TextBirthday: JVFloatLabeledTextField!
    @IBOutlet weak var TextPhone: JVFloatLabeledTextField!
    @IBOutlet weak var TextGender: JVFloatLabeledTextField!
    @IBOutlet weak var TextDNI: JVFloatLabeledTextField!
    @IBOutlet weak var TextSocialWork: JVFloatLabeledTextField!
    @IBOutlet weak var TextAfiliadoNumber: JVFloatLabeledTextField!
    
    
    @IBOutlet weak var TextPhone_1: UITextField!
    @IBOutlet weak var TextDNI_1: UITextField!
    @IBOutlet weak var TextAfiliadoNumber_1: UITextField!
    
    //WDImagePicker
    var imagePicker: WDImagePicker!
    var fixedImage: UIImage?

    var GenderPickOption = ["Masculino", "Femenino"]
    
    //Social Work
    var downPicker: DownPicker!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        ProgressHUD.dismiss()
        
        //Init Sets
        GenderPickerDid()
        
        // bind yourTextField to DownPicker
        self.downPicker = DownPicker(textField: TextSocialWork, withData: g_InitSocialWork_Array)
        //self.downPicker.addTarget(self, action: "dp_Selected:", for: UIControlEvents.valueChanged)
        
        //Real Time Phone Number detect
        //TextPhone.addTarget(self, action: "textFieldDidChange:", for: UIControlEvents.editingChanged)
        
        TextPhone_1.delegate = self
        TextPhone_1.keyboardType = .numberPad
        TextDNI_1.delegate = self
        TextDNI_1.keyboardType = .numberPad
        TextAfiliadoNumber_1.delegate = self        
        TextAfiliadoNumber_1.keyboardType = .numberPad
        
        //Init Values
        //ImagePicFrame.isHidden = true
        //AvatatButton.isHidden = true
        //Init Values
        ImageBasePic.isHidden = true
        ImagePicFrame.isHidden = false
        AvatatButton.isHidden = false
        
        InitShow()
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        if textField == self.TextPhone_1 {
            
            let invalidCharacters = CharacterSet(charactersIn: "+0123456789").inverted
            return string.rangeOfCharacter(from: invalidCharacters, options: [], range: string.startIndex ..< string.endIndex) == nil
        } else {
            let invalidCharacters = CharacterSet(charactersIn: "0123456789").inverted
            return string.rangeOfCharacter(from: invalidCharacters, options: [], range: string.startIndex ..< string.endIndex) == nil
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
    }

    func InitShow(){
        
        LabelName.text = g_ProfileInfo.name
        LabelEmail.text = g_ProfileInfo.email
        
        /*self.fixedImage = self.imageWithImage(image: #imageLiteral(resourceName: "7_AnonymousImag.png"), newSize: CGSize(width: 110, height: 110))  //7_AnonymousImag.png
        self.fixedImage = Utils.profileImage(image: self.fixedImage!)
        g_ProfileInfo.avatarimage = fixedImage!*/
        
        self.AvatatButton.setBackgroundImage(g_ProfileInfo.avatarimage, for: .normal)
    }

    func GetProfileInfor() -> Bool {
        
        var Flag: Bool = true
        
        if TextBirthday.text != "" {
            g_ProfileInfo.birthday = TextBirthday.text!
        } else {
            Flag = false
        }
        
        if TextPhone.text != "" {
            g_ProfileInfo.phone = TextPhone.text!
        } else {
            Flag = false
        }
        
        if TextGender.text != "" {
            if TextGender.text == "Masculino" {
                g_ProfileInfo.gender = 1
            }
            if TextGender.text == "Femenino" {
                g_ProfileInfo.gender = 2
            }
            
        } else {
            Flag = false
        }
        
        if TextDNI.text != "" {
            g_ProfileInfo.dni = TextDNI.text!
        } else {
            Flag = false
        }
        
        if TextSocialWork.text != "" {
            
            if let search_index = g_InitSocialWork_Array.index(of: TextSocialWork.text!) {
                g_ProfileInfo.socialwork = search_index + 1
            }
        } else {
            Flag = false
        }
        
        if TextAfiliadoNumber.text != "" {
            g_ProfileInfo.afiliadonumber = TextAfiliadoNumber.text!
        } else {
            Flag = false
        }
        
        if Flag == false {
            self.view.makeToast("Inserte Infors correctos en todos los campos.")
        } else {
            
//            if AvatatButton.backgroundImage(for: .normal) == #imageLiteral(resourceName: "7_AnonymousImag.png") { //7_Anonymous              
//                
//            }
        }
        
        return Flag
        
        
    }
    
    
    func GenderPickerDid() {
        let pickerView = UIPickerView()
        
        pickerView.delegate = self
        
        TextGender.inputView = pickerView
        
        let toolBar = UIToolbar(frame: CGRect(x: 0, y: self.view.frame.size.height/6, width: self.view.frame.size.width, height: 40.0))
        
        toolBar.layer.position = CGPoint(x: self.view.frame.size.width/2, y: self.view.frame.size.height-20.0)
        
        toolBar.barStyle = UIBarStyle.blackTranslucent
        
        toolBar.tintColor = UIColor.white
        
        toolBar.backgroundColor = UIColor.black
        
        
        let defaultButton = UIBarButtonItem(title: "Defecto", style: UIBarButtonItemStyle.plain, target: self, action: #selector(PersonalInformationViewController.tappedToolBarBtn))
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: self, action: #selector(PersonalInformationViewController.donePressed))
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: self, action: nil)
        
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width / 3, height: self.view.frame.size.height))
        
        label.font = UIFont(name: "Helvetica", size: 12)
        
        label.backgroundColor = UIColor.clear
        
        label.textColor = UIColor.white
        
        label.text = "Seleccione género"
        
        label.textAlignment = NSTextAlignment.center
        
        let textBtn = UIBarButtonItem(customView: label)
        
        toolBar.setItems([defaultButton,flexSpace,textBtn,flexSpace,doneButton], animated: true)
        
        TextGender.inputAccessoryView = toolBar
    }
    func donePressed(_ sender: UIBarButtonItem) {
        
       if self.TextGender.text == "" {
            TextGender.text = "Masculino"
            TextGender.resignFirstResponder()
        } else {
            TextGender.resignFirstResponder()
        }
        
    }
    func tappedToolBarBtn(_ sender: UIBarButtonItem) {
        TextGender.text = "Masculino"
        TextGender.resignFirstResponder()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return GenderPickOption.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return GenderPickOption[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        TextGender.text = GenderPickOption[row]
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func imageWithImage(image: UIImage, newSize: CGSize) -> UIImage{
        UIGraphicsBeginImageContext(newSize)
        image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let newImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    @IBAction func onTappedAddAvatarImageButton(_ sender: Any) {
        
//        curProfileInfo.dob                  = (self.textFieldDateOfBirth.text)!
//        curProfileInfo.role                 = "user"
        
        imagePicker = WDImagePicker()
        imagePicker.cropSize = CGSize(width: 280, height: 200)
        imagePicker.delegate = self
        let alert = UIAlertController(title: "opción", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Cámara", style: .default, handler:{
            action in
            self.imagePicker.imagePickerController.sourceType = .camera
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Biblioteca de fotografías", style: .default, handler: {
            action in
            self.imagePicker.imagePickerController.sourceType = .photoLibrary
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    func imagePicker(_ imagePicker: WDImagePicker, pickedImage: UIImage) {
        
        self.fixedImage = self.imageWithImage(image: pickedImage, newSize: CGSize(width: 110, height: 110))
        self.fixedImage = Utils.profileImage(image: self.fixedImage!)
        g_ProfileInfo.avatarimage = fixedImage!
        self.AvatatButton.setBackgroundImage(g_ProfileInfo.avatarimage, for: .normal)
        
        ImageBasePic.isHidden = true
        ImagePicFrame.isHidden = false
        AvatatButton.isHidden = false
        

        

        
        self.imagePicker.imagePickerController.dismiss(animated: true, completion: nil)
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo:[AnyHashable: Any]!)
        {
            picker.dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func onTappedDateButton(_ sender: Any) {
        DatePickerDialog().show(title: "Cumpleaños selecto", doneButtonTitle: "Salvar", cancelButtonTitle: "Cancelar", minimumDate: nil, maximumDate: nil, datePickerMode: .date) { (date) in
            if date != nil {
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd-MM-yyyy"
                //dateFormatter.dateStyle = .medium
                var strDate = dateFormatter.string(from: date!)
                
                self.TextBirthday?.text = strDate
                g_ProfileInfo.birthday = strDate
            }
        }
    }
    
    func validate(phoneNumber: String) -> Bool {
        let charcterSet  = NSCharacterSet(charactersIn: "+0123456789").inverted
        let inputString = phoneNumber.components(separatedBy: charcterSet)
        let filtered = inputString.joined(separator: "")
        return  phoneNumber == filtered
    }
    
//    func textFieldDidChange(textField: UITextField) {
//        //your code
//        if validate(phoneNumber: textField.text!) == false {
//            return
//        }
//    }
    
//    func dp_Selected() {
//        
//        print(self.downPicker.text)        
//    }

    
    @IBAction func onTappedCreateAccount(_ sender: Any) {
        
        if GetProfileInfor() {
            
            //===================================================
            g_LoginFlag = true
            //===================================================
            
            ImageBasePic.isHidden = true
            ImagePicFrame.isHidden = false
            AvatatButton.isHidden = false
            
            //===================================================
            tryAddUser()
            //===================================================
            
        }
    }
    
    
    // Add User  -----------------------------------------------------------------------------------------------
    // 21. http://67.205.136.161:8070/DocAppointments/rest/patient/user/add
    func tryAddUser() {
        
        //print("======================================")
        
        let params: NSDictionary = [    "firstName": g_ProfileInfo.firstname,
                                        "lastName": g_ProfileInfo.lastname,
                                        "hospitalID": g_Step_5_Array[g_Step_SelIndex_Array[4]].information.hospitalID,
                                        "cellPhone": g_ProfileInfo.phone,
                                        "dni": g_ProfileInfo.dni,
                                        "birthDate": g_ProfileInfo.birthday,
                                        "gender": g_ProfileInfo.gender,
                                        "socialSecurityType": g_ProfileInfo.socialwork,
                                        "socialSecurityNumber": g_ProfileInfo.afiliadonumber,           //"7654321",
                                        "locationID": g_Step_2_Array[g_Step_SelIndex_Array[1]].id,  //27909,
                                        "provinceID": g_Step_1_Array[g_Step_SelIndex_Array[0]].id,  //24,
                                        "telephone": g_ProfileInfo.phone,           //"123456",
            
            
                                        "loginPolicy": "USRPASSWD",
                                        "email": g_ProfileInfo.email,                    //"claudiob@barca.com",
                                        "password": g_ProfileInfo.password          //"Prueba12345"
                                    ]
 
        //print(params)
        
        
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue_NSDictionary(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Add_User, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            //print(responseObject)
            if (responseObject != nil ) {
                
                var temp: User_Add_Infor = User_Add_Infor(STATUS: "", MSG_: "", patientID: g_patientID)
                temp.STATUS = responseObject?["STATUS"] as! String
                temp.MSG_ = responseObject?["MSG_"] as! String
                
                
                
                if temp.STATUS == "SUCCESS" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                    
                    if temp.MSG_ == "El usuario ha sido creado exitosamente" {
                        temp.patientID = responseObject?["patientID"] as! Int
                        g_patientID = temp.patientID
                        
                        //==================================================================================
                        
                        print(g_patientID)
                        
                        UserDefaults.standard.set(g_patientID, forKey: "g_patientID")
                        UserDefaults.standard.set(true, forKey: "SignUped")
                        
                        //==================================================================================
                        
                        
                        let frontView = self.storyboard?.instantiateViewController(withIdentifier: "MyShiftViewControllerVC") as! MyShiftViewController
                        let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                        rearView.delegate = frontView
                        let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                        self.navigationController?.pushViewController(swViewController!, animated: true)
                        //self.performSegue(withIdentifier: StorySegues.FromPersonalInformationToHome.rawValue, sender: self)
                    }
                }
                if temp.STATUS == "ERROR" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                }
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
}
