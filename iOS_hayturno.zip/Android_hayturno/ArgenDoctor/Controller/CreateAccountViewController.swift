//
//  CreateAccountViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/25/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit
import Toast_Swift
import JVFloatLabeledTextField


class CreateAccountViewController: UIViewController {

    //Field Variable
    @IBOutlet weak var TxtFirstName: JVFloatLabeledTextField!
    @IBOutlet weak var TxtLastName: JVFloatLabeledTextField!
    @IBOutlet weak var TxtEmail: JVFloatLabeledTextField!
    @IBOutlet weak var TxtPassword: JVFloatLabeledTextField!
    @IBOutlet weak var TxtRePassword: JVFloatLabeledTextField!
    
    @IBOutlet weak var ImageFirstName: UIImageView!
    @IBOutlet weak var ImageLastName: UIImageView!
    @IBOutlet weak var ImageEmail: UIImageView!
    @IBOutlet weak var ImagePassword: UIImageView!
    @IBOutlet weak var ImageRePassword: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    //===============================================================================
    @IBAction func onTappedCreateAccountButton(_ sender: Any) {
//      self.performSegue(withIdentifier: StorySegues.FromCreateAccountToPersonalInformation.rawValue, sender: self)
        if InputAllParameters() {
            
            g_ProfileInfo.firstname = TxtFirstName.text!
            g_ProfileInfo.lastname = TxtLastName.text!
            g_ProfileInfo.name = TxtFirstName.text! + " " + TxtLastName.text!
            g_ProfileInfo.email = TxtEmail.text!
            
            
            //--------------------------------------------------------
            let tempPass: String = TxtPassword.text!
            let length_before = tempPass.length
            
            g_ProfileInfo.password = "Un" + (tempPass as! String)
            var length_after = length_before + 2
            length_after = g_ProfileInfo.password.length
            
            if length_after < 17 {
                
                //length_after
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: length_after)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            } else {
                
                //16
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: 16)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            }
            //--------------------------------------------------------
            
            self.performSegue(withIdentifier: StorySegues.FromCreateAccountToPersonalInformation.rawValue, sender: self)
        }
        
    }
    //===============================================================================
    
    //check true or false values.
    func InputAllParameters() -> (Bool) {
        
        var Flag: Bool = true
        
        if TxtFirstName.text == "" {
            
            Flag = false
            ImageFirstName.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("Por favor, introduzca el campo Nombre.")
        } else{
            ImageFirstName.image = nil
        }
        if TxtLastName.text == "" {
            
            Flag = false
            ImageLastName.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("Por favor, introduzca el campo del apellido.")
        }else {
           ImageLastName.image = nil
        }
        
        if TxtEmail.text == "" {
            
            Flag = false
            ImageEmail.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("Por favor, introduzca el campo de correo electrónico.")
        }else{
            ImageEmail.image = nil
        }
        
        if TxtEmail.text?.isEmail == false {
            
            Flag = false
            ImageEmail.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("El tipo de correo electrónico no es válido.")
        } else {
            ImageEmail.image = nil
        }
        
        if TxtPassword.text == "" {
            
            Flag = false
            ImagePassword.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("Por favor, introduzca el campo de contraseña.")
        }
        if TxtPassword.text?.isValidPassword == false {
            
            Flag = false
            ImagePassword.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("El tipo de contraseña no es válido.")
        } else {
            ImagePassword.image = nil
        }
        
        if TxtRePassword.text == "" {
            
            Flag = false
            ImageRePassword.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("Por favor, introduzca Repetir campo de contraseña.")
        }
        if TxtRePassword.text?.isValidPassword == false {
            
            Flag = false
            ImageRePassword.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("Repetir El tipo de contraseña no es válido.")
        }else {
            ImageRePassword.image = nil
        }
        
        if TxtPassword.text != TxtRePassword.text {
            
            Flag = false
            ImagePassword.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            ImageRePassword.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("Contraseña y contraseña de repetición no coinciden.")
        } else {
            if TxtPassword.text != "" && TxtRePassword.text != "" {
                if TxtPassword.text?.isValidPassword == true && TxtRePassword.text?.isValidPassword == true {
                    ImagePassword.image = nil
                    ImageRePassword.image = nil
                }               
            }
        }
        
        return Flag
    }
    
    @IBAction func onTappedShowToast1(_ sender: Any) {
        if ImageFirstName.image == #imageLiteral(resourceName: "Icon_Red_Alert") {
            self.view.makeToast("Por favor, introduzca el campo Nombre.")
        }
    }
    
    @IBAction func onTappedShowToast2(_ sender: Any) {
        if ImageLastName.image == #imageLiteral(resourceName: "Icon_Red_Alert") {
            self.view.makeToast("Por favor, introduzca el campo del apellido.")
        }
    }
    
    @IBAction func onTappedShowToast3(_ sender: Any) {
        if ImageEmail.image == #imageLiteral(resourceName: "Icon_Red_Alert") {
            if TxtEmail.text == "" {
                self.view.makeToast("Por favor, introduzca el campo de correo electrónico.")
            } else {
                if TxtEmail.text?.isEmail == false {
                    self.view.makeToast("El tipo de correo electrónico no es válido.")
                }
            }
        }
    }
    
    @IBAction func onTappedShowToast4(_ sender: Any) {
        if TxtPassword.text == "" {
            self.view.makeToast("Por favor, introduzca el campo de contraseña.")
        } else {
            if TxtPassword.text?.isValidPassword == false {
                self.view.makeToast("El tipo de contraseña no es válido.")
            } else {
                if TxtPassword.text != TxtRePassword.text {
                    self.view.makeToast("Contraseña y contraseña de repetición no coinciden.")
                }
            }
        }
    }
    
    @IBAction func onTappedShowToast5(_ sender: Any) {
        if TxtRePassword.text == "" {
            self.view.makeToast("Por favor, introduzca Repetir campo de contraseña.")
        } else {
            if TxtRePassword.text?.isValidPassword == false {
                self.view.makeToast("Repetir El tipo de contraseña no es válido.")
            } else {
                if TxtPassword.text != TxtRePassword.text {
                    self.view.makeToast("Contraseña y contraseña de repetición no coinciden.")
                }
            }
        }
    }
    
}


//=====================================================================================
extension String {
    
    //To check text field or String is blank or not
    var isBlank: Bool {
        get {
            let trimmed = trimmingCharacters(in: CharacterSet.whitespaces)
            return trimmed.isEmpty
        }
    }
    
    //Validate Email
    
    var isEmail: Bool {
        do {
            let regex = try NSRegularExpression(pattern: "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}", options: .caseInsensitive)
            return regex.firstMatch(in: self, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.characters.count)) != nil
        } catch {
            return false
        }
    }
    
    var isAlphanumeric: Bool {
        return !isEmpty && range(of: "[^a-zA-Z0-9]", options: .regularExpression) == nil
    }
    
    //validate Password
    var isValidPassword: Bool {
        do {
            let regex = try NSRegularExpression(pattern: "^[a-zA-Z_0-9\\-_,;.:#+*?=!§$%&/()@]+$", options: .caseInsensitive)
            if(regex.firstMatch(in: self, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.characters.count)) != nil){
                
                if(self.characters.count>=8 && self.characters.count<=20){
                    return true
                }else{
                    return false
                }
            }else{
                return false
            }
        } catch {
            return false
        }
    }
}
