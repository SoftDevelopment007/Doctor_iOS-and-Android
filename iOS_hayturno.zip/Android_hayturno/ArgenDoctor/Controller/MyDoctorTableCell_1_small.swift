//
//  MyDoctorTableCell.swift
//  ArgenDoctor
//
//  Created by LEE on 5/26/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import UIKit



class MyDoctorTableCell_1_small: UITableViewCell {
    
    @IBOutlet weak var smallSideButton_Right: UIButton!
    
    @IBOutlet weak var largeSideButton: UIButton!
   
    @IBOutlet weak var TxtLabel: UILabel!
    
    @IBOutlet weak var smallLikeButton: UIButton!
    //@IBOutlet weak var largeLikeButton: UIButton!
    
    @IBOutlet weak var smallCellView: UIView!
    
}
