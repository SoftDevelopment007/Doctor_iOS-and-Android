//
//  ConfirmViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/24/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

class ConfirmViewController: UIViewController {

    //Step Field 1 ~ 5
    @IBOutlet weak var TxtLabelField1: UILabel!
    @IBOutlet weak var TxtLabelField2: UILabel!
    @IBOutlet weak var TxtLabelField3: UILabel!
    @IBOutlet weak var TxtLabelField4: UILabel!
    @IBOutlet weak var TxtLabelField5: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        ShowStepField()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        ShowStepField()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func ShowStepField() {
        
        TxtLabelField1.text = g_Step_1_Array[g_Step_SelIndex_Array[0]].nombre
        TxtLabelField2.text = g_Step_2_Array[g_Step_SelIndex_Array[1]].nombre
        TxtLabelField3.text = g_Step_3_Array[g_Step_SelIndex_Array[2]].nombre
        TxtLabelField4.text = g_Step_4_Array[g_Step_SelIndex_Array[3]].nombre
        TxtLabelField5.text = g_Step_5_Array[g_Step_SelIndex_Array[4]].information.nombre + " " + g_Step_5_Array[g_Step_SelIndex_Array[4]].information.apellido
    }

    @IBAction func onTappedField1Button(_ sender: Any) {
        
        g_Step_CurSel_Int = 1
        
        self.navigationController?.popViewController(animated: true)
        //self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func onTappedField2Button(_ sender: Any) {
        
        g_Step_CurSel_Int = 2
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedField3Button(_ sender: Any) {
        
        g_Step_CurSel_Int = 3
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedField4Button(_ sender: Any) {
        
        g_Step_CurSel_Int = 4
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedField5Button(_ sender: Any) {
        
        g_Step_CurSel_Int = 5
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedConfirmButton(_ sender: Any) {
        
        self.performSegue(withIdentifier: StorySegues.FromConfirmToSearchDiary.rawValue, sender: self)
    }
    
}
