//
//  RegisterViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/25/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

import FBSDKCoreKit
import FBSDKLoginKit

import Firebase
import GoogleSignIn

import FirebaseAuth
//import FirebaseDatabase

//import FirebaseStorage
//import SDWebImage

//import ImageSlideshow
//import Alamofire

class RegisterViewController: UIViewController, GIDSignInUIDelegate, GIDSignInDelegate {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //Google
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func onTappedCreateAccount(_ sender: Any) {
        
        self.performSegue(withIdentifier: StorySegues.FromRegisterToCreateAccount.rawValue, sender: self)
    }
    
    @IBAction func onTappedFaceBookButton(_ sender: Any) {
        
        FBSDKLoginManager().logIn(withReadPermissions: ["email", "public_profile"], from: self) { (result, err) in
            
            if err != nil {
                print("FB login failed: \(err)")
                return
            }
            
            self.showEmailAddress()
        }
    }

    func showEmailAddress() {
        
        ProgressHUD.show()
        
        let accessToken = FBSDKAccessToken.current()
        guard let accessTokenString = accessToken?.tokenString else { return }
        
        let credentials = FIRFacebookAuthProvider.credential(withAccessToken: accessTokenString)
        
        FIRAuth.auth()?.signIn(with: credentials, completion: { (user, error) in
            if error != nil {
                print("Something is wrong with FB user: \(error)")
            }
            
            //print("successfully logged in with our user: \(user)")
        })
        
        //FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "email, id, name"]).start { (connection, result, err) in
        FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "id, name, first_name, last_name, email, picture.type(normal), link"]).start { (connection, result, err) in
            
            if err != nil {
                print("failed to login: \(err)")
                return
            }
            
            //print(result ?? "")
            
            
            
            guard let userInfo = result as? [String: Any] else { return } //handle the error
            //The url is nested 3 layers deep into the result so it's pretty messy
            if let imageURL = ((userInfo["picture"] as? [String: Any])?["data"] as? [String: Any])?["url"] as? String {
                //Download image from imageURL
                //print(imageURL)
                
                if let imageData: NSData = NSData(contentsOf: NSURL(string: imageURL) as! URL) {
                    g_ProfileInfo.avatarimage = Utils.profileImage(image: UIImage(data: imageData as Data)!)
                }
            }

            
            //-----------------------------------------------------------
            let data:[String:AnyObject] = result as! [String : AnyObject]
            
            //print(data)
            
            let uid : NSString? = data["id"]! as? NSString
            let userName : NSString? = data["name"]! as? NSString
            let firstName : NSString? = data["first_name"]! as? NSString
            let lastName : NSString? = data["last_name"]! as? NSString
            let email : NSString? = data["email"]! as? NSString
            
            /*print(uid)
            print(userName!)
            print(firstName!)
            print(lastName!)
            print(email!)*/
            
            
            //=====================================================================================================
            g_LoginFlag = true

            g_ProfileInfo.name = userName! as String
            g_ProfileInfo.firstname = firstName! as String
            g_ProfileInfo.lastname = lastName! as String
            g_ProfileInfo.email = email! as String

            
            //---------------------------------------------------------
            let tempPass: String = (uid as! String)
            let length_before = tempPass.length
            
            g_ProfileInfo.password = "Un" + (tempPass as! String)
            var length_after = length_before + 2
            length_after = g_ProfileInfo.password.length
            
            if length_after < 17 {
                
                //length_after
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: length_after)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            } else {
                
                //16
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: 16)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            }
            //----------------------------------------------------------
            
            
            self.performSegue(withIdentifier: StorySegues.FromResgisterToPersonalInfor.rawValue, sender: self)
            //=====================================================================================================
        }
    }
    
    
    

//    @IBAction func signOut(sender: AnyObject) {
//        GIDSignIn.sharedInstance().signOut()
//        dismiss(animated: true, completion: nil)
//    }
    
    @IBAction func onTappedGoogleButton(_ sender: Any) {
        
        //ProgressHUD.show()
        GIDSignIn.sharedInstance().signIn()
        //GIDSignIn.sharedInstance().signInSilently()
    }
    
    func signIn(_ signIn: GIDSignIn!, didDisconnectWithUser user: GIDGoogleUser!, withError error: NSError!) {
        
    }
    
    func sign( _ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {

        if let err = error {
            //ProgressHUD.dismiss()
            print("Failed to log in with Google: \(err)")
            return          
        }
        else {
            ProgressHUD.show()
            //print("Successfully logged in with Goodle: \(user)")
            
            guard let idToken = user.authentication.idToken else { return }
            guard let accessToken = user.authentication.accessToken else { return }
            
            let userId = user.userID
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
            
            if user.profile.hasImage
            {
                let pic = user.profile.imageURL(withDimension: 100)
                //print(pic)
                
                if let imageData: NSData = NSData(contentsOf: pic!) {
                    g_ProfileInfo.avatarimage = Utils.profileImage(image: UIImage(data: imageData as Data)!)
                }
            }
            
            /*print(userId)
            print(fullName)
            print(givenName)
            print(familyName)
            print(email)*/
            
            
           
            //=======================================================================================================
            //
            g_LoginFlag = true
            
            g_ProfileInfo.name = fullName!
            g_ProfileInfo.firstname = givenName!
            g_ProfileInfo.lastname = familyName!
            g_ProfileInfo.email = email!
            
            
            //---------------------------------------------------------
            let tempPass: String = userId!
            let length_before = tempPass.length
            
            g_ProfileInfo.password = "Un" + (tempPass as! String)
            var length_after = length_before + 2
            length_after = g_ProfileInfo.password.length
            
            if length_after < 17 {
                
                //length_after
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: length_after)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            } else {
                
                //16
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: 16)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            }
            //----------------------------------------------------------
            
            
            self.performSegue(withIdentifier: StorySegues.FromResgisterToPersonalInfor.rawValue, sender: self)
            //
            //======================================================================================================
        }
    }
    
    
}
