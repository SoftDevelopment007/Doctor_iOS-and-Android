//
//  ConfirmacionViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/25/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

class ConfirmacionViewController: UIViewController {

    let GlobalVar = Global()
    
    
    @IBOutlet weak var LabelCity: UILabel!
    @IBOutlet weak var LabelInstitution: UILabel!
    @IBOutlet weak var LabelAdress: UILabel!
    @IBOutlet weak var LabelTelephone: UILabel!
    @IBOutlet weak var LabelSpecialty: UILabel!
    @IBOutlet weak var LabelProfesional: UILabel!
    @IBOutlet weak var LabelDay: UILabel!
    @IBOutlet weak var LabelTime: UILabel!
    
    @IBOutlet weak var Btn_DoctorLikeButton: UIButton!
    
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    
    var tempDoctorID: Int = -1
    var tempHospitalID: Int = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //Rounded Type View
        view1.layer.cornerRadius = 6.0
        view2.layer.cornerRadius = 6.0
        view3.layer.cornerRadius = 6.0
        
        ShowStepField()
        
        
        
        
        var favarite_doctor_array: Array<String> = Array<String>()
        for i in 0 ..< g_favarite_Doctors_Array.count {
            favarite_doctor_array.append(g_favarite_Doctors_Array[i].firstname + " " + g_favarite_Doctors_Array[i].lastname)
        }
        
        if g_bool_byFavarite == true {
            
            tempDoctorID = g_favarite_Doctors_Array[g_Current_Index].doctorID
            tempHospitalID = g_favarite_Doctors_Array[g_Current_Index].hospital_id
            
            
            if let search_index = favarite_doctor_array.index(of: g_favarite_Doctors_Array[g_Current_Index].firstname + " " + g_favarite_Doctors_Array[g_Current_Index].lastname) {
                
                Btn_DoctorLikeButton.setBackgroundImage(#imageLiteral(resourceName: "4_Remove_Heart.png"), for: .normal)    //4_Remove_Heart.png
            } else {
                Btn_DoctorLikeButton.setBackgroundImage(#imageLiteral(resourceName: "4_Add_Heart.png"), for: .normal)    //4_Add_Heart.png
            }
        } else {
            if let search_index = favarite_doctor_array.index(of: g_Step_5_Array[g_Step_SelIndex_Array[4]].information.nombre + " " + g_Step_5_Array[g_Step_SelIndex_Array[4]].information.apellido) {
                
                Btn_DoctorLikeButton.setBackgroundImage(#imageLiteral(resourceName: "4_Remove_Heart.png"), for: .normal)    //4_Remove_Heart.png
            } else {
                Btn_DoctorLikeButton.setBackgroundImage(#imageLiteral(resourceName: "4_Add_Heart.png"), for: .normal)    //4_Add_Heart.png
            }
        }
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        ShowStepField()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if g_bool_byFavarite == true {
            tempDoctorID = g_favarite_Doctors_Array[g_Current_Index].doctorID
            tempHospitalID = g_favarite_Doctors_Array[g_Current_Index].hospital_id
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

   
    func ShowStepField() {

        if g_bool_byFavarite == true {
            
            //g_bool_byFavarite = false
            
            LabelCity.text = "Acheral   "
            LabelInstitution.text = g_favarite_Doctors_Array[g_Current_Index].hospitalname       //Optional("Sanatorio Norte")
            LabelAdress.text = g_favarite_Doctors_Array[g_Current_Index].hospitaldireccion       //Optional("Salta 122")
            LabelTelephone.text = g_favarite_Doctors_Array[g_Current_Index].hospitaltelefono     //Optional("4312233")
            LabelSpecialty.text = g_favarite_Doctors_Array[g_Current_Index].special       //Optional("Cardiologia")
            LabelProfesional.text = g_favarite_Doctors_Array[g_Current_Index].firstname + " " + g_favarite_Doctors_Array[g_Current_Index].lastname
            
        } else {
            LabelCity.text = g_Step_2_Array[g_Step_SelIndex_Array[1]].nombre            //Optional("Acheral   ")
            LabelInstitution.text = g_Step_4_Array[g_Step_SelIndex_Array[3]].nombre     //Optional("Sanatorio Norte")
            LabelAdress.text = g_Step_4_Array[g_Step_SelIndex_Array[3]].direccion       //Optional("Salta 122")
            LabelTelephone.text = g_Step_4_Array[g_Step_SelIndex_Array[3]].telefono     //Optional("4312233")
            LabelSpecialty.text = g_Step_3_Array[g_Step_SelIndex_Array[2]].nombre       //Optional("Cardiologia")
            LabelProfesional.text = g_Step_5_Array[g_Step_SelIndex_Array[4]].information.nombre + " " + g_Step_5_Array[g_Step_SelIndex_Array[4]].information.apellido                                                    //Optional("Luciana Perez")
        }
        
        
        
        
        LabelDay.text = g_Diary_Date
        LabelTime.text = g_Diary_Time
        
        if g_RegisteredFlag {
            Btn_DoctorLikeButton.isHidden = false
        } else {
            Btn_DoctorLikeButton.isHidden = true
        }
        
        
    }
    
    @IBAction func onTappedFavariteButton(_ sender: Any) {
        
        if !g_LoginFlag {
            return
        }
        
        if Btn_DoctorLikeButton.backgroundImage(for: .normal) == #imageLiteral(resourceName: "4_Add_Heart.png")  {   //4_Add_Heart.png
            
            //add favarite
            //Btn_DoctorLikeButton.setBackgroundImage(#imageLiteral(resourceName: "4_Remove_Heart.png"), for: .normal)    //4_Remove_Heart.png
            
            print(g_favarite_Doctors_Array)
            tryAddFavariteDoctor()
            
        } else {
            
            //remove event
            //Btn_DoctorLikeButton.setBackgroundImage(#imageLiteral(resourceName: "4_Add_Heart.png"), for: .normal)    //4_Add_Heart.png
            
            print(g_favarite_Doctors_Array)
            tryRemoveFavariteDoctor()
        }
    }
    
    
    @IBAction func onTappedConfirmButton(_ sender: Any) {
        
        //===================================================
        if g_LoginFlag == true { //Go to AprobacionView
            
            self.performSegue(withIdentifier: StorySegues.FromConfirmacionToAprobacion.rawValue, sender: self)            

        } else {    // Go to SignUp
            
          self.performSegue(withIdentifier: StorySegues.FromConfirmacionToRegister.rawValue, sender: self)
        }
        //===================================================       
        
    }
    
    
    // 6_ok. http://67.205.136.161:8070/DocAppointments/rest/patient/favorite/add
    func tryAddFavariteDoctor() {
        
        
        var params: NSDictionary = [
                                    "authorization": [
                                                    "patientID": 1,
                                                    "loginPolicy": "USRPASSWD",
                                                    "eml": "juanperez@gmail.com",
                                                    "psswd":"Prueba123"
                                                    ],
                                    "doctorID": "",
                                    "patientID": g_patientID,
                                    "hospitalID": ""
                                  ]
        
        if g_bool_byFavarite == true {
            params = [
                        "authorization": [
                            "patientID": 1,
                            "loginPolicy": "USRPASSWD",
                            "eml": "juanperez@gmail.com",
                            "psswd":"Prueba123"
                        ],
                        "doctorID": tempDoctorID,
                        //g_Step_5_Array[g_Step_SelIndex_Array[4]].information.doctorID,
                        "patientID": g_patientID,
                        "hospitalID": tempHospitalID
                        // g_Step_5_Array[g_Step_SelIndex_Array[4]].information.hospitalID
                    ]
        } else {
            params = [
                        "authorization": [
                            "patientID": 1,
                            "loginPolicy": "USRPASSWD",
                            "eml": "juanperez@gmail.com",
                            "psswd":"Prueba123"
                        ],
                        "doctorID": g_Step_5_Array[g_Step_SelIndex_Array[4]].information.doctorID,
                        "patientID": g_patientID,
                        "hospitalID": g_Step_5_Array[g_Step_SelIndex_Array[4]].information.hospitalID
                    ]
        }
        
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue_NSDictionary(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Add_Favarite_Doctor, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                var temp: schedule_Info = schedule_Info(STATUS: "", MSG_: "")
                temp.STATUS = responseObject?["STATUS"] as! String
                temp.MSG_ = responseObject?["MSG_"] as! String
                
                if temp.STATUS == "SUCCESS" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                    
                    
                    if temp.MSG_ == "El doctor ha sido vinculado exitosamente" {
                       self.Btn_DoctorLikeButton.setBackgroundImage(#imageLiteral(resourceName: "4_Remove_Heart.png"), for: .normal)    //4_Remove_Heart.png
                       self.tryGetFavariteDoctorsAll()
                    }
                    
                }
                if temp.STATUS == "ERROR" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                }
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    // 8_ok. http://67.205.136.161:8070/DocAppointments/rest/patient/favorite/remove
    func tryRemoveFavariteDoctor() {
        
        var favarite_doctor_array: Array<String> = Array<String>()
        for i in 0 ..< g_favarite_Doctors_Array.count {
            favarite_doctor_array.append(g_favarite_Doctors_Array[i].firstname + " " + g_favarite_Doctors_Array[i].lastname)
        }
        
        var cnt: Int = -1
        
        if g_bool_byFavarite == true {
            if let search_index = favarite_doctor_array.index(of: g_favarite_Doctors_Array[g_Current_Index].firstname + " " + g_favarite_Doctors_Array[g_Current_Index].lastname) {
                
                cnt = search_index
            } else {
                return
            }
        } else {
            if let search_index = favarite_doctor_array.index(of: g_Step_5_Array[g_Step_SelIndex_Array[4]].information.nombre + " " + g_Step_5_Array[g_Step_SelIndex_Array[4]].information.apellido) {
                
                cnt = search_index
            } else {
                return
            }
        }
        

        
        let params: NSDictionary = [
                                        "authorization":
                                                        [
                                                            "patientID": 1,
                                                            "loginPolicy": "USRPASSWD",
                                                            "eml": "juanperez@gmail.com",
                                                            "psswd":"Prueba123"
                                                        ],
                                        "favoriteID": g_favarite_Doctors_Array[cnt].favoriteID,     //30,
                                        "patientID" : g_patientID                                   //1
                                  ]
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue_NSDictionary(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Remove_Favarite_Doctor, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                var temp: schedule_Info = schedule_Info(STATUS: "", MSG_: "")
                temp.STATUS = responseObject?["STATUS"] as! String
                temp.MSG_ = responseObject?["MSG_"] as! String
                
                if temp.STATUS == "SUCCESS" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                    
                    
                    if temp.MSG_ == "El doctor favorito ha sido desvinculado exitosamente" {
                        
                        self.Btn_DoctorLikeButton.setBackgroundImage(#imageLiteral(resourceName: "4_Add_Heart.png"), for: .normal)    //4_Add_Heart.png
                        self.tryGetFavariteDoctorsAll()
                        
                    }
                    
                }
                if temp.STATUS == "ERROR" {
                    self.view.makeToast(temp.MSG_, duration: 3.0, position: .bottom)
                }
                
            }
            else {
                print("~~~~~~~~~~ Error ~~~~~~~~~~")
            }
        })
    }
    
    // 7. http://67.205.136.161:8070/DocAppointments/rest/patient/favorite/all
    func tryGetFavariteDoctorsAll() {
        
        g_favarite_Doctors_Array.removeAll()
        
        
        let params: NSDictionary = [
            "authorization": [
                "patientID": 1,
                "loginPolicy": "USRPASSWD",
                "eml": "juanperez@gmail.com",
                "psswd":"Prueba123"
            ],
            "patientID": g_patientID
        ]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Get_Favarite_Doctors, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                for data in responseObject! {
                    print(data)
                    
                    let dict = data as! [String: AnyObject]
                    
                    var temp: favarite_Doctor_Infor = favarite_Doctor_Infor(favoriteID: -1, doctorID: -1, hospital_id: -1, firstname: "", lastname: "", special: "", hospitalname: "", hospitaldireccion: "", hospitaltelefono: "")
                    
                    temp.favoriteID = dict["favoriteID"] as! Int
                    temp.doctorID = dict["doctorID"] as! Int
                    
                    let dict_1 = dict["hospital"] as! [String: AnyObject]
                    temp.hospital_id = dict_1["id"] as! Int
                    temp.hospitalname = dict_1["nombre"] as! String
                    temp.hospitaldireccion = dict_1["direccion"] as! String
                    temp.hospitaltelefono = dict_1["telefono"] as! String
                    
                    let dict_2 = dict["information"] as! [String: AnyObject]
                    temp.firstname = dict_2["nombre"] as! String
                    temp.lastname = dict_2["apellido"] as! String
                    
                    let dict_3 = dict["specialty"] as! [String: AnyObject]
                    temp.special = dict_3["nombre"] as! String
                    
                    g_favarite_Doctors_Array.append(temp)
                }
                
                print(g_favarite_Doctors_Array)
                print(g_favarite_Doctors_Array.count)
                
                g_Current_Index = g_favarite_Doctors_Array.count - 1
                
                
                //self.view.makeToast("You have successfully received all infors.", duration: 3.0, position: .bottom)
                
                //                self.singleton.email = self.textfieldEmail.text!
                //                self.singleton.password = self.textfieldPassword.text!
                
                
                
            }
            else {
                
            }
        })
    }

    
    
        
        
        
        
        
        
    
}
