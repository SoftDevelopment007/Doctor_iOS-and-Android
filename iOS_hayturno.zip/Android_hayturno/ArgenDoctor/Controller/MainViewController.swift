//
//  MainViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 5/24/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    let GlobalVar = Global()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()      
        
        
        // Get All Init Infors from Backend...
        tryObrasocialAll()
        tryGetFavariteDoctorsAll()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func onTappedGoStepSearchBtn(_ sender: Any) {
        
        
        let bSignUped = UserDefaults.standard.bool(forKey: "SignUped")
        if (bSignUped) {
            
            //Already SignUp.
            let Temp_patientID = UserDefaults.standard.integer(forKey: "g_patientID")
            if Temp_patientID < 2 {
                g_patientID = 1
            } else {
                
                //===================================================================
                //                                                                 //
                //  All Initial Input                                              //
                //
                
                g_patientID = Temp_patientID
                
                //
                //
                //
                //===================================================================
            }
            performSegue(withIdentifier: StorySegues.FromMainToSignIn.rawValue, sender: self)
        } else {
            
            //First Initial Running.
            g_patientID = 1
            self.performSegue(withIdentifier: StorySegues.FromMainToStepSearch.rawValue, sender: self)
        }
        
    }
    
    //Loading Infors =======================================================================================
    
    // 23. http://67.205.136.161:8070/DocAppointments/rest/patient/obrasocial/all
    // var g_InitSocialWork_Array = ["Boreal", "Prensa"]
    func tryObrasocialAll() {
        let params: NSDictionary = [:]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.OBRASOCIAL_ALL, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {

                for data in responseObject! {
                    print(data)
                    
                    let nombre = data as! [String: AnyObject]
                    g_InitSocialWork_Array.append(nombre["nombre"] as! String)
                    
                }
                
                print(g_InitSocialWork_Array)
                print(g_InitSocialWork_Array.count)
                
                
                //self.view.makeToast("You have successfully received all infors.", duration: 3.0, position: .bottom)
                
//                self.singleton.email = self.textfieldEmail.text!
//                self.singleton.password = self.textfieldPassword.text!
                
                
                
            }
            else {
                
            }
        })
    }
    
    // 7. http://67.205.136.161:8070/DocAppointments/rest/patient/favorite/all
    func tryGetFavariteDoctorsAll() {
        
        g_favarite_Doctors_Array.removeAll()
        
        
        let params: NSDictionary = [
            "authorization": [
                "patientID": 1,
                "loginPolicy": "USRPASSWD",
                "eml": "juanperez@gmail.com",
                "psswd":"Prueba123"
            ],
            "patientID": g_patientID
        ]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Get_Favarite_Doctors, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                for data in responseObject! {
                    print(data)
                    
                    let dict = data as! [String: AnyObject]
                    
                    var temp: favarite_Doctor_Infor = favarite_Doctor_Infor(favoriteID: -1, doctorID: -1, hospital_id: -1, firstname: "", lastname: "", special: "", hospitalname: "", hospitaldireccion: "", hospitaltelefono: "")
                    
                    temp.favoriteID = dict["favoriteID"] as! Int
                    temp.doctorID = dict["doctorID"] as! Int
                    
                    let dict_1 = dict["hospital"] as! [String: AnyObject]
                    temp.hospital_id = dict_1["id"] as! Int
                    temp.hospitalname = dict_1["nombre"] as! String
                    temp.hospitaldireccion = dict_1["direccion"] as! String
                    temp.hospitaltelefono = dict_1["telefono"] as! String
                    
                    let dict_2 = dict["information"] as! [String: AnyObject]
                    temp.firstname = dict_2["nombre"] as! String
                    temp.lastname = dict_2["apellido"] as! String
                    
                    let dict_3 = dict["specialty"] as! [String: AnyObject]
                    temp.special = dict_3["nombre"] as! String

                    g_favarite_Doctors_Array.append(temp)
                }
                
                print(g_favarite_Doctors_Array)
                print(g_favarite_Doctors_Array.count)
                
                
                //self.view.makeToast("You have successfully received all infors.", duration: 3.0, position: .bottom)
                
                //                self.singleton.email = self.textfieldEmail.text!
                //                self.singleton.password = self.textfieldPassword.text!
                
                
                
            }
            else {
                
            }
        })
    }


}

extension String {
    var length: Int {
        return self.characters.count
    }
}
