//
//  SignInViewController.swift
//  ArgenDoctor
//
//  Created by LEE on 6/9/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit
import JVFloatLabeledTextField

import FBSDKCoreKit
import FBSDKLoginKit

import Firebase
import GoogleSignIn

import FirebaseAuth

class SignInViewController: UIViewController, GIDSignInUIDelegate, GIDSignInDelegate {

    let GlobalVar = Global()
    
    @IBOutlet weak var View_HaveButtons: UIView!
    @IBOutlet weak var View_HaveEdits: UIView!
    
    @IBOutlet weak var TxtEmail: JVFloatLabeledTextField!
    @IBOutlet weak var TxtPassword: JVFloatLabeledTextField!
    
    @IBOutlet weak var imageView_Email: UIImageView!
    @IBOutlet weak var imageView_Password: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        View_HaveEdits.isHidden = true
        
        //Google
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        
        
        let bSignIned = UserDefaults.standard.bool(forKey: "SignIned")
        if (bSignIned) {
            
            let Temp_patientID = UserDefaults.standard.integer(forKey: "g_patientID")
            if Temp_patientID < 2 {
                g_patientID = 1
            } else {
                
                //===================================================================
                //                                                                 //
                //  All Initial Input                                              //
                //
                
                g_patientID = Temp_patientID
                
                //
                //
                //
                //===================================================================
            }

            
            g_ProfileInfo.email = UserDefaults.standard.string(forKey: "email")!
            g_ProfileInfo.password = UserDefaults.standard.string(forKey: "password")!
            
            if let imageData = UserDefaults.standard.value(forKey: "avatarImage") as? Data {
                g_ProfileInfo.avatarimage = Utils.profileImage(image: UIImage(data: imageData as Data)!)
            }
            
            trySignIn()
            
            
            
            
            
            //
            
            
            /*let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
            let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
            rearView.delegate = frontView
            let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
            self.navigationController?.pushViewController(swViewController!, animated: true)
            //performSegue(withIdentifier: StorySegues.FromSignInToHomView.rawValue, sender: self)*/
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        View_HaveButtons.isHidden = false
        View_HaveEdits.isHidden = true
    }
    //Facebook and Google and Email SignIn ------------------------
    @IBAction func onTappedFaceBookBtn(_ sender: Any) {
        
 
        FBSDKLoginManager().logIn(withReadPermissions: ["email", "public_profile"], from: self) { (result, err) in
            
            if err != nil {
                ProgressHUD.dismiss()
                print("FB login failed: \(err)")
                return
            }
 
            self.showEmailAddress()
        }
    }
    
    func showEmailAddress() {
        
        let accessToken = FBSDKAccessToken.current()
        guard let accessTokenString = accessToken?.tokenString else { return }
        
        let credentials = FIRFacebookAuthProvider.credential(withAccessToken: accessTokenString)
        
        ProgressHUD.show()
        
        FIRAuth.auth()?.signIn(with: credentials, completion: { (user, error) in
            if error != nil {
                print("Something is wrong with FB user: \(error)")
            }
            
            //print("successfully logged in with our user: \(user)")
        })
        
        //FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "email, id, name"]).start { (connection, result, err) in
        FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "id, name, first_name, last_name, email, picture.type(normal), link"]).start { (connection, result, err) in
            
            if err != nil {
                print("failed to login: \(err)")
                return
            }
            
            //print(result ?? "")
            
            
            
            guard let userInfo = result as? [String: Any] else { return } //handle the error
            //The url is nested 3 layers deep into the result so it's pretty messy
            if let imageURL = ((userInfo["picture"] as? [String: Any])?["data"] as? [String: Any])?["url"] as? String {
                //Download image from imageURL
                //print(imageURL)
                
                if let imageData: NSData = NSData(contentsOf: NSURL(string: imageURL) as! URL) {
                    g_ProfileInfo.avatarimage = Utils.profileImage(image: UIImage(data: imageData as Data)!)
                }
            }
            
            
            //-----------------------------------------------------------
            let data:[String:AnyObject] = result as! [String : AnyObject]
            
            //print(data)
            
            let uid : NSString? = data["id"]! as? NSString
            let userName : NSString? = data["name"]! as? NSString
            let firstName : NSString? = data["first_name"]! as? NSString
            let lastName : NSString? = data["last_name"]! as? NSString
            let email : NSString? = data["email"]! as? NSString
            
            /*print(uid)
             print(userName!)
             print(firstName!)
             print(lastName!)
             print(email!)*/
            
            
            //=====================================================================================================
            
            g_ProfileInfo.name = userName! as String
            g_ProfileInfo.firstname = firstName! as String
            g_ProfileInfo.lastname = lastName! as String
            g_ProfileInfo.email = email! as String
            
            
            //---------------------------------------------------------
            let tempPass: String = (uid as! String)
            let length_before = tempPass.length
            
            g_ProfileInfo.password = "Un" + (tempPass as! String)
            var length_after = length_before + 2
            length_after = g_ProfileInfo.password.length
            
            if length_after < 17 {
                
                //length_after
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: length_after)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            } else {
                
                //16
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: 16)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            }
            //----------------------------------------------------------
            
            
            print(g_ProfileInfo.email)
            print(g_ProfileInfo.password)
            
            self.trySignIn()
            
            
            //=====================================================================================================
        }
    }

    
    
    @IBAction func onTappedGoogleBtn(_ sender: Any) {
        
        GIDSignIn.sharedInstance().signIn()
    }

    func signIn(_ signIn: GIDSignIn!, didDisconnectWithUser user: GIDGoogleUser!, withError error: NSError!) {
        
    }
    
    func sign( _ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        
        if let err = error {
            print("Failed to log in with Google: \(err)")
            return
        }
        else {
            //print("Successfully logged in with Goodle: \(user)")
            
            ProgressHUD.show()
            
            guard let idToken = user.authentication.idToken else { return }
            guard let accessToken = user.authentication.accessToken else { return }
            
            let userId = user.userID
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
            
            if user.profile.hasImage
            {
                let pic = user.profile.imageURL(withDimension: 100)
                //print(pic)
                
                if let imageData: NSData = NSData(contentsOf: pic!) {
                    g_ProfileInfo.avatarimage = Utils.profileImage(image: UIImage(data: imageData as Data)!)
                }
            }
            
            /*print(userId)
             print(fullName)
             print(givenName)
             print(familyName)
             print(email)*/
            
            
            
            //=======================================================================================================
            g_ProfileInfo.name = fullName!
            g_ProfileInfo.firstname = givenName!
            g_ProfileInfo.lastname = familyName!
            g_ProfileInfo.email = email!
            
            
            //------------------------------------------------------
            let tempPass: String = userId!
            let length_before = tempPass.length
            
            g_ProfileInfo.password = "Un" + (tempPass as! String)
            var length_after = length_before + 2
            length_after = g_ProfileInfo.password.length
            
            if length_after < 17 {
                
                //length_after
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: length_after)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            } else {
                
                //16
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: 16)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            }
            //--------------------------------------------------------

            
            print(g_ProfileInfo.email)
            print(g_ProfileInfo.password)
            
            self.trySignIn()
            
            
            //
            //======================================================================================================
        }
    }

    
    
    @IBAction func onTappedMailBtn(_ sender: Any) {
        //View_HaveButtons.isHidden = true
        //View_HaveEdits.isHidden = false
        
        View_HaveButtons.fadeOut()
        
        // do stuff 0.5 seconds later
        let when = DispatchTime.now() + 0.5 // change 2 to desired number of seconds
        DispatchQueue.main.asyncAfter(deadline: when) {
            // Your code with delay
            self.View_HaveEdits.isHidden = false
            self.View_HaveEdits.fadeIn()
        }
        
    }
    
    

    
    //Go to next page and Cancel ---------------------------------
    @IBAction func onTappedGotoNextPage(_ sender: Any) {
        
        //
        if InputAllParameters() {
            
            g_ProfileInfo.email = TxtEmail.text!

            
            
            //------------------------------------------------------
            let tempPass: String = TxtPassword.text!
            let length_before = tempPass.length
            
            g_ProfileInfo.password = "Un" + (tempPass as! String)
            var length_after = length_before + 2
            length_after = g_ProfileInfo.password.length
            
            if length_after < 17 {
                
                //length_after
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: length_after)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            } else {
                
                //16
                let startIndex = g_ProfileInfo.password.index(g_ProfileInfo.password.startIndex, offsetBy: 16)
                g_ProfileInfo.password = g_ProfileInfo.password.substring(to: startIndex)
            }
            //--------------------------------------------------------
            
            
            print(g_ProfileInfo.email)
            print(g_ProfileInfo.password)
            
            trySignIn()
            
/*            let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
            let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
            rearView.delegate = frontView
            let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
            self.navigationController?.pushViewController(swViewController!, animated: true)
            //performSegue(withIdentifier: StorySegues.FromSignInToHomView.rawValue, sender: self)
 */
        }
    }
    @IBAction func onTappedCancelButton(_ sender: Any) {
        
        g_LoginFlag = false
        
        View_HaveEdits.fadeOut()
        
        // do stuff 0.5 seconds later
        let when = DispatchTime.now() + 0.5 // change 2 to desired number of seconds
        DispatchQueue.main.asyncAfter(deadline: when) {
            // Your code with delay
            self.View_HaveButtons.fadeIn()
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    //Email and Password Check -----------------------------------
    @IBAction func onTappedShowToast_EmailCheck(_ sender: Any) {
        if imageView_Email.image == #imageLiteral(resourceName: "Icon_Red_Alert") {
            if TxtEmail.text == "" {
                self.view.makeToast("Por favor, introduzca el campo de correo electrónico.")
            } else {
                if TxtEmail.text?.isEmail == false {
                    self.view.makeToast("El tipo de correo electrónico no es válido.")
                }
            }
        }
    }
    @IBAction func onTappedShowToast_PasswordCheck(_ sender: Any) {
        if imageView_Password.image == #imageLiteral(resourceName: "Icon_Red_Alert") {
            if TxtPassword.text == "" {
                self.view.makeToast("Por favor, introduzca el campo de contraseña.")
            } else {
                if TxtPassword.text?.isValidPassword == false {
                    self.view.makeToast("El tipo de contraseña no es válido.")
                }
            }
        }
    }
    
    //check true or false values.
    func InputAllParameters() -> (Bool) {
        
        var Flag: Bool = true
        
        
        if TxtEmail.text == "" {
            
            Flag = false
            imageView_Email.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("Por favor, introduzca el campo de correo electrónico.")
        }else{
            imageView_Email.image = nil
        }
        
        if TxtEmail.text?.isEmail == false {
            
            Flag = false
            imageView_Email.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("El tipo de correo electrónico no es válido.")
        } else {
            imageView_Email.image = nil
        }
        
        if TxtPassword.text == "" {
            
            Flag = false
            imageView_Password.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("Por favor, introduzca el campo de contraseña.")
        }
        if TxtPassword.text?.isValidPassword == false {
            
            Flag = false
            imageView_Password.image = #imageLiteral(resourceName: "Icon_Red_Alert")
            //self.view.makeToast("El tipo de contraseña no es válido.")
        } else {
            imageView_Password.image = nil
        }
        
        return Flag
    }
    
    // Get Initial Favarite data
    // 7. http://67.205.136.161:8070/DocAppointments/rest/patient/favorite/all
    func tryGetFavariteDoctorsAll() {
        
        g_favarite_Doctors_Array.removeAll()
        
        
        let params: NSDictionary = [
            "authorization": [
                "patientID": 1,
                "loginPolicy": "USRPASSWD",
                "eml": "juanperez@gmail.com",
                "psswd":"Prueba123"
            ],
            "patientID": g_patientID
        ]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Get_Favarite_Doctors, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                for data in responseObject! {
                    print(data)
                    
                    let dict = data as! [String: AnyObject]
                    
                    var temp: favarite_Doctor_Infor = favarite_Doctor_Infor(favoriteID: -1, doctorID: -1, hospital_id: -1, firstname: "", lastname: "", special: "", hospitalname: "", hospitaldireccion: "", hospitaltelefono: "")
                    
                    temp.favoriteID = dict["favoriteID"] as! Int
                    temp.doctorID = dict["doctorID"] as! Int
                    
                    let dict_1 = dict["hospital"] as! [String: AnyObject]
                    temp.hospital_id = dict_1["id"] as! Int
                    temp.hospitalname = dict_1["nombre"] as! String
                    temp.hospitaldireccion = dict_1["direccion"] as! String
                    temp.hospitaltelefono = dict_1["telefono"] as! String
                    
                    let dict_2 = dict["information"] as! [String: AnyObject]
                    temp.firstname = dict_2["nombre"] as! String
                    temp.lastname = dict_2["apellido"] as! String
                    
                    let dict_3 = dict["specialty"] as! [String: AnyObject]
                    temp.special = dict_3["nombre"] as! String
                    
                    g_favarite_Doctors_Array.append(temp)
                }
                
                print(g_favarite_Doctors_Array)
                print(g_favarite_Doctors_Array.count)
                
                
                let frontView = self.storyboard?.instantiateViewController(withIdentifier: "MyShiftViewControllerVC") as! MyShiftViewController
                let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                rearView.delegate = frontView
                let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                self.navigationController?.pushViewController(swViewController!, animated: true)
                //performSegue(withIdentifier: StorySegues.FromSignInToHomView.rawValue, sender: self)
                
                
                
                //self.view.makeToast("You have successfully received all infors.", duration: 3.0, position: .bottom)
                
                //                self.singleton.email = self.textfieldEmail.text!
                //                self.singleton.password = self.textfieldPassword.text!
                
                
                
            }
            else {
                
            }
        })
    }
    
    
    // Get SignIn data
    // http://67.205.136.161:8070/DocAppointments/rest/patient/login
    func trySignIn() {
        
        g_patientID = -1
        
        g_ProfileInfo.firstname = ""
        g_ProfileInfo.lastname = ""
        g_ProfileInfo.name = ""
        //g_ProfileInfo.email = ""
        //g_ProfileInfo.password = ""
        g_ProfileInfo.birthday = ""
        g_ProfileInfo.phone = ""
        g_ProfileInfo.gender = -1
        g_ProfileInfo.dni = ""
        g_ProfileInfo.socialwork = -1
        g_ProfileInfo.afiliadonumber = ""
        //g_ProfileInfo.avatarimage = #imageLiteral(resourceName: "7_AnonymousImag.png")  // 7_AnonymousImag.png 3_RegisterCenterPhoto.png
        
        let params: NSDictionary = [    "loginPolicy": "USRPASSWD",
                                        "eml": g_ProfileInfo.email,
                                        "psswd": g_ProfileInfo.password
                                    ]

        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue_NSDictionary(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.SignIn_Patient, parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
            
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                // SignIn Error?
                /*{
                 "STATUS": "ERROR",
                 "CODE": "INVALID_CREDENTIALS",
                 "MSG_": "Credenciales de acceso invalidas"
                }*/
                
                //temp.MSG_ = responseObject?["MSG_"] as! String
                
                /*if let dict_error = responseObject?["STATUS"] {
                    
                    if dict_error as! String == "ERROR" {
                        let temp_msg = responseObject?["MSG_"] as! String
                        
                        self.view.makeToast(temp_msg, duration: 3.0, position: .bottom)
                        return
                    }
                }*/
                
                
                g_patientID = responseObject?["patientID"] as! Int
                
                g_ProfileInfo.firstname = responseObject?["nombre"] as! String
                g_ProfileInfo.lastname = responseObject?["apellido"] as! String
                g_ProfileInfo.name = g_ProfileInfo.firstname + " " + g_ProfileInfo.lastname
                g_ProfileInfo.dni = responseObject?["dni"] as! String
                g_ProfileInfo.gender = responseObject?["sexo"] as! Int
                g_ProfileInfo.birthday = responseObject?["fechaNacimiento"] as! String
                g_ProfileInfo.phone = responseObject?["telefono"] as! String
                
                
                //let obraSocialInfo_dict = responseObject?["obraSocialInfo"] as! NSDictionary
                //g_ProfileInfo.socialwork = -1
                g_ProfileInfo.afiliadonumber = responseObject?["numObraSocial"] as! String
                //g_ProfileInfo.avatarimage = #imageLiteral(resourceName: "7_AnonymousImag.png")  // 7_AnonymousImag.png 3_RegisterCenterPhoto.png
                
                
                /*"nombre": "Hobi",
                "apellido": "Somi",
                "dni": "12345678",
                "sexo": 1,
                "fechaNacimiento": "12-06-1985",
                "telefono": "12345678",
                "celular": "12345678",
                "email": "Hobi@mail.com",
                "estado": 1,
                "numObraSocial": "1234567",
                "googleUserId": null,
                "obraSocialInfo": {
                    "id": 1,
                    "nombre": "Boreal",
                    "estado": "ACT"
                },
                "personType": "PATIENT",
                "hospitalID": 2,
                "doctorID": null,
                "patientID": 264,
                "provinceID": 24,
                "assistantID": null,
                "locationID": 27859,
                "personID": 321*/
                
                //=========================
                
                g_LoginFlag = true
                UserDefaults.standard.set(true, forKey: "SignIned")
                UserDefaults.standard.set(g_ProfileInfo.email, forKey: "email")
                UserDefaults.standard.set(g_ProfileInfo.password, forKey: "password")
                
                //print(g_ProfileInfo.avatarimage)
                UserDefaults.standard.set(UIImageJPEGRepresentation(g_ProfileInfo.avatarimage, 100), forKey: "avatarImage")
                
                self.tryGetFavariteDoctorsAll()
                //=========================
                
            }
            else {
                
            }
        })
    }

    
}


extension UIView {
    
    func fadeIn(duration: TimeInterval = 0.5,
                delay: TimeInterval = 0.0,
                completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in }) {
        UIView.animate(withDuration: duration,
                       delay: delay,
                       options: UIViewAnimationOptions.curveEaseIn,
                       animations: {
                        self.alpha = 1.0
        }, completion: completion)
    }
    
    func fadeOut(duration: TimeInterval = 0.5,
                 delay: TimeInterval = 0.0,
                 completion: @escaping (Bool) -> Void = {(finished: Bool) -> Void in }) {
        UIView.animate(withDuration: duration,
                       delay: delay,
                       options: UIViewAnimationOptions.curveEaseIn,
                       animations: {
                        self.alpha = 0.0
        }, completion: completion)
    }
}
