//
//  adminSideMenu.swift
//  Hoopoe
//
//  Created by PRK on 2/25/17.
//  Copyright © 2017 rising. All rights reserved.
//

import Foundation
import UIKit

protocol SideMenuViewDelegate {
    
    func onTapNuevoTurnoButton(sender:AnyObject) -> Void
    func onTapMisTurnosButton(sender: AnyObject) -> Void
    func onTapMisMedicosButton(sender: AnyObject) -> Void
    func onTapDatosPersonalesButton(sender:AnyObject) -> Void
    func onTapCerrarSesionButton(sender: AnyObject) -> Void
}

class adminSideMenu: UIViewController{
    

    var delegate: SideMenuViewDelegate?
    
    @IBOutlet weak var buttonAvatar: UIButton!    
    @IBOutlet weak var textUserName: UILabel!
    
    
    
    
    @IBOutlet weak var imageNuevoTurno: UIImageView!
    @IBOutlet weak var btnNuevoTurno: UIButton!
 
    @IBOutlet weak var imageMisTurnos: UIImageView!
    @IBOutlet weak var btnMisTurnos: UIButton!
    
    @IBOutlet weak var imageMisMedicos: UIImageView!
    @IBOutlet weak var btnMisMedicos: UIButton!
    
    @IBOutlet weak var imageDatosPersonales: UIImageView!
    @IBOutlet weak var btnDatosPersonales: UIButton!
    
    @IBOutlet weak var imageCerrarSesion: UIImageView!
    @IBOutlet weak var btnCerrarSesion: UIButton!
    
    func RedAnimation() {
        
        switch curSel {
        case 0:
            
            btnNuevoTurno.setTitleColor(.black, for: .normal)
            btnMisTurnos.setTitleColor(.black, for: .normal)
            btnMisMedicos.setTitleColor(.black, for: .normal)
            btnDatosPersonales.setTitleColor(.black, for: .normal)
            btnCerrarSesion.setTitleColor(.black, for: .normal)
            
        case 1:
            btnNuevoTurno.setTitleColor(.red, for: .normal)
            btnMisTurnos.setTitleColor(.black, for: .normal)
            btnMisMedicos.setTitleColor(.black, for: .normal)
            btnDatosPersonales.setTitleColor(.black, for: .normal)
            btnCerrarSesion.setTitleColor(.black, for: .normal)
            
        case 2:
            btnNuevoTurno.setTitleColor(.black, for: .normal)
            btnMisTurnos.setTitleColor(.red, for: .normal)
            btnMisMedicos.setTitleColor(.black, for: .normal)
            btnDatosPersonales.setTitleColor(.black, for: .normal)
            btnCerrarSesion.setTitleColor(.black, for: .normal)

        case 3:
            btnNuevoTurno.setTitleColor(.black, for: .normal)
            btnMisTurnos.setTitleColor(.black, for: .normal)
            btnMisMedicos.setTitleColor(.red, for: .normal)
            btnDatosPersonales.setTitleColor(.black, for: .normal)
            btnCerrarSesion.setTitleColor(.black, for: .normal)

        case 4:
            btnNuevoTurno.setTitleColor(.black, for: .normal)
            btnMisTurnos.setTitleColor(.black, for: .normal)
            btnMisMedicos.setTitleColor(.black, for: .normal)
            btnDatosPersonales.setTitleColor(.red, for: .normal)
            btnCerrarSesion.setTitleColor(.black, for: .normal)
            
        case 5:
            btnNuevoTurno.setTitleColor(.black, for: .normal)
            btnMisTurnos.setTitleColor(.black, for: .normal)
            btnMisMedicos.setTitleColor(.black, for: .normal)
            btnDatosPersonales.setTitleColor(.black, for: .normal)
            btnCerrarSesion.setTitleColor(.red, for: .normal)
            
        default: break
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        curSel = 0
        RedAnimation()
        
    }
    
    //DownLoad Cover and User Image
    override func viewWillAppear(_ animated: Bool) {
        
        textUserName.text = g_ProfileInfo.name
        self.buttonAvatar.setBackgroundImage(g_ProfileInfo.avatarimage, for: .normal)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        textUserName.text = g_ProfileInfo.name
        self.buttonAvatar.setBackgroundImage(g_ProfileInfo.avatarimage, for: .normal)
    }
    
    @IBAction func onTapNuevoTurnoButton(_ sender: Any) {
        
        curSel = 1
        RedAnimation()
        
        self.revealViewController().revealToggle(animated: true)
        self.delegate?.onTapNuevoTurnoButton(sender: sender as AnyObject)

    }

    @IBAction func onTapMisTurnosButton(_ sender: Any) {
        
        curSel = 2
        RedAnimation()
        
        self.revealViewController().revealToggle(animated: true)
        self.delegate?.onTapMisTurnosButton(sender: sender as AnyObject)
    }
    
    @IBAction func onTapMisMedicosButton(_ sender: Any) {
        
        curSel = 3
        RedAnimation()
        
        self.revealViewController().revealToggle(animated: true)
        self.delegate?.onTapMisMedicosButton(sender: sender as AnyObject)
    }
    
    @IBAction func onTapDatosPersonalesButton(_ sender: Any) {
        
        curSel = 4
        RedAnimation()
        
        self.revealViewController().revealToggle(animated: true)
        self.delegate?.onTapDatosPersonalesButton(sender: sender as AnyObject)
    }    

    @IBAction func onTapCerrarSesionButton(_ sender: Any) {
        
        curSel = 5
        RedAnimation()
        
        self.revealViewController().revealToggle(animated: true)
        self.delegate?.onTapCerrarSesionButton(sender: sender as AnyObject)
    }
}
