package com.hayturnoapp.models;

/**
 * Created by Nicolas on 19/10/2016.
 */

public class HorariosDoctor {
    private String fechahoras;

    public String getFechahoras() {
        return fechahoras;
    }

    public void setFechahoras(String fechahoras) {
        this.fechahoras = fechahoras;
    }
}
