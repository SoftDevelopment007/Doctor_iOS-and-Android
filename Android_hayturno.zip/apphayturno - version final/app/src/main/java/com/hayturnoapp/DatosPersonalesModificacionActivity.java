package com.hayturnoapp;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.hayturnoapp.models.Autorizacion;
import com.hayturnoapp.models.InfoPaciente;
import com.hayturnoapp.models.JsResId;
import com.hayturnoapp.models.JsonResSimple;
import com.hayturnoapp.models.ObraSocial;
import com.hayturnoapp.utils.ExceptionHandler;
import com.hayturnoapp.utils.RestClient;
import com.hayturnoapp.utils.Session;
import com.hayturnoapp.utils.Utils;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.koushikdutta.ion.ProgressCallback;
import com.koushikdutta.ion.Response;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;
import com.mindorks.paracamera.Camera;
import com.tmxlr.lib.driodvalidatorlight.Form;
import com.tmxlr.lib.driodvalidatorlight.helper.Range;
import com.tmxlr.lib.driodvalidatorlight.helper.RegexTemplate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;


import cz.msebera.android.httpclient.Header;



public class DatosPersonalesModificacionActivity extends AppCompatActivity {
    private Session sesion;

    private EditText etFechaNacimiento;
    private SimpleDateFormat dateFormatter;
    private DatePickerDialog dpdFechaNacimiento;
    ProgressDialog progreso;


    private Drawer resultDrawer;
    private AccountHeader headerResult;

    private String[] activityTitles;

    private Spinner dropdownObraSocial;
    private Spinner dropdownGenero;
    private EditText etDni;
    private EditText etCelular;
    private EditText etNoAfiliado;
    private EditText tvNombre;
    private EditText tvCorreo;
    private EditText tvApellido;
    private ImageView IVFotoPerfil;
    private Integer provicinaID;
    private Integer locationID;

    private Camera camera;
    private String FotoGuardada;

    private Button btnActualizacion;
    ProgressDialog dlg;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // manejador de error
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setContentView(R.layout.fragment_datos_personales);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        sesion = new Session(this);
        sesion.checkLogin();

        progreso = new ProgressDialog(this, R.style.ThemePD);
        progreso.setMessage("");
        progreso.setIndeterminate(false);
        progreso.setCancelable(false);
        progreso.setProgressStyle(android.R.style.Widget_ProgressBar_Small);


        camera = new Camera(this);

        provicinaID = 0;
        locationID = 0;

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

        activityTitles = getResources().getStringArray(R.array.nav_item_activity_titles);

        String directorioFotoUsuario =  sesion.getDirectorioFotoUsuario();
        Utils u = new Utils();

        btnActualizacion = (Button) findViewById(R.id.buttonComenzar);

        dropdownObraSocial = (Spinner) findViewById(R.id.spinnerObrasocial);
        dropdownGenero = (Spinner) findViewById(R.id.spinnerGenero);
        etDni = (EditText) findViewById(R.id.editTextDni);
        etCelular = (EditText) findViewById(R.id.editTextCelular);
        etNoAfiliado = (EditText) findViewById(R.id.editTextNoAfiliado);
        tvNombre = (EditText) findViewById(R.id.editTextNombre);
        tvApellido = (EditText) findViewById(R.id.editTextApellido);
        tvCorreo = (EditText) findViewById(R.id.editTextMail);
        etFechaNacimiento = (EditText) findViewById(R.id.editTextFechaNacimiento);
        IVFotoPerfil = (ImageView) findViewById(R.id.FotoPersona);

        FotoGuardada = "";

        if( directorioFotoUsuario == null)
            directorioFotoUsuario = "";

        if(directorioFotoUsuario.isEmpty())
          Glide.with(this).load("").centerCrop().placeholder(R.drawable.foto_persona_v2).into(IVFotoPerfil);
        else
          Glide.with(this).load( u.getFilefromPath(directorioFotoUsuario) ).centerCrop().placeholder(R.drawable.foto_persona_v2).into(IVFotoPerfil);


        //seteamos la funcion
        btnActualizacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActualizacion();
            }
        });

        //seteamos side app bar
        if (sesion.isLoggedIn()) {
            toolbar.setNavigationIcon(R.drawable.ic_menu);
            HashMap<String, String> user = sesion.getDetalleUsuario();

            final ProfileDrawerItem datoUsuario = new ProfileDrawerItem();
            datoUsuario.withName(user.get(sesion.KEY_NAME));

            if( directorioFotoUsuario == null)
                directorioFotoUsuario = "";

            if( !directorioFotoUsuario.isEmpty() )
                datoUsuario.withIcon(u.loadImageFromStorage(directorioFotoUsuario));
            else
                datoUsuario.withIcon(getResources().getDrawable(R.drawable.foto_persona));

            headerResult = new AccountHeaderBuilder()
                    .withActivity(this)
                    .withHeaderBackground(R.color.colorBackBlueLight)
                    .addProfiles(datoUsuario)
                    .withSelectionListEnabledForSingleProfile(false)
                    .build();



            //agregamos el menu de navegacion
            resultDrawer = new DrawerBuilder()
                    .withActivity(this)
                    .withToolbar(toolbar)
                    .withAccountHeader(headerResult)
                    .addDrawerItems(
                            new PrimaryDrawerItem().withName(activityTitles[0]).withIcon(R.drawable.icon_search).withIdentifier(1),
                            new PrimaryDrawerItem().withName(activityTitles[1]).withIcon(R.drawable.icon_agenda).withIdentifier(2),
                            new PrimaryDrawerItem().withName(activityTitles[2]).withIcon(R.drawable.icon_mis_medicos).withIdentifier(3),
                            new PrimaryDrawerItem().withName(activityTitles[3]).withIcon(R.drawable.icon_datos_personales).withIdentifier(4),
                            new PrimaryDrawerItem().withName(activityTitles[4]).withIcon(R.drawable.icon_close_session).withIdentifier(5)
                    )
                    .withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
                        @Override
                        public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                            //revisamos si drawerItem esta seteado
                            //drawerItem puede ser nulo por diferentes razones
                            //--> click en encaebzado
                            //--> click en el pie
                            // esos items no contiene drawerItem
                            if (drawerItem != null) {
                                Intent intent = null;
                                int identificador = (int) drawerItem.getIdentifier();
                                switch (identificador) {
                                    case 1:
                                        intent = new Intent(DatosPersonalesModificacionActivity.this, BusquedaTurnoActivity.class);
                                        break;
                                    case 2:
                                        intent = new Intent(DatosPersonalesModificacionActivity.this, CalendariosTurnoActivity.class);
                                        break;
                                    case 3:
                                        intent = new Intent(DatosPersonalesModificacionActivity.this, MisMedicosActivity.class);
                                        break;
                                    case 4:
                                        break;
                                    case 5:
                                        signOut();
                                        break;

                                }

                                if (intent != null) {
                                    DatosPersonalesModificacionActivity.this.startActivity(intent);
                                }
                            }
                            return false;
                        }
                    })
                    .build();
        }

        progreso.show();

        setearFechasDatepicker();
        llenarSpinner();

        try {
            extraerDataUsuario();
        } catch (JSONException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        camera.builder()
                .resetToCorrectOrientation(true)// it will rotate the camera bitmap to the correct orientation from meta data
                .setDirectory("pics")
                .setName("HayTurno_" + System.currentTimeMillis())
                .setImageFormat(Camera.IMAGE_PNG)
                .setCompression(75)
                .setImageHeight(1000);// it will try to achieve this height as close as possible maintaining the aspect ratio;

        // programamos el boton de la camara
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    camera.takePicture();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });



        dlg = new ProgressDialog(this);
        dlg.setTitle("Cargando Foto...");
        dlg.setIndeterminate(false);
        dlg.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Camera.REQUEST_TAKE_PHOTO) {
            Bitmap foto = camera.getCameraBitmap();
            if (foto != null)
            {
                ImageView fotoperfil = (ImageView) findViewById(R.id.FotoPersona);
                Glide.with(this).load(camera.getCameraBitmapPath()).centerCrop().fitCenter().into(fotoperfil);


            } else {
                Toast.makeText(this.getApplicationContext(), "No se tomo foto!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        camera.deleteImage(); //Borramos imagen
        camera = null;
    }

    private void setearFechasDatepicker() {

        etFechaNacimiento.setInputType(InputType.TYPE_NULL);
        etFechaNacimiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dpdFechaNacimiento.show();
            }
        });

        Calendar calendario = Calendar.getInstance();
        dpdFechaNacimiento = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar fecha = Calendar.getInstance();
                fecha.set(year, monthOfYear, dayOfMonth);
                etFechaNacimiento.setText(dateFormatter.format(fecha.getTime()));
            }

        }, calendario.get(Calendar.YEAR), calendario.get(Calendar.MONTH), calendario.get(Calendar.DAY_OF_MONTH));
    }

    private void llenarSpinner() {
        ArrayList<String> generoList = new ArrayList<String>();
        generoList.add("M");
        generoList.add("F");
        ArrayAdapter<String> dataAdapterGenero = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, generoList);
        dataAdapterGenero.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        dropdownGenero.setAdapter(dataAdapterGenero);


        try {
            llenarSpinnerObraSocial();
        } catch (JSONException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }

    }

    private void llenarSpinnerObraSocial() throws JSONException, UnsupportedEncodingException {
        JSONObject obj = new JSONObject();
        obj.put("s", "s");

        RestClient.postJson(null, "/patient/obrasocial/all", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                String respuesta = response.toString();
                System.out.println("DEVOLVIO un array>>>>>>>>>>>>>>" + respuesta);
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<ObraSocial>>() {
                }.getType();
                Collection<ObraSocial> enums = gson.fromJson(respuesta, collectionType);
                ObraSocial[] map = enums.toArray(new ObraSocial[enums.size()]);

                ArrayList<ObraSocial> obras = new ArrayList<>();
                for (ObraSocial p : map) {
                    obras.add(p);
                }
                ArrayAdapter<ObraSocial> dataAdapterYers = new ArrayAdapter<ObraSocial>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, obras);
                dropdownObraSocial.setAdapter(dataAdapterYers);

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                String respuesta = response.toString();
                System.out.println("DEVOLVIO un array>>>>>>>>>>>>>>" + respuesta);
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<ObraSocial>>() {
                }.getType();
                Collection<ObraSocial> enums = gson.fromJson(respuesta, collectionType);
                ObraSocial[] map = enums.toArray(new ObraSocial[enums.size()]);

                ArrayList<ObraSocial> obras = new ArrayList<>();
                for (ObraSocial p : map) {
                    obras.add(p);
                }
                ArrayAdapter<ObraSocial> dataAdapterYers = new ArrayAdapter<ObraSocial>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item, obras);
                dataAdapterYers.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                dropdownObraSocial.setAdapter(dataAdapterYers);

            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);
                Toast.makeText(getApplicationContext(), "Ocurrio un error de conexion", Toast.LENGTH_LONG).show();
            }
        });

    }

    private void extraerDataUsuario() throws JSONException, UnsupportedEncodingException {
        Autorizacion auth = new Autorizacion();

        //Sacamos los datos del paciente
        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));


        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID());
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if(auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());


        System.out.println("Objeto autorizacion>>>>>>" + objAuth.toString());

        JSONObject obj = new JSONObject();
        obj.put("authorization", objAuth);
        obj.put("patientID", auth.getPatientID());
        //    obj.put("patientID", 1);

        System.out.println("Objeto enviado>>>>>>" + obj.toString());


        RestClient.postJson(null, "/patient/single", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                String respuesta = response.toString();
                Gson gson = new Gson();

                System.out.println("DEVOLVIO un Object>>>>>>>>>>>>>>" + respuesta);
                InfoPaciente datosPaciente = gson.fromJson(respuesta, InfoPaciente.class);

                tvNombre.setText(datosPaciente.getInformation().getNombre());
                tvApellido.setText(datosPaciente.getInformation().getApellido());
                tvCorreo.setText(datosPaciente.getInformation().getEmail());
                etFechaNacimiento.setText(datosPaciente.getInformation().getFechaNacimiento());
                etCelular.setText(datosPaciente.getInformation().getCelular());
                etDni.setText(datosPaciente.getInformation().getDni());
                etNoAfiliado.setText(datosPaciente.getInformation().getNumObraSocial().toString());

                locationID = datosPaciente.getInformation().getLocationID();
                provicinaID = datosPaciente.getInformation().getProvinceID();

                dropdownGenero.setSelection(Integer.valueOf(datosPaciente.getInformation().getSexo()) - 1);
                dropdownObraSocial.setSelection(datosPaciente.getInformation().getObraSocialInfo().getId() -1);
                progreso.dismiss();

            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);
                Toast.makeText(getApplicationContext(), "Ocurrio un error extrayendo los datos, Intentelo más tarde", Toast.LENGTH_LONG).show();
            }
        });


    }


    private void startActualizacion() {
        Form form = new Form(this);


        form.check(tvNombre, RegexTemplate.NOT_EMPTY_PATTERN, "El nombre no debe ser vacio");

        form.check(tvApellido, RegexTemplate.NOT_EMPTY_PATTERN, "El apellido no debe ser vacio");

        form.check(etFechaNacimiento, RegexTemplate.NOT_EMPTY_PATTERN, "Debe Ingresar fecha de nacimiento");

        form.check(tvCorreo, RegexTemplate.NOT_EMPTY_PATTERN, "El email no debe estar vacio");
        form.check(tvCorreo, RegexTemplate.EMAIL_PATTERN, "Formato incorrecto, ejemplo de formato: Hay.Turno123@gmail.com");

        form.check(etCelular, RegexTemplate.NOT_EMPTY_PATTERN, "El celular no debe ir vacio");

        form.check(etDni, RegexTemplate.NOT_EMPTY_PATTERN, "El dni no debe estar vacio");
        form.checkLength(etDni, Range.equalOrLess(10), "El dni debe ser de 10 digitos");

        form.check(etNoAfiliado, RegexTemplate.NOT_EMPTY_PATTERN, "El numero de afiliado no debe estar vacio");

        if (form.validate())
        {
            // validamos que haya una foto que subir
     //       if (camera.getCameraBitmap() != null)
     //           subirFoto();

            try {
                actualizarUsuario();
            }catch (JSONException | UnsupportedEncodingException e)
            {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Revise la informacion nuevamente", Toast.LENGTH_LONG).show();
        }


    }

    private void subirFoto()
    {
        Autorizacion auth = new Autorizacion();

        //Sacamos los datos del paciente
        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));

        Utils u  = new Utils();

        File fotoaComprimir = new File(camera.getCameraBitmapPath());
        File foto =  u.saveBitmapToFile(fotoaComprimir);


        //guardamos una copia a la memoria interna
        String fotoPath = u.saveToInternalStorage(camera.getCameraBitmap() ,getApplicationContext());
        //guardamos el path
        sesion.setDirectorioFotoUsuario(fotoPath);


        //mostrando progres dialog
        dlg.show();

        String pswdParameterJson = "";

        if(auth.getLoginPolicy().equals("FB"))
            pswdParameterJson = "facebooktoken";   //       objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            pswdParameterJson = "googletoken";     //  objAuth.put("googletoken", auth.getPsswd());
        else
            pswdParameterJson = "psswd";           //objAuth.put("psswd", auth.getPsswd());



        Ion.with(this)
                .load("POST", RestClient.getAbsoluteUrlserver("/patient/pic/add"))
                .progressDialog(dlg)
                .setTimeout(60 * 60 * 1000)
                .setMultipartParameter("patientID", auth.getPatientID().toString())
                .setMultipartParameter("loginPolicy", auth.getLoginPolicy())
                .setMultipartParameter("eml", auth.getEml())
                .setMultipartParameter(pswdParameterJson, auth.getPsswd())
                .setMultipartFile("pic", "image/png", foto)
                .asString()
                .withResponse()
                .setCallback(new FutureCallback<Response<String>>() {
                    @Override
                    public void onCompleted(Exception e, Response<String> result)
                    {
                        dlg.cancel();

                        if(e  != null)
                        {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                        else
                        {                            // print the response code, ie, 200
                            System.out.println(result.getHeaders().code());
                            // print the String that was downloaded
                            Toast.makeText(getApplicationContext(), result.getResult(), Toast.LENGTH_LONG).show();
                            System.out.println(result.getResult());
                        }

                    }
                });

      }

    /*
        actualizarUsuario ahora llama a subirFoto cada vez que se detecte que se ha tomado una foto
        solamente intenta subir la foto si se ha actulizado con exito los datos
    */
    private void actualizarUsuario() throws JSONException, UnsupportedEncodingException
    {
        Autorizacion auth = new Autorizacion();
        String nombre = tvNombre.getText().toString();
        String apellido = tvApellido.getText().toString();
        String email = tvCorreo.getText().toString();
        String genero = dropdownGenero.getSelectedItem().toString();
        Integer ssNumber = Integer.valueOf(etNoAfiliado.getText().toString());
        String DNI = etDni.getText().toString();
        String celular = etCelular.getText().toString();
        String fechaNacimiento = etFechaNacimiento.getText().toString();

        Integer generoID = 0;

        ObraSocial obraElegida = (ObraSocial) dropdownObraSocial.getSelectedItem();

        //Sacamos los datos del paciente
        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));


        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID());
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if(auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());


        if (genero.equals("M"))
            generoID = 1;
        else
            generoID = 2;

        //el json pide como campos obligatorios
        //patientID, firstName, lastName, dni, birthdate, gender, locationID, provinceID, telephone

        JSONObject obj = new JSONObject();
        obj.put("authorization", objAuth);
        obj.put("firstName", nombre);
        obj.put("lastName", apellido);
        obj.put("cellPhone", celular);
        obj.put("email", email);
        obj.put("dni", DNI);
        obj.put("birthDate", fechaNacimiento);
        obj.put("gender", generoID);
        obj.put("locationID", locationID);
        obj.put("provinceID", provicinaID);
        obj.put("telephone", celular);
        obj.put("patientID", auth.getPatientID());
    //  obj.put("socialSecurityType", ssType);
        obj.put("socialSecurityType", obraElegida.getId());
        obj.put("socialSecurityNumber", ssNumber);


        System.out.println("JSON ENVIADO de datos::::::::" + obj.toString());

        RestClient.postJson(null, "/patient/user/modify", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                System.out.println("Llamo al object::::::");

                String respuesta = response.toString();
                Gson gson = new Gson();

                JsResId jsSimple = gson.fromJson(respuesta, JsResId.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS() );
                System.out.println("Recibio estatus de: " + jsSimple.getMSG_());
                if (jsSimple.getSTATUS().equals("SUCCESS"))
                {
                    String nombre = tvNombre.getText().toString();
                    String apellido = tvApellido.getText().toString();
                    String email = tvCorreo.getText().toString();

                    sesion.setNombre(nombre +" "+apellido);
                    sesion.setEmail(email);

                    Toast.makeText(getApplicationContext(), "Datos Actualizados!", Toast.LENGTH_LONG).show();

                    if (camera.getCameraBitmap() != null)
                       subirFoto();

                } else {

                    Toast.makeText(getApplicationContext(), "No se logro actualizar los datos", Toast.LENGTH_LONG).show();
                }
            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                super.onFailure(statusCode, headers, responseString, throwable);
                String respString = responseString;
                Log.d("Error de ws::::: ", "" + throwable);
                Toast.makeText(getApplicationContext(), "Ocurrio un error de actualizacion, Intentelo más tarde", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject js) {
                super.onFailure(statusCode, headers, throwable, js);

                Log.d("Error de ws::::: ", "" + throwable);
                Toast.makeText(getApplicationContext(), "Ocurrio un error de actualizacion, Intentelo más tarde", Toast.LENGTH_LONG).show();
            }


        });



    } // fin de actulizar usuario


    private void signOut()
    {
        sesion.logoutUser();
    }

}
