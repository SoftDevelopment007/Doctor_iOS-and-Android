package com.hayturnoapp.models;

import java.util.ArrayList;

/**
 * Created by Nicolas on 02/11/2016.
 */

public class MisMedicosArrayList
{
    private ArrayList<MedicoFavoritoJson> listadoMedicos;

    public ArrayList<MedicoFavoritoJson> getListadoMedicos()
    {
        return listadoMedicos;
    }

    public void setListadoMedicos(ArrayList<MedicoFavoritoJson> listadoMedicos)
    {
        this.listadoMedicos = listadoMedicos;
    }
}
