package com.hayturnoapp.utils;

import android.app.Application;

// FUNCIONA PARA GUARDAR LOS DATOS QUE SELECCIONA EL USUARIO A TRAVZ DE LOS FILTROS
public class DatosGlobales extends Application {

    private Integer IdProvinciaSelecta;
    private Integer IdCiudadSelecta;
    private Integer IdEspecialidad;
    private Integer IdCentroMedico;
    private Integer IdDoctor;


    private String horario_Inicio;
    private String horario_Fin;
    private String fecha_turno;

    private String NombreProvincia;
    private String NombreCiudad;
    private String NombreEspecialidad;
    private String NombreCentroMedico;
    private String NombreDoctor;
    private String DireccionCentroMedico;
    private String TelefonoCentroMedico;

    private boolean revisarFiltro;
    private Integer filtroNuevo;


    private static DatosGlobales ourInstance = new DatosGlobales();

    public static DatosGlobales getInstance() {
        return ourInstance;
    }

    private DatosGlobales() {
        this.revisarFiltro = false;
        this.filtroNuevo = 0;
    }

    public Integer getIdProvinciaSelecta() {
        return IdProvinciaSelecta;
    }

    public void setIdProvinciaSelecta(Integer idProvinciaSelecta) {
        IdProvinciaSelecta = idProvinciaSelecta;
    }

    public Integer getIdCiudadSelecta() {
        return IdCiudadSelecta;
    }

    public void setIdCiudadSelecta(Integer idCiudadSelecta) {
        IdCiudadSelecta = idCiudadSelecta;
    }

    public Integer getIdEspecialidad() {
        return IdEspecialidad;
    }

    public void setIdEspecialidad(Integer idEspecialidad) {
        IdEspecialidad = idEspecialidad;
    }

    public Integer getIdCentroMedico() {
        return IdCentroMedico;
    }

    public void setIdCentroMedico(Integer idCentroMedico) {
        IdCentroMedico = idCentroMedico;
    }

    public Integer getIdDoctor() {
        return IdDoctor;
    }

    public void setIdDoctor(Integer idDoctor) {
        IdDoctor = idDoctor;
    }

    public String getNombreProvincia() {
        return NombreProvincia;
    }

    public void setNombreProvincia(String nombreProvincia) {
        NombreProvincia = nombreProvincia;
    }

    public String getNombreCiudad() {
        return NombreCiudad;
    }

    public void setNombreCiudad(String nombreCiudad) {
        NombreCiudad = nombreCiudad;
    }

    public String getNombreEspecialidad() {
        return NombreEspecialidad;
    }

    public void setNombreEspecialidad(String nombreEspecialidad) {
        NombreEspecialidad = nombreEspecialidad;
    }

    public String getNombreCentroMedico() {
        return NombreCentroMedico;
    }

    public void setNombreCentroMedico(String nombreCentroMedico) {
        NombreCentroMedico = nombreCentroMedico;
    }

    public String getNombreDoctor() {
        return NombreDoctor;
    }

    public void setNombreDoctor(String nombreDoctor) {
        NombreDoctor = nombreDoctor;
    }

    public String getHorario_Inicio() {
        return horario_Inicio;
    }

    public void setHorario_Inicio(String horario_Inicio) {
        this.horario_Inicio = horario_Inicio;
    }

    public String getHorario_Fin() {
        return horario_Fin;
    }

    public void setHorario_Fin(String horario_Fin) {
        this.horario_Fin = horario_Fin;
    }


    public String getFecha_turno() {
        return fecha_turno;
    }

    public void setFecha_turno(String fecha_turno) {
        this.fecha_turno = fecha_turno;
    }

    public String getDireccionCentroMedico() {
        return DireccionCentroMedico;
    }

    public void setDireccionCentroMedico(String direccionCentroMedico) {
        DireccionCentroMedico = direccionCentroMedico;
    }

    public String getTelefonoCentroMedico() {
        return TelefonoCentroMedico;
    }

    public void setTelefonoCentroMedico(String telefonoCentroMedico) {
        TelefonoCentroMedico = telefonoCentroMedico;
    }

    public boolean isRevisarFiltro() {
        return revisarFiltro;
    }

    public void setRevisarFiltro(boolean revisarFiltro) {
        this.revisarFiltro = revisarFiltro;
    }

    public Integer getFiltroNuevo() {
        return filtroNuevo;
    }

    public void setFiltroNuevo(Integer filtroNuevo) {
        this.filtroNuevo = filtroNuevo;
    }


    //procedimiento de limpieza de datos
    public void limpiarDatosFiltros()
    {
       switch (this.filtroNuevo)
       {
           case 1:
               this.IdProvinciaSelecta = 0;
               this.IdCiudadSelecta= 0;
               this.IdEspecialidad= 0;
               this.IdCentroMedico= 0;
               this.IdDoctor= 0;
           break;
           case 2:
               this.IdCiudadSelecta= 0;
               this.IdEspecialidad= 0;
               this.IdCentroMedico= 0;
               this.IdDoctor= 0;
           break;
           case 3:
               this.IdEspecialidad= 0;
               this.IdCentroMedico= 0;
               this.IdDoctor= 0;
           break;
           case 4:
               this.IdCentroMedico= 0;
               this.IdDoctor= 0;
           break;
           case 5:
                this.IdDoctor= 0;
           break;
           default:
               break;
       }
    } // fin de limpiar datos de filtros
}
