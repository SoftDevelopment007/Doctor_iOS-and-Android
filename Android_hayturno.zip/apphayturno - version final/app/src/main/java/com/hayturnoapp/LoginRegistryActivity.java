package com.hayturnoapp;

import android.app.Activity;
import android.content.Intent;

import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.facebook.FacebookSdk;

import android.widget.Toast;


import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;

import com.hayturnoapp.utils.DatosUsuarios;
import com.hayturnoapp.utils.ExceptionHandler;


import org.json.JSONObject;


import java.util.HashMap;


public class LoginRegistryActivity extends AppCompatActivity {

    private LoginButton loginButtonFb;
    private CallbackManager callbackManager;

    private HashMap<String, String> valoresFB;


    private GoogleApiClient mGoogleApiClient;
    private static final int RC_SIGN_IN = 9001;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // manejador de error
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
       // FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.activity_login_registry);

        valoresFB = new HashMap<String, String>();


        /*********************************** SECCION DE FB *************************************************/
        /***************************************************************************************************/
        loginButtonFb = (LoginButton) findViewById(R.id.login_button_Fb);

        /************************************SECCION DE G+*************************************************/
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestIdToken(getString(R.string.default_web_client_id))
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        SignInButton Glogin = (SignInButton) findViewById(R.id.login_button_G);
        Glogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
                startActivityForResult(signInIntent, RC_SIGN_IN);
            }
        });


        /*************************************** FIN DE LA SECCION DE G+ ***********************************/
        limpiardata();

    } // FIN DE ON CREATE


    @Override
    protected void onResume() {

        super.onResume();
        callbackManager=CallbackManager.Factory.create();

        loginButtonFb= (LoginButton)findViewById(R.id.login_button_Fb);

        loginButtonFb.setReadPermissions("public_profile", "email","user_friends");
        loginButtonFb.registerCallback(callbackManager, mCallBack);



    }

    @Override
    protected void onPause() {

        super.onPause();
    }

    protected void onStop() {
        super.onStop();

    }


    @Override
    protected void onActivityResult(int requestCode, int responseCode, Intent intent) {
        super.onActivityResult(requestCode, responseCode, intent);

        if (requestCode == RC_SIGN_IN )
        {  //parte de G+
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(intent);

            if (result.isSuccess())
            {
                // Signed in successfully, show authenticated UI.
                GoogleSignInAccount acct = result.getSignInAccount();
                //    acct.getIdToken(); // el oken que se debe de pasar
                DatosUsuarios duvar = DatosUsuarios.getInstance();
                duvar.setIdTokenGmail( acct.getIdToken());
                duvar.setRegistroporGmail(true);
                duvar.setRegistroporFB(false);
                duvar.setRegistroporApp(false);
                duvar.setNombres( acct.getGivenName());
                duvar.setApellidos(acct.getFamilyName());
                duvar.setEmail(acct.getEmail());
                Intent intentaDatos =new Intent(LoginRegistryActivity.this,DatosPersonalesActivity.class);
                startActivity(intentaDatos );

            } else {
                // Signed out,
                Toast.makeText(this, "Error de autenticacion, intente mas tarde", Toast.LENGTH_LONG).show();
            }
        }// PARTE DE FB
        else  {

            if (responseCode == Activity.RESULT_OK) {
                callbackManager.onActivityResult(requestCode, responseCode, intent);
               // Toast.makeText(this, "Access Token: " + accessToken, Toast.LENGTH_LONG).show();
            } else {

                Toast.makeText(this, "Error: en onActivityResult", Toast.LENGTH_LONG).show();
            }

        }
    }


    public void startAccount(View v) {

        DatosUsuarios duvar = DatosUsuarios.getInstance();

        duvar.setRegistroporApp(true);

        Intent intent = new Intent(this, FormRegistroActivity.class);
        startActivity(intent);


    }


    private FacebookCallback<LoginResult> mCallBack = new FacebookCallback<LoginResult>() {
        @Override
        public void onSuccess(final LoginResult loginResult) {

              // App code
            GraphRequest request = GraphRequest.newMeRequest( loginResult.getAccessToken(),   new GraphRequest.GraphJSONObjectCallback() {
                        @Override
                        public void onCompleted( JSONObject object, GraphResponse response)
                        {
                            String facebookID =  "";
                            String email=  "";
                            String name =  "";
                            String gender =  "";
                            String firstname = "";
                            String lastname = "";
                            Log.e("responseFB: ", response + "");
                            try {

                                facebookID = object.getString("id").toString();
                                email = object.getString("email").toString();
                                gender = object.getString("gender").toString();
                                firstname = object.getString("first_name").toString();
                                lastname = object.getString("last_name").toString();


                            }catch (Exception e){
                                e.printStackTrace();
                            }
                            DatosUsuarios duvar = DatosUsuarios.getInstance();
                            duvar.setAccessTokenFB(loginResult.getAccessToken());

                            duvar.setRegistroporFB(true);
                            duvar.setRegistroporGmail(false);
                            duvar.setRegistroporApp(false);

                            duvar.setNombres(firstname);
                            duvar.setApellidos(lastname);
                            duvar.setEmail(email);
                            duvar.setGenero(gender);
                            Intent intent=new Intent(LoginRegistryActivity.this,DatosPersonalesActivity.class);
                            startActivity(intent);
                            finish();

                        }

                    });

            Bundle parameters = new Bundle();
            parameters.putString("fields", "id,name,first_name,last_name,email,gender");
            request.setParameters(parameters);
            request.executeAsync();
        }

        @Override
        public void onCancel() {
       //     progressDialog.dismiss();
            Toast.makeText(LoginRegistryActivity.this, "cancelado el callback", Toast.LENGTH_LONG).show();
        }

        @Override
        public void onError(FacebookException e) {
         //   progressDialog.dismiss();

            Toast.makeText(LoginRegistryActivity.this, "Error en el callback", Toast.LENGTH_LONG).show();
        }
    };


    // por si alguna razon el cliente desea regresar a esta pantalla, limpiamos la data.
    public void limpiardata()
    {
        DatosUsuarios duvar = DatosUsuarios.getInstance();
        duvar.setAccessTokenFB(null);

        duvar.setRegistroporFB(false);
        duvar.setRegistroporGmail(false);
        duvar.setRegistroporApp(false);

        duvar.setNombres("");
        duvar.setApellidos("");
        duvar.setEmail("");
        duvar.setGenero("");
        duvar.setContraseña("");

      //  Toast.makeText(this, "se limpio la data", Toast.LENGTH_LONG).show();
    }



}
