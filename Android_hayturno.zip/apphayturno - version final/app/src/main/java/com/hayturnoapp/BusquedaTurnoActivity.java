package com.hayturnoapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hayturnoapp.adapters.BusquedaTurnoPagerAdapter;
import com.hayturnoapp.adapters.RecyclerViewAdapter2;
import com.hayturnoapp.models.CentroMedico;
import com.hayturnoapp.models.Ciudad;
import com.hayturnoapp.models.Doctor;
import com.hayturnoapp.models.Especialidad;
import com.hayturnoapp.models.Provincia;
import com.hayturnoapp.models.ValorFiltros;
import com.hayturnoapp.utils.DatosGlobales;
import com.hayturnoapp.utils.ExceptionHandler;
import com.hayturnoapp.utils.RestClient;
import com.hayturnoapp.utils.Session;
import com.hayturnoapp.utils.Utils;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.conn.ConnectTimeoutException;

public class BusquedaTurnoActivity extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;

    //elementos del Drawer
    private Drawer resultDrawer;
    private AccountHeader headerResult;

    private String[] activityTitles;
    private Session sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // manejador de error
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setContentView(R.layout.activity_busqueda_turno);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);


        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        DatosGlobales var = DatosGlobales.getInstance();
        sesion = new Session(this);

        activityTitles = getResources().getStringArray(R.array.nav_item_activity_titles);

        final BusquedaTurnoPagerAdapter adapter = new BusquedaTurnoPagerAdapter(getSupportFragmentManager());
        final ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        viewPager.setAdapter(adapter);


        TabLayout tabLayout = (TabLayout) findViewById(R.id.tablayout);
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }

        });


        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {


            @Override
            public void onPageSelected(int position) {
                TextView btn = (TextView) findViewById(R.id.textViewComenzar);


                adapter.notifyDataSetChanged();
                Fragment f1 = adapter.getItem(position);
                f1.onResume();

                if (position == 0) {
                    btn.setText(R.string.pager_1_provincia);
                }
                if (position == 1) {
                    btn.setText(R.string.pager_2_ciudad);

                }
                if (position == 2) {
                    btn.setText(R.string.pager_3_especialidad);

                }
                if (position == 3) {
                    btn.setText(R.string.pager_4_centro_medico);


                }
                if (position == 4) {
                    btn.setText(R.string.pager_5_especialista);

                }

            }

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


        // revisamos si viene el activity de BusquedaTurnoFinal, es para setear los nuevo valores
        if (var.isRevisarFiltro()) {
            viewPager.setCurrentItem(var.getFiltroNuevo() - 1);
            var.limpiarDatosFiltros();
            var.setRevisarFiltro(false);
            var.setFiltroNuevo(0);
        }


        //seteamos el navigator drawer
        if (sesion.isLoggedIn()) {
            toolbar.setNavigationIcon(R.drawable.ic_menu);
            HashMap<String, String> user = sesion.getDetalleUsuario();

            String directorioFotoUsuario = "";
            Utils u = new Utils();
            final ProfileDrawerItem datoUsuario = new ProfileDrawerItem();
            datoUsuario.withName(user.get(sesion.KEY_NAME));

            directorioFotoUsuario =  sesion.getDirectorioFotoUsuario();

            if( directorioFotoUsuario == null)
                directorioFotoUsuario = "";

            if( !directorioFotoUsuario.isEmpty() )
                datoUsuario.withIcon(u.loadImageFromStorage(directorioFotoUsuario));
            else
                datoUsuario.withIcon(getResources().getDrawable(R.drawable.foto_persona));

            headerResult = new AccountHeaderBuilder()
                    .withActivity(this)
                    .withHeaderBackground(R.color.colorBackBlueLight)
                    .addProfiles(datoUsuario)
                    .withSelectionListEnabledForSingleProfile(false)
                    .build();


            //agregamos el menu de navegacion
            resultDrawer = new DrawerBuilder()
                    .withActivity(this)
                    .withToolbar(toolbar)
                    .withAccountHeader(headerResult)
                    .addDrawerItems(
                            new PrimaryDrawerItem().withName( activityTitles[0]).withIcon(R.drawable.icon_search).withIdentifier(1),
                            new PrimaryDrawerItem().withName( activityTitles[1]).withIcon(R.drawable.icon_agenda).withIdentifier(2),
                            new PrimaryDrawerItem().withName( activityTitles[2]).withIcon(R.drawable.icon_mis_medicos).withIdentifier(3),
                            new PrimaryDrawerItem().withName( activityTitles[3]).withIcon(R.drawable.icon_datos_personales).withIdentifier(4),
                            new PrimaryDrawerItem().withName( activityTitles[4]).withIcon(R.drawable.icon_close_session).withIdentifier(5)
                    ).withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
                        @Override
                        public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                            //revisamos si drawerItem esta seteado
                            //drawerItem puede ser nulo por diferentes razones
                            //--> click en encaebzado
                            //--> click en el pie
                            // esos items no contiene drawerItem
                            if (drawerItem != null) {
                                Intent intent = null;
                                int identificador = (int) drawerItem.getIdentifier();
                                switch (identificador) {
                                    case 1:
                                        intent = new Intent(BusquedaTurnoActivity.this, BusquedaTurnoActivity.class);
                                        break;
                                    case 2:
                                        intent = new Intent(BusquedaTurnoActivity.this, CalendariosTurnoActivity.class);
                                        break;
                                    case 3:
                                        intent = new Intent(BusquedaTurnoActivity.this, MisMedicosActivity.class);
                                        break;
                                    case 4:
                                        intent = new Intent(BusquedaTurnoActivity.this, DatosPersonalesModificacionActivity.class);
                                        break;
                                    case 5:
                                        signOut();
                                        break;

                                }

                                if (intent != null) {
                                    BusquedaTurnoActivity.this.startActivity(intent);
                                }
                            }
                            return false;
                        }
                    })
                    .build();
        }

    }


    private void signOut()
    {
        sesion.logoutUser();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
            case R.id.action_settings:
                return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public static class BusquedaTurnoFragment extends Fragment {
        private static final String TAB_POSITION = "tab_position";
        private View vc;

        public BusquedaTurnoFragment() {

        }

        public static BusquedaTurnoFragment newInstance(int tabPosition) {
            BusquedaTurnoFragment fragment = new BusquedaTurnoFragment();
            Bundle args = new Bundle();
            args.putInt(TAB_POSITION, tabPosition);
            fragment.setArguments(args);
            fragment.onResume();
            return fragment;
        }


        @Nullable
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            DatosGlobales var = DatosGlobales.getInstance();
            //  ArrayList<String> items = new ArrayList<String>();
            Bundle args = getArguments();
            int tabPosition = args.getInt(TAB_POSITION);

            View v = inflater.inflate(R.layout.fragment_list_view, container, false);

            ProgressDialog progreso = new ProgressDialog(getActivity(), R.style.ThemePD);
            progreso.setMessage("");
            progreso.setIndeterminate(false);
            progreso.setCancelable(false);
            progreso.setProgressStyle(android.R.style.Widget_ProgressBar_Small);


            if (tabPosition == 0)//provincias
            {

                try {
                    obtenerProvincias(v, getActivity(), progreso);
                } catch (JSONException | UnsupportedEncodingException e) {
                    e.printStackTrace();
                }// items.clear();


            }//------------------------------------ FIN DE PROVINCIAS -----------------------
            if (tabPosition == 1) //--------------- CIUDADES
            {

                int valorProvincia;
                //localidades
                if (var.getIdProvinciaSelecta() == null)
                    valorProvincia = 0;
                else
                    valorProvincia = var.getIdProvinciaSelecta();


                try {
                    // obtenerCiudades( v, getActivity(),24 );
                    obtenerCiudades(v, getActivity(), valorProvincia);
                } catch (JSONException | UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

            }
            if (tabPosition == 2) {
                //especialidad

                int valorCiudad;
                //localidades
                if (var.getIdCiudadSelecta() == null)
                    valorCiudad = 0;
                else
                    valorCiudad = var.getIdCiudadSelecta();


                try {
                    //obtenerEspecialidades( v, getActivity(),27909);
                    obtenerEspecialidades(v, getActivity(), valorCiudad, progreso);
                } catch (JSONException | UnsupportedEncodingException e) {
                    e.printStackTrace();
                }// items.clear();

            }
            if (tabPosition == 3) {
                //centro medico

                int valorEspecialidad = 0;
                int valorCiudad = 0;

                if (var.getIdCiudadSelecta() == null)
                    valorCiudad = 0;
                else
                    valorCiudad = var.getIdCiudadSelecta();

                if (var.getIdEspecialidad() == null)
                    valorEspecialidad = 0;
                else
                    valorEspecialidad = var.getIdEspecialidad();

                try {
                    // obtenerCentrosMedico( v, getActivity(),27909,1);
                    obtenerCentrosMedico(v, getActivity(), valorCiudad, valorEspecialidad, progreso);
                } catch (JSONException | UnsupportedEncodingException e) {
                    e.printStackTrace();
                }// items.clear();
            }
            if (tabPosition == 4) {
                //especialista

                Integer valorEspecilidad = 0;
                Integer valorHospital = 0;

                if (var.getIdCiudadSelecta() == null)
                    valorEspecilidad = 0;
                else
                    valorEspecilidad = var.getIdEspecialidad();

                if (var.getIdEspecialidad() == null)
                    valorHospital = 0;
                else
                    valorHospital = var.getIdCentroMedico();

                try {
                    //     obtenerDoctores( v, getActivity(),1,1);
                    obtenerDoctores(v, getActivity(), valorEspecilidad, valorHospital);
                } catch (JSONException | UnsupportedEncodingException e) {
                    e.printStackTrace();
                }// items.clear();

            }
/*
            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
            recyclerView.setAdapter(new RecyclerViewAdapter(items));
*/
            return v;
        }
    }


//----TODO: REORGANIZAR ESTE MONTON DE CODIGO REPETIDO  ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
    //  vpFiltros.setCurrentItem(1,true);

    // llamando al webservice
    static public void obtenerProvincias(final View v, final Activity Act, final ProgressDialog pd) throws JSONException, UnsupportedEncodingException {
        JSONObject obj = new JSONObject();
        obj.put("s", "s");

        //   System.out.println(">>>>>>>>>"+obj);
        pd.show();
        RestClient.postJson(null, "/location/provinces/all", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected JSONArray

                //final ViewPager vpFiltros = (ViewPager) v.findViewById(R.id.viewpager);
                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<Provincia>>() {
                }.getType();
                Collection<Provincia> enums = gson.fromJson(respuesta, collectionType);

                Provincia[] map = enums.toArray(new Provincia[enums.size()]);
                System.out.println("DEVOLVIO un Object>>>>>>>>>>>>>>" + respuesta);
                System.out.println("ENUMS>>>>>>>>" + enums.isEmpty());

                //    List<String> prov = new ArrayList<String>();
                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();

                for (Provincia p : map) {
                    ValorFiltros dato = new ValorFiltros(p.getId(), p.getNombre());
                    prov.add(dato);
                }

                RecyclerView RV = (RecyclerView) v.findViewById(R.id.recyclerview);
                RV.setLayoutManager(new LinearLayoutManager(Act));


                RecyclerViewAdapter2 adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                    @Override
                    public void onItemClick(ValorFiltros item) {
                        //        Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                        ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                        DatosGlobales var = DatosGlobales.getInstance();

                        var.setIdProvinciaSelecta(item.getLlave());
                        var.setNombreProvincia(item.getValor());
                        System.out.println("Objeto global>>>>>>>>>>>" + var.getIdProvinciaSelecta().toString());
                        vpFiltros.setCurrentItem(1, true);
                    }
                });

                RV.setAdapter(adapter);
                RV.addItemDecoration(new HorizontalDividerItemDecoration.Builder(Act.getBaseContext().getApplicationContext()).color(Color.BLACK).build());

                pd.dismiss();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                // Extraemos las provincias que devuelva el WS

                String respuesta = response.toString();
                //   final ViewPager vpFiltros = (ViewPager) v.findViewById(R.id.viewpager);

                System.out.println("DEVOLVIO un array>>>>>>>>>>>>>>" + respuesta);


                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<Provincia>>() {
                }.getType();
                Collection<Provincia> enums = gson.fromJson(respuesta, collectionType);

                Provincia[] map = enums.toArray(new Provincia[enums.size()]);
                System.out.println("ENUMS>>>>>>>>" + enums.isEmpty());

                //    List<String> prov = new ArrayList<String>();
                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();

                for (Provincia p : map) {
                    ValorFiltros dato = new ValorFiltros(p.getId(), p.getNombre());
                    prov.add(dato);
                    //          prov.add(p.getNombre());
                }


                RecyclerView RV = (RecyclerView) v.findViewById(R.id.recyclerview);
                RV.setLayoutManager(new LinearLayoutManager(Act));

                RecyclerViewAdapter2 adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                    @Override
                    public void onItemClick(ValorFiltros item) {
                        //                      Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                        ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                        DatosGlobales var = DatosGlobales.getInstance();

                        var.setIdProvinciaSelecta(item.getLlave());
                        var.setNombreProvincia(item.getValor());
                        System.out.println("Objeto global>>>>>>>>>>>" + var.getIdProvinciaSelecta().toString());
                        vpFiltros.setCurrentItem(1, true);
                    }
                });
                RV.setAdapter(adapter);
                RV.addItemDecoration(new HorizontalDividerItemDecoration.Builder(Act.getBaseContext().getApplicationContext()).color(Color.BLACK).build());

                //      RV.setAdapter(new RecyclerViewAdapter(prov));

                pd.dismiss();
            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);
                pd.dismiss();
                Toast.makeText(Act.getBaseContext().getApplicationContext(), "Ocurrio un error de conexion", Toast.LENGTH_LONG).show();
            }


        });


    }
    //---------------------------- FIN DE PROVINCIAS ----------------------------------------------

    //--------------------- CIUDADES
    static public void obtenerCiudades(final View v, final Activity Act, int id_provincia) throws JSONException, UnsupportedEncodingException {
        JSONObject obj = new JSONObject();
        obj.put("provinceID", id_provincia);


        RestClient.postJson(null, "/location/locationsperprovince", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected JSONArray
                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<Ciudad>>() {
                }.getType();
                Collection<Ciudad> enums = gson.fromJson(respuesta, collectionType);
                Ciudad[] map = enums.toArray(new Ciudad[enums.size()]);

                System.out.println("DEVOLVIO un Object ciudades>>>>>>>>>>>>>>" + respuesta);
                System.out.println("ENUMS>>>>>>>>" + enums.isEmpty());

                // List<String> prov = new ArrayList<String>();
                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();

                for (Ciudad p : map) {
                    ValorFiltros dato = new ValorFiltros(p.getId(), p.getNombre());
                    prov.add(dato);
                }

                RecyclerView RV = (RecyclerView) v.findViewById(R.id.recyclerview);

                RV.setLayoutManager(new LinearLayoutManager(Act));

                RecyclerViewAdapter2 adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                    @Override
                    public void onItemClick(ValorFiltros item) {
                        //  Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                        ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                        DatosGlobales var = DatosGlobales.getInstance();
                        var.setIdCiudadSelecta(item.getLlave());
                        var.setNombreCiudad(item.getValor());
                        vpFiltros.setCurrentItem(2, true);
                    }
                });

                RV.setAdapter(adapter);
                RV.addItemDecoration(new HorizontalDividerItemDecoration.Builder(Act.getBaseContext().getApplicationContext()).color(Color.BLACK).build());

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                // Extraemos las provincias que devuelva el WS

                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<Ciudad>>() {
                }.getType();
                Collection<Ciudad> enums = gson.fromJson(respuesta, collectionType);
                Ciudad[] map = enums.toArray(new Ciudad[enums.size()]);

                System.out.println("DEVOLVIO un Object ciudades>>>>>>>>>>>>>>" + respuesta);
                System.out.println("ENUMS>>>>>>>>" + enums.isEmpty());

                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();

                for (Ciudad p : map) {
                    ValorFiltros dato = new ValorFiltros(p.getId(), p.getNombre());
                    prov.add(dato);
                }

                RecyclerView RV = (RecyclerView) v.findViewById(R.id.recyclerview);

                RV.setLayoutManager(new LinearLayoutManager(Act));

                RecyclerViewAdapter2 adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                    @Override
                    public void onItemClick(ValorFiltros item) {
                        //Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                        ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                        DatosGlobales var = DatosGlobales.getInstance();
                        var.setIdCiudadSelecta(item.getLlave());
                        var.setNombreCiudad(item.getValor());
                        vpFiltros.setCurrentItem(2, true);
                    }
                });
                RV.setAdapter(adapter);
                RV.addItemDecoration(new HorizontalDividerItemDecoration.Builder(Act.getBaseContext().getApplicationContext()).color(Color.BLACK).build());


            }

            //hacer acciones dependiendo del tipo de status
            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                super.onFailure(statusCode, headers, responseString, throwable);
                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);

                if( throwable.getCause() instanceof ConnectTimeoutException)
                    Toast.makeText(Act.getBaseContext().getApplicationContext(), "Ocurrio un error de conexion, Intentelo mas tarde", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(Act.getBaseContext().getApplicationContext(), "Ocurrio un error, Intentelo mas tarde", Toast.LENGTH_LONG).show();

            }
        });

    }  //---------------------------- FIN DE CIUDADES ----------------------------------------------


    static public void obtenerEspecialidades(final View v, final Activity Act, int id_ciudad, final ProgressDialog pd) throws JSONException, UnsupportedEncodingException {
        JSONObject obj = new JSONObject();
        obj.put("locationID", id_ciudad);

        pd.show();
        RestClient.postJson(null, "/location/specialtiesperlocation", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected JSONArray
                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<Especialidad>>() {
                }.getType();
                Collection<Especialidad> enums = gson.fromJson(respuesta, collectionType);

                Especialidad[] map = enums.toArray(new Especialidad[enums.size()]);
                System.out.println("DEVOLVIO un Object>>>>>>>>>>>>>>" + respuesta);
                System.out.println("ENUMS>>>>>>>>" + enums.isEmpty());

                //   List<String> prov = new ArrayList<String>();
                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();

                if (map.length == 0) {
                    String name = Act.getResources().getString(R.string.label_mensaje_not_found);
                    ValorFiltros dato = new ValorFiltros(0, name);
                    prov.add(dato);
                } else {
                    for (Especialidad p : map) {

                        ValorFiltros dato = new ValorFiltros(p.getId(), p.getNombre());
                        prov.add(dato);
                    }
                }

                RecyclerView RV = (RecyclerView) v.findViewById(R.id.recyclerview);

                RV.setLayoutManager(new LinearLayoutManager(Act));
                RecyclerViewAdapter2 adapter;
                if (map.length == 0) {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //     Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                            vpFiltros.setCurrentItem(1, true);
                        }
                    });

                } else {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //     Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                            DatosGlobales var = DatosGlobales.getInstance();
                            var.setIdEspecialidad(item.getLlave());
                            var.setNombreEspecialidad(item.getValor());
                            vpFiltros.setCurrentItem(3, true);
                        }
                    });

                }


                RV.setAdapter(adapter);
                RV.addItemDecoration(new HorizontalDividerItemDecoration.Builder(Act.getBaseContext().getApplicationContext()).color(Color.BLACK).build());
                pd.dismiss();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                // Extraemos las provincias que devuelva el WS

                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<Especialidad>>() {
                }.getType();
                Collection<Especialidad> enums = gson.fromJson(respuesta, collectionType);

                Especialidad[] map = enums.toArray(new Especialidad[enums.size()]);
                System.out.println("DEVOLVIO un Object>>>>>>>>>>>>>>" + respuesta);
                System.out.println("ENUMS>>>>>>>>" + enums.isEmpty());

                //   List<String> prov = new ArrayList<String>();
                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();

                if (map.length == 0) {
                    String name = Act.getResources().getString(R.string.label_mensaje_not_found);
                    ValorFiltros dato = new ValorFiltros(0, name);
                    prov.add(dato);
                } else {
                    for (Especialidad p : map) {
                        ValorFiltros dato = new ValorFiltros(p.getId(), p.getNombre());
                        prov.add(dato);
                    }
                }

                RecyclerView RV = (RecyclerView) v.findViewById(R.id.recyclerview);

                RV.setLayoutManager(new LinearLayoutManager(Act));

                RecyclerViewAdapter2 adapter;
                if (map.length == 0) {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //     Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                            vpFiltros.setCurrentItem(1, true);
                        }
                    });

                } else {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //     Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                            DatosGlobales var = DatosGlobales.getInstance();
                            var.setIdEspecialidad(item.getLlave());
                            var.setNombreEspecialidad(item.getValor());
                            vpFiltros.setCurrentItem(3, true);
                        }
                    });

                }


                RV.setAdapter(adapter);
                RV.addItemDecoration(new HorizontalDividerItemDecoration.Builder(Act.getBaseContext().getApplicationContext()).color(Color.BLACK).build());

                pd.dismiss();
            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                super.onFailure(statusCode, headers, responseString, throwable);
                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);
                pd.dismiss();

                if( throwable.getCause() instanceof ConnectTimeoutException)
                    Toast.makeText(Act.getBaseContext().getApplicationContext(), "Ocurrio un error de conexion, Intentelo mas tarde", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(Act.getBaseContext().getApplicationContext(), "Ocurrio un error, Intentelo mas tarde", Toast.LENGTH_LONG).show();

            }
        });


    }

    //---------------------------- FIN DE Especialidades ----------------------------------------------

    static public void obtenerCentrosMedico(final View v, final Activity Act, int id_ciudad, int id_especilidad, final ProgressDialog pd) throws JSONException, UnsupportedEncodingException {
        JSONObject obj = new JSONObject();
        obj.put("specialtyID", id_especilidad);
        obj.put("locationID", id_ciudad);

        pd.show();

        RestClient.postJson(null, "/location/hospitalsperspeciality", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected JSONArray
                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<CentroMedico>>() {
                }.getType();
                Collection<CentroMedico> enums = gson.fromJson(respuesta, collectionType);

                CentroMedico[] map = enums.toArray(new CentroMedico[enums.size()]);
                System.out.println("DEVOLVIO un Object>>>>>>>>>>>>>>" + respuesta);
                System.out.println("ENUMS>>>>>>>>" + enums.isEmpty());

                //   List<String> prov = new ArrayList<String>();
                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();

                int i = 0;

                if (map.length == 0) {
                    String name = Act.getResources().getString(R.string.label_mensaje_not_found);
                    ValorFiltros dato = new ValorFiltros(0, name);
                    prov.add(dato);
                } else {
                    for (CentroMedico p : map) {
                        ValorFiltros dato = new ValorFiltros(p.getId(), p.getNombre());
                        dato.setValordir1(p.getDireccion());
                        dato.setValordir2(p.getTelefono());
                        prov.add(dato);
                        String revdata = p.getId().toString() + " " + p.getNombre().toString() + " " + p.getDireccion() + " " + p.getTelefono();
                        System.out.println("objeto>>>>>>>>>>>>>>" + String.valueOf(i) + " " + revdata);
                        i++;
                    }
                }

                RecyclerView RV = (RecyclerView) v.findViewById(R.id.recyclerview);

                RV.setLayoutManager(new LinearLayoutManager(Act));

                RecyclerViewAdapter2 adapter;
                if (map.length == 0) {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //     Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                            vpFiltros.setCurrentItem(2, true);
                        }
                    });

                } else {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //     Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                            DatosGlobales var = DatosGlobales.getInstance();
                            var.setIdCentroMedico(item.getLlave());
                            var.setNombreCentroMedico(item.getValor());
                            var.setDireccionCentroMedico(item.getValordir1());
                            var.setTelefonoCentroMedico(item.getValordir2());
                            vpFiltros.setCurrentItem(4, true);
                        }
                    });
                }

                RV.setAdapter(adapter);
                RV.addItemDecoration(new HorizontalDividerItemDecoration.Builder(Act.getBaseContext().getApplicationContext()).color(Color.BLACK).build());
                pd.dismiss();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                // Extraemos las provincias que devuelva el WS

                String respuesta = response.toString();
                System.out.println("DEVOLVIO un array>>>>>>>>>>>>>>" + respuesta);


                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<CentroMedico>>() {
                }.getType();
                Collection<CentroMedico> enums = gson.fromJson(respuesta, collectionType);

                CentroMedico[] map = enums.toArray(new CentroMedico[enums.size()]);
                System.out.println("ENUMS>>>>>>>>" + enums.isEmpty());

                //   List<String> prov = new ArrayList<String>();
                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();

                int i = 0;


                if (map.length == 0) {
                    String name = Act.getResources().getString(R.string.label_mensaje_not_found);
                    ValorFiltros dato = new ValorFiltros(0, name);
                    prov.add(dato);
                } else {
                    for (CentroMedico p : map) {
                        ValorFiltros dato = new ValorFiltros(p.getId(), p.getNombre());
                        dato.setValordir1(p.getDireccion());
                        dato.setValordir2(p.getTelefono());
                        prov.add(dato);
                        String revdata = p.getId().toString() + " " + p.getNombre().toString() + " " + p.getDireccion() + " " + p.getTelefono();
                        System.out.println("objetoCentroMedico>>>>>>>>>>>>>>" + String.valueOf(i) + " " + revdata);
                        i++;
                    }
                }


                RecyclerView RV = (RecyclerView) v.findViewById(R.id.recyclerview);
                RV.setLayoutManager(new LinearLayoutManager(Act));

                RecyclerViewAdapter2 adapter;
                if (map.length == 0) {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //     Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                            vpFiltros.setCurrentItem(2, true);
                        }
                    });

                } else {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //     Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                            DatosGlobales var = DatosGlobales.getInstance();
                            var.setIdCentroMedico(item.getLlave());
                            var.setNombreCentroMedico(item.getValor());
                            var.setDireccionCentroMedico(item.getValordir1());
                            var.setTelefonoCentroMedico(item.getValordir2());
                            vpFiltros.setCurrentItem(4, true);
                        }
                    });
                }


                RV.setAdapter(adapter);
                RV.addItemDecoration(new HorizontalDividerItemDecoration.Builder(Act.getBaseContext().getApplicationContext()).color(Color.BLACK).build());
                pd.dismiss();
            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                super.onFailure(statusCode, headers, responseString, throwable);
                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);
                pd.dismiss();

                if( throwable.getCause() instanceof ConnectTimeoutException)
                   Toast.makeText(Act.getBaseContext().getApplicationContext(), "Ocurrio un error de conexion, Intentelo mas tarde", Toast.LENGTH_LONG).show();
                else
                   Toast.makeText(Act.getBaseContext().getApplicationContext(), "Ocurrio un error, Intentelo mas tarde", Toast.LENGTH_LONG).show();

            }

        });


    }
    //---------------------------- FIN DE CentroMedico ----------------------------------------------

    static public void obtenerDoctores(final View v, final Activity Act, Integer id_especialidad, Integer id_hospital) throws JSONException, UnsupportedEncodingException {
        JSONObject obj = new JSONObject();
        obj.put("specialtyID", id_especialidad);
        obj.put("hospitalID", id_hospital);

        RestClient.postJson(null, "/doctor/byinstitutionandspecialty", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected JSONArray
                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<Doctor>>() {
                }.getType();
                Collection<Doctor> enums = gson.fromJson(respuesta, collectionType);

                Doctor[] map = enums.toArray(new Doctor[enums.size()]);
                System.out.println("DEVOLVIO un Object>>>>>>>>>>>>>>" + respuesta);
                System.out.println("ENUMS>>>>>>>>" + enums.isEmpty());

                //   List<String> prov = new ArrayList<String>();
                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();

                if (map.length == 0) {
                    String name = Act.getResources().getString(R.string.label_mensaje_not_found);
                    ValorFiltros dato = new ValorFiltros(0, name);
                    prov.add(dato);
                } else {
                    for (Doctor p : map) {
                        ValorFiltros dato = new ValorFiltros(p.getInformation().getDoctorID(), p.getInformation().getNombre() + " " + p.getInformation().getApellido());
                        System.out.println("id: " + dato.getLlave() + ", nombre: " + dato.getValor());
                        prov.add(dato);
                    }

                }


                RecyclerView RV = (RecyclerView) v.findViewById(R.id.recyclerview);

                RV.setLayoutManager(new LinearLayoutManager(Act));

                RecyclerViewAdapter2 adapter;
                if (map.length == 0) {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //     Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                            vpFiltros.setCurrentItem(3, true);
                        }
                    });

                } else {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //  Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            DatosGlobales var = DatosGlobales.getInstance();
                            var.setIdDoctor(item.getLlave());
                            var.setNombreDoctor(item.getValor());

                            Intent intentConfirmacion = new Intent(Act, BusquedaTurnoFinalActivity.class);
                            Act.startActivity(intentConfirmacion);
                        }
                    });
                }


                RV.setAdapter(adapter);
                RV.addItemDecoration(new HorizontalDividerItemDecoration.Builder(Act.getBaseContext().getApplicationContext()).color(Color.BLACK).build());
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                // Extraemos las provincias que devuelva el WS

                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<Doctor>>() {
                }.getType();
                Collection<Doctor> enums = gson.fromJson(respuesta, collectionType);

                Doctor[] map = enums.toArray(new Doctor[enums.size()]);
                System.out.println("DEVOLVIO un Object>>>>>>>>>>>>>>" + respuesta);
                System.out.println("ENUMS>>>>>>>>" + enums.isEmpty());

                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();

                if (map.length == 0) {
                    String name = Act.getResources().getString(R.string.label_mensaje_not_found);
                    ValorFiltros dato = new ValorFiltros(0, name);
                    prov.add(dato);
                } else {
                    for (Doctor p : map) {
                        ValorFiltros dato = new ValorFiltros(p.getInformation().getDoctorID(), p.getInformation().getNombre() + " " + p.getInformation().getApellido());
                        System.out.println("id: " + dato.getLlave() + ", nombre: " + dato.getValor());
                        prov.add(dato);
                    }

                }


                RecyclerView RV = (RecyclerView) v.findViewById(R.id.recyclerview);

                RV.setLayoutManager(new LinearLayoutManager(Act));
                RecyclerViewAdapter2 adapter;
                if (map.length == 0) {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //     Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            ViewPager vpFiltros = (ViewPager) Act.findViewById(R.id.viewpager);
                            vpFiltros.setCurrentItem(3, true);
                        }
                    });

                } else {
                    adapter = new RecyclerViewAdapter2(prov, new RecyclerViewAdapter2.OnItemClickListener() {
                        @Override
                        public void onItemClick(ValorFiltros item) {
                            //  Toast.makeText(Act.getBaseContext().getApplicationContext(), item.getValor(), Toast.LENGTH_LONG).show();
                            DatosGlobales var = DatosGlobales.getInstance();
                            var.setIdDoctor(item.getLlave());
                            var.setNombreDoctor(item.getValor());

                            Intent intentConfirmacion = new Intent(Act, BusquedaTurnoFinalActivity.class);
                            Act.startActivity(intentConfirmacion);
                        }
                    });
                }

                RV.setAdapter(adapter);
                RV.addItemDecoration(new HorizontalDividerItemDecoration.Builder(Act.getBaseContext().getApplicationContext()).color(Color.BLACK).build());

            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                super.onFailure(statusCode, headers, responseString, throwable);
                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);

                if( throwable.getCause() instanceof ConnectTimeoutException)
                    Toast.makeText(Act.getBaseContext().getApplicationContext(), "Ocurrio un error de conexion, Intentelo mas tarde", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(Act.getBaseContext().getApplicationContext(), "Ocurrio un error, Intentelo mas tarde", Toast.LENGTH_LONG).show();

            }
        });


    }


}


