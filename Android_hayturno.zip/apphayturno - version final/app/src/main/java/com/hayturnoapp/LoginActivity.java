package com.hayturnoapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.hayturnoapp.models.Appointment;
import com.hayturnoapp.models.Autorizacion;
import com.hayturnoapp.models.InfoGeneral;
import com.hayturnoapp.models.JsonResSimple;
import com.hayturnoapp.utils.DatosCitas;
import com.hayturnoapp.utils.DatosUsuarios;
import com.hayturnoapp.utils.ExceptionHandler;
import com.hayturnoapp.utils.RestClient;
import com.hayturnoapp.utils.Session;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;
import com.tmxlr.lib.driodvalidatorlight.Form;
import com.tmxlr.lib.driodvalidatorlight.helper.RegexTemplate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import cz.msebera.android.httpclient.Header;


public class LoginActivity extends AppCompatActivity {

    private LinearLayout linearLayoutLocaField;
    private LinearLayout linearLayoutSocialField;
    private Button btnNuevaCuenta;
    private Button btnLogin;
    private Button btnCancelarLogin;

    private Session sesion;

    private static final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,20})";
    private Pattern patronPassword;

    private GoogleApiClient mGoogleApiClient;
    private static final int RC_SIGN_IN = 9001;

    private LoginButton loginButtonFb;
    private CallbackManager callbackManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // manejador de error
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setContentView(R.layout.activity_login_home);

        /*********************************** SECCION DE FB *************************************************/
        /***************************************************************************************************/
        loginButtonFb = (LoginButton) findViewById(R.id.login_button_Fb);
        //****************************************************************************************************

        linearLayoutLocaField = (LinearLayout) findViewById(R.id.local_field_login);
        linearLayoutSocialField = (LinearLayout) findViewById(R.id.social_media_buttons);
        btnNuevaCuenta = (Button) findViewById(R.id.buttonNuevaCuenta);
        btnLogin = (Button) findViewById(R.id.buttonLogin);
        btnCancelarLogin = (Button) findViewById(R.id.buttonCancelarLogin);

        sesion = new Session(this);

//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestIdToken(getString(R.string.default_web_client_id))
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        SignInButton Glogin = (SignInButton) findViewById(R.id.login_button_G);
        Glogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
                startActivityForResult(signInIntent, RC_SIGN_IN);
            }
        });
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------


        btnNuevaCuenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearLayoutLocaField.setVisibility(View.VISIBLE);
                linearLayoutSocialField.setVisibility(View.GONE);
            }
        });

        btnCancelarLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearLayoutSocialField.setVisibility(View.VISIBLE);
                linearLayoutLocaField.setVisibility(View.GONE);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = "";
                String contraseña = "";

                EditText tvnombreEmail = (EditText) findViewById(R.id.editTextEmail);
                EditText tvcontraseña = (EditText) findViewById(R.id.editTextPassword);
                Form form = new Form(LoginActivity.this);
                patronPassword = Pattern.compile(PASSWORD_PATTERN);

                form.check(tvnombreEmail, RegexTemplate.NOT_EMPTY_PATTERN, "El email no debe estar vacio");
                form.check(tvnombreEmail, RegexTemplate.EMAIL_PATTERN, "Formato incorrecto, ejemplo de formato: Hay.Turno123@gmail.com");

                form.check(tvcontraseña, RegexTemplate.NOT_EMPTY_PATTERN, "La contraseña no debe ir vacia");


                if (form.validate()) {
                    email = tvnombreEmail.getText().toString();
                    contraseña = tvcontraseña.getText().toString();

                    try {
                        startLogin(email, contraseña, "USRPASSWD", "");
                    } catch (JSONException | UnsupportedEncodingException e) {
                        Toast.makeText(LoginActivity.this, "Ocurrio un error intentado acceder", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Revise la informacion nuevamente", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    @Override
    protected void onResume() {

        super.onResume();
        callbackManager = CallbackManager.Factory.create();

        loginButtonFb = (LoginButton) findViewById(R.id.login_button_Fb);

        loginButtonFb.setReadPermissions("public_profile", "email", "user_friends");
        loginButtonFb.registerCallback(callbackManager, mCallBack);
    }

    @Override
    protected void onPause() {

        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    private FacebookCallback<LoginResult> mCallBack = new FacebookCallback<LoginResult>() {
        @Override
        public void onSuccess(final LoginResult loginResult) {

            // App code
            GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                @Override
                public void onCompleted(JSONObject object, GraphResponse response) {
                    String email = "";
                    String newTokenFB = "";

                    //               Log.e("responseFB: ", response + "");
                    try {
                        email = object.getString("email").toString();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    newTokenFB = loginResult.getAccessToken().getToken();
                    //           Toast.makeText(LoginActivity.this, "connectado a graph", Toast.LENGTH_LONG).show();
                    try {
                        startLogin(email, newTokenFB, "FB", "");
                    } catch (JSONException | UnsupportedEncodingException e) {
                        Toast.makeText(LoginActivity.this, "Ocurrio un error intentado acceder", Toast.LENGTH_LONG).show();
                    }

                }

            });

            Bundle parameters = new Bundle();
            parameters.putString("fields", "id,name,first_name,last_name,email,gender");
            request.setParameters(parameters);
            request.executeAsync();
        }

        @Override
        public void onCancel() {
            //     progressDialog.dismiss();
            Toast.makeText(LoginActivity.this, "cancelado el callback", Toast.LENGTH_LONG).show();
        }

        @Override
        public void onError(FacebookException e) {
            //   progressDialog.dismiss();

            Toast.makeText(LoginActivity.this, "Error en el callback", Toast.LENGTH_LONG).show();
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int responseCode, Intent intent) {
        super.onActivityResult(requestCode, responseCode, intent);

        if (requestCode == RC_SIGN_IN) {  //parte de G+
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(intent);

            if (result.isSuccess()) {
                // Signed in successfully, show authenticated UI.
                GoogleSignInAccount acct = result.getSignInAccount();
                //    acct.getIdToken(); // el token que se debe de pasar

                try {
                    startLogin(acct.getEmail(), acct.getIdToken(), "G", acct.getId());
                } catch (JSONException | UnsupportedEncodingException e) {
                    Toast.makeText(LoginActivity.this, "Ocurrio un error intentado acceder", Toast.LENGTH_LONG).show();
                }

            } else {
                // Signed out,
                Toast.makeText(this, "Error de autenticacion, intente mas tarde", Toast.LENGTH_LONG).show();
            }
        }// PARTE DE FB
        else {

            if (responseCode == Activity.RESULT_OK) {
                callbackManager.onActivityResult(requestCode, responseCode, intent);
                // Toast.makeText(this, "Access Token: " + accessToken, Toast.LENGTH_LONG).show();
            } else {

                Toast.makeText(this, "Error: en onActivityResult", Toast.LENGTH_LONG).show();
            }

        }
    }


    public void startLogin(final String email, final String password, final String loginPolicy, final String idGoogle) throws JSONException, UnsupportedEncodingException {
        JSONObject obj = new JSONObject();
        obj.put("eml", email);
        obj.put("loginPolicy", loginPolicy);

        if (loginPolicy.equals("FB"))
            obj.put("facebooktoken", password);
        else if (loginPolicy.equals("G")) {
            obj.put("googletoken", password);
            //MODIFICACION DE ID DEL USUARIO DE GOOGLE
            obj.put("googleUserId", idGoogle);
        } else
            obj.put("psswd", password);

        System.out.println("json login: " + obj.toString());

        RestClient.postJson(null, "/patient/login", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                //formateamos la respuesta y creamos un objeto a partir de la respuesta
                String respuesta = response.toString();
                Gson gson = new Gson();

                InfoGeneral infoPaciente = gson.fromJson(respuesta, InfoGeneral.class);

                //extraemos la data necesaria
                String nombre = infoPaciente.getNombre() + " " + infoPaciente.getApellido();
                String email = infoPaciente.getEmail();
                int patientID = infoPaciente.getPatientID();

                Session sesion = new Session(LoginActivity.this);
                sesion.crearLoginSession(nombre, email, patientID, loginPolicy, password);

                //nos dirigimos a la pantalla de inicio

                Intent intent = new Intent(LoginActivity.this, HayTurnoInitActivity.class);
                startActivity(intent);

            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                super.onFailure(statusCode, headers, responseString, throwable);
                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                super.onFailure(statusCode, headers, throwable, errorResponse);
                String respString = errorResponse.toString();
                System.out.println("Error con el usuario>>>>>>>>>" + respString);

                Gson gson = new Gson();
                JsonResSimple jrs = gson.fromJson(respString, JsonResSimple.class);
                Toast.makeText(LoginActivity.this, jrs.getMSG_(), Toast.LENGTH_LONG).show();

            }


        });

    }


} // fin del activity
