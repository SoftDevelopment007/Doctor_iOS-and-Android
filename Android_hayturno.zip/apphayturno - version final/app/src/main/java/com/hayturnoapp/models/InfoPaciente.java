package com.hayturnoapp.models;

public class InfoPaciente {

    private Integer patientID;  //    "patientID":21,
    private InfoGeneral information;

    public Integer getPatientID() {
        return patientID;
    }

    public void setPatientID(Integer patientID) {
        this.patientID = patientID;
    }

    public InfoGeneral getInformation() {
        return information;
    }

    public void setInformation(InfoGeneral information) {
        this.information = information;
    }
}
