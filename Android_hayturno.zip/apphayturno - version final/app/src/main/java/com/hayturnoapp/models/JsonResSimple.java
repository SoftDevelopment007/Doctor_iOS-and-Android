package com.hayturnoapp.models;

/**
 * Created by Nicolas on 01/10/2016.
 */

public class JsonResSimple {

    private String STATUS;
    private String MSG_;

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    public String getMSG_() {
        return MSG_;
    }

    public void setMSG_(String MSG_) {
        this.MSG_ = MSG_;
    }
}
