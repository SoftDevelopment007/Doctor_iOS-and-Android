package com.hayturnoapp.models;

import com.bignerdranch.expandablerecyclerview.Model.ParentListItem;

import java.util.List;

public class MedicoFavorito implements ParentListItem
{

    private List<MedicoFavoritoHijo> listadoHijos;
    private String Title;

    public MedicoFavorito(List<MedicoFavoritoHijo> listadoHijos, String title) {
        this.listadoHijos = listadoHijos;
        Title = title;
    }

    @Override
    public boolean isInitiallyExpanded() {
        return false;
    }

    @Override
    public List<?> getChildItemList() {
        return listadoHijos;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }


}
