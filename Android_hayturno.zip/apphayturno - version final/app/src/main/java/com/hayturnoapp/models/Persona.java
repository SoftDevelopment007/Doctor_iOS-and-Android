package com.hayturnoapp.models;

/**
 * Created by Nicolas on 05/04/2017.
 */

public class Persona {
}
