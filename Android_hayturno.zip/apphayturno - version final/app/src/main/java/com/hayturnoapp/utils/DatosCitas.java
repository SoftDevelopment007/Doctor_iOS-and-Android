package com.hayturnoapp.utils;

import android.app.Application;

import java.util.List;

/**
 * Created by Nicolas on 13/10/2016.
 */

public class DatosCitas extends Application {

    private List<String> CitasUsuario;


    private static DatosCitas ourInstance = new DatosCitas();

    public static DatosCitas getInstance() {
        return ourInstance;
    }

    private DatosCitas() {
    }

    public List<String> getCitasUsuario() {
        return CitasUsuario;
    }

    public void setCitasUsuario(List<String> citasUsuario) {
        CitasUsuario = citasUsuario;
    }
}
