package com.hayturnoapp.adapters;


import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hayturnoapp.R;
import com.hayturnoapp.models.ValorFiltros;

import java.util.List;
import java.util.Map;

public class RecyclerViewAdapter2 extends RecyclerView.Adapter<RecyclerViewAdapter2.ViewHolder> {
    public interface OnItemClickListener
    {
        void  onItemClick(ValorFiltros item);
    }

    private List<ValorFiltros> mItems;


    private final OnItemClickListener listener;


    public RecyclerViewAdapter2(List<ValorFiltros> items, OnItemClickListener listener) {

        mItems = items;
        this.listener = listener;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i)  {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_row, viewGroup, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.bind(i, listener);

    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }


   // ViewHolder de los elementos que se generar a partir de la data
    public class ViewHolder extends RecyclerView.ViewHolder
    {

        private final TextView mTextView;

        ViewHolder(View v) {
            super(v);
            mTextView = (TextView)v.findViewById(R.id.list_item);
        }

        public void bind(final int position, final OnItemClickListener listener) {
            final ValorFiltros it = mItems.get(position);
            mTextView.setText(it.getValor());

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    listener.onItemClick(it);
                }
            });
        }

    }// Fin del viewholder



}
