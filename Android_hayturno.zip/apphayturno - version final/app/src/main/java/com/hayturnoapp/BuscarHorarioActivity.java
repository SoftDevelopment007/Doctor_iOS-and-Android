package com.hayturnoapp;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.graphics.Typeface;
import android.widget.Spinner;
import android.widget.Toast;

import java.lang.reflect.Type;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hayturnoapp.models.Appointment;
import com.hayturnoapp.models.DoctorSchedules;
import com.hayturnoapp.utils.DatosGlobales;
import com.hayturnoapp.utils.DatosUsuarios;
import com.hayturnoapp.utils.ExceptionHandler;
import com.hayturnoapp.utils.RestClient;
import com.hayturnoapp.utils.Session;
import com.hayturnoapp.utils.Utils;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import cz.msebera.android.httpclient.Header;


public class BuscarHorarioActivity extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;

    private RadioGroup rgHora;  // RadioButtons de AM Y PM

    //variables de control de radiogroups
    private RadioButton horarioElegido;
    private RadioButton horarioAnterior;
    private RadioButton horarioAnteriorGRA;
    private String GrActual;
    private String GrAnterior;


    private RadioButton botonAM;
    private RadioButton botonPM;

    private Spinner dropdownMonth;
    private Spinner dropdownYear;
    private Spinner dropdownDay;


    private RadioGroup RgHorasCitas1;
    private RadioGroup RgHorasCitas2;
    private RadioGroup RgHorasTurno;

    private Button botonConfirmacion;

    private int year;
    private int month;
    private int day;

    List<String> horariosDoctor;


    private int ActCreado;

    private Drawer resultDrawer;
    private AccountHeader headerResult;

    private String[] activityTitles;
    private Session sesion;

    private boolean usuarioInteractuando; //varible de control


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        // manejador de error
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setContentView(R.layout.activity_buscar_horario_cita);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);


        activityTitles = getResources().getStringArray(R.array.nav_item_activity_titles);

        ActCreado = 0;
        GrActual = "";
        GrAnterior = "";

        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE,1); // seteamos a manana
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day = c.get(Calendar.DAY_OF_MONTH);

        sesion = new Session(this);

        horariosDoctor = new ArrayList<>();

        rgHora = (RadioGroup) findViewById(R.id.RadioGroupHorario);
        botonAM = (RadioButton) findViewById(R.id.AM_radiobutton);
        botonPM = (RadioButton) findViewById(R.id.PM_radiobutton);

        dropdownYear = (Spinner) findViewById(R.id.year_display);
        dropdownMonth = (Spinner) findViewById(R.id.month_display);
        dropdownDay = (Spinner) findViewById(R.id.date_display);

        RgHorasCitas1 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas1);
        RgHorasCitas2 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas2);
        RgHorasTurno = (RadioGroup) findViewById(R.id.RadioGroupHorario);


        botonConfirmacion = (Button) findViewById(R.id.buttonConfirmarHorario);
        botonConfirmacion.setEnabled(false); // va a tener que elegir un radio button  para que s pueda habilitar
        botonAM.setChecked(true);
        botonPM.setChecked(false);


        crearRadioButtons();


        RgHorasCitas1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                RadioButton rbelegido = (RadioButton) group.findViewById(checkedId);
                boolean esTrue = rbelegido.isChecked();
                System.out.println("Llamado grp1::::: boton cambio de estado " + rbelegido.getText().toString());
                cambiarRadioButton(rbelegido, esTrue, "GR1");
            }
        });


        RgHorasCitas2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                RadioButton rbelegido = (RadioButton) group.findViewById(checkedId);
                boolean esTrue = rbelegido.isChecked();
                System.out.println("Llamado grp2:::::" + rbelegido.getText().toString());
                cambiarRadioButton(rbelegido, esTrue, "GR2");

            }
        });

        RgHorasTurno.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                RadioButton rbelegido = (RadioButton) group.findViewById(checkedId);
                cambiarHorariosRadioButton(rbelegido);

            }
        });


        llenarSpiners(dropdownYear, dropdownMonth, dropdownDay);


        if (sesion.isLoggedIn())
        {
            toolbar.setNavigationIcon(R.drawable.ic_menu);
            HashMap<String, String> user = sesion.getDetalleUsuario();
            String directorioFotoUsuario = "";
            Utils u = new Utils();
            final ProfileDrawerItem datoUsuario = new ProfileDrawerItem();
            datoUsuario.withName(user.get(sesion.KEY_NAME));

            directorioFotoUsuario =  sesion.getDirectorioFotoUsuario();

            if( directorioFotoUsuario == null)
                directorioFotoUsuario = "";

            if( !directorioFotoUsuario.isEmpty() )
                datoUsuario.withIcon(u.loadImageFromStorage(directorioFotoUsuario));
            else
                datoUsuario.withIcon(getResources().getDrawable(R.drawable.foto_persona));

            headerResult = new AccountHeaderBuilder()
                    .withActivity(this)
                    .withHeaderBackground(R.color.colorBackBlueLight)
                    .addProfiles(datoUsuario)
                    .withSelectionListEnabledForSingleProfile(false)
                    .build();



            //agregamos el menu de navegacion
            resultDrawer = new DrawerBuilder()
                    .withActivity(this)
                    .withToolbar(toolbar)
                    .withAccountHeader(headerResult)
                    .addDrawerItems(
                            new PrimaryDrawerItem().withName( activityTitles[0]).withIcon(R.drawable.icon_search).withIdentifier(1),
                            new PrimaryDrawerItem().withName( activityTitles[1]).withIcon(R.drawable.icon_agenda).withIdentifier(2),
                            new PrimaryDrawerItem().withName( activityTitles[2]).withIcon(R.drawable.icon_mis_medicos).withIdentifier(3),
                            new PrimaryDrawerItem().withName( activityTitles[3]).withIcon(R.drawable.icon_datos_personales).withIdentifier(4),
                            new PrimaryDrawerItem().withName( activityTitles[4]).withIcon(R.drawable.icon_close_session).withIdentifier(5)
                    ).withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener()
                    {
                        @Override
                        public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                            //revisamos si drawerItem esta seteado
                            //drawerItem puede ser nulo por diferentes razones
                            //--> click en encaebzado
                            //--> click en el pie
                            // esos items no contiene drawerItem
                            if (drawerItem != null) {
                                Intent intent = null;
                                int identificador = (int) drawerItem.getIdentifier();
                                switch (identificador) {
                                    case 1:
                                        intent = new Intent(BuscarHorarioActivity.this, BusquedaTurnoActivity.class);
                                        break;
                                    case 2:
                                        intent = new Intent(BuscarHorarioActivity.this, CalendariosTurnoActivity.class);
                                        break;
                                    case 3:
                                        intent = new Intent(BuscarHorarioActivity.this, MisMedicosActivity.class);
                                        break;
                                    case 4:
                                        intent = new Intent(BuscarHorarioActivity.this, DatosPersonalesModificacionActivity.class);
                                        break;
                                    case 5:
                                        signOut();
                                        break;

                                }

                                if (intent != null) {
                                    BuscarHorarioActivity.this.startActivity(intent);
                                }
                            }
                            return false;
                        }
                    }) //fin del OnDrawerItemClickListener
                    .build();
        }

    }

    private void signOut()
    {
        sesion.logoutUser();
    }

    public void startAprobacionTurno(View v)
    {
        DatosGlobales var = DatosGlobales.getInstance();
        String horario_inicio = horarioElegido.getText().toString();
        String horario_fin = "";
        String fechaTurno = "";
        String dia = dropdownDay.getSelectedItem().toString();
        String mes = dropdownMonth.getSelectedItem().toString().toLowerCase();
        String año = dropdownYear.getSelectedItem().toString();
        String formatoMes;
        String formatoDia;



        String[] horas = horario_inicio.split(":");

        DateFormat df = new SimpleDateFormat("HH:mm");
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

        GregorianCalendar TimeTurno = new GregorianCalendar();
        TimeTurno.set(Calendar.HOUR_OF_DAY, Integer.valueOf(horas[0]));
        TimeTurno.set(Calendar.MINUTE, Integer.valueOf(horas[1]));

        TimeTurno.add(Calendar.MINUTE, 30);


        horario_fin = df.format(TimeTurno.getTime());
        Date dausuario= new Date() ;
        Date Datehoy = new Date();
        fechaTurno = devolverFechaFormateada(dia, mes, año);
        try
        {
          dausuario = null;
          dausuario = sdf.parse(fechaTurno);
        }
        catch (ParseException e)
        {
            e.printStackTrace();
        }

        if (dausuario.after(Datehoy))
        {
        //System.out.println("valor: ::::::::" +fechaTurno );

        var.setFecha_turno(fechaTurno);
        var.setHorario_Inicio(horario_inicio);
        var.setHorario_Fin(horario_fin);

        Intent intent = new Intent(this, ConfirmacionTurnoActivity.class);
        startActivity(intent);

        }
        else
        {
            Toast.makeText(this, "No puede reservar turno con fechas anteriores o del dia actual. elija otra fecha", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();

    }


    //crea radiobuttons a partir de los datos recibidos del web service del doctor
    public void crearRadioButtons() {
        final RadioGroup RgHorasCitas1 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas1);
        final RadioGroup RgHorasCitas2 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas2);

        DatosGlobales DGvar = DatosGlobales.getInstance();
        String fechaConsulta = "";
        boolean existeCita = false;

        fechaConsulta = devolverFechaFormateada(String.valueOf(day), String.valueOf(month), String.valueOf(year));

        System.out.println("fecha inicial de consulta>>>>>>: " + fechaConsulta);

        try {
            ObtenerCitasMedico(fechaConsulta, new Callback<List<String>>() {
                @Override
                public void onResponse(List<String> data) {
                    horariosDoctor.addAll(data);
                    llenarRadioButtons("AM", RgHorasCitas1, RgHorasCitas2);
                }
            });

        } catch (JSONException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }// items.clear();

    }

    @Override
    public void onUserInteraction()
    {
        super.onUserInteraction();
        usuarioInteractuando = true;
    }

    public void llenarSpiners(Spinner dpYear, Spinner dpMonth, Spinner dpDay) {
        ArrayList<Integer> years = new ArrayList<Integer>();
        ArrayList<String> months = new ArrayList<String>();
        final ArrayList<Integer> days = new ArrayList<Integer>();

        Calendar mcal = new GregorianCalendar(year, month, day);

        int esteAnio = year;
        int diasMes = mcal.getActualMaximum(Calendar.DAY_OF_MONTH);
        int posicionsetear = 0;

        for (int i = 0; i < 10; i++) {
            years.add(esteAnio + i);
        }

        for (int i = 0; i < 12; i++) {
            months.add(getMes(i, Locale.getDefault()));
        }

        for (int i = 0; i < diasMes; i++) {
            days.add(i + 1);
        }

        // seteamos el año....
        ArrayAdapter<Integer> dataAdapterYers = new ArrayAdapter<Integer>(this, R.layout.spinner_item, years);
        dataAdapterYers.setDropDownViewResource(R.layout.spinner_dropdown_item);
        dpYear.setAdapter(dataAdapterYers);

        dpYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                ActCreado += 1;
                String año = parent.getItemAtPosition(position).toString();
                String mes = dropdownMonth.getSelectedItem().toString().toLowerCase();
                String dia = dropdownDay.getSelectedItem().toString();
                String fechaConsulta = devolverFechaFormateada(dia, mes, año);
                System.out.println("Horario> Mes::::::::::: " + fechaConsulta);

                String[] fecI = devolverFechaFormateada(dia, mes, año).split("-");

                Calendar mical = new GregorianCalendar(Integer.valueOf(fecI[2]), Integer.valueOf(fecI[1]) - 1, Integer.valueOf(fecI[0]));

                final RadioGroup RgHorasCitas1 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas1);
                final RadioGroup RgHorasCitas2 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas2);

                if (ActCreado > 3 && usuarioInteractuando)
                {
                    usuarioInteractuando= false;

                    RgHorasCitas1.removeAllViews();
                    RgHorasCitas2.removeAllViews();

                    try {
                        ObtenerCitasMedico(fechaConsulta, new Callback<List<String>>() {
                            @Override
                            public void onResponse(List<String> data) {
                                if (!horariosDoctor.isEmpty()) {
                                    horariosDoctor.clear();
                                }

                                horariosDoctor.addAll(data);
                                RadioButton btnAMPM = (RadioButton) RgHorasTurno.findViewById(RgHorasTurno.getCheckedRadioButtonId());
                                String textoAMPPM = "";

                                if (btnAMPM.equals(botonAM))
                                    textoAMPPM = "AM";
                                else
                                    textoAMPPM = "PM";
                                System.out.print(">>>>llamada de spinner anio");
                                llenarRadioButtons(textoAMPPM, RgHorasCitas1, RgHorasCitas2);
                            }
                        });

                    } catch (JSONException | UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }// items.clear();


                }//fin de if de actcreado

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        //seteamos el mes
        //  ArrayAdapter<String> dataAdapterMonth = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, months);
//        dataAdapterMonth.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        ArrayAdapter<String> dataAdapterMonth = new ArrayAdapter<String>(this, R.layout.spinner_item, months);
        dataAdapterMonth.setDropDownViewResource(R.layout.spinner_dropdown_item);
        dpMonth.setAdapter(dataAdapterMonth);

        //seteamos el mes actual
        String mespordefecto = getMes(mcal.get(Calendar.MONTH) , Locale.getDefault());
        posicionsetear = dataAdapterMonth.getPosition(mespordefecto);
        dpMonth.setSelection(posicionsetear,false);
        dpMonth.setEnabled(true);

        posicionsetear  = 0;

        dpMonth.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ActCreado += 1;

                String año = dropdownYear.getSelectedItem().toString();
                String dia = dropdownDay.getSelectedItem().toString();
                String mes = parent.getItemAtPosition(position).toString().toLowerCase();
                String fechaConsulta = devolverFechaFormateada(dia, mes, año);
                System.out.println("Horario> Mes::::::::::: " + fechaConsulta);

                String[] fecI = devolverFechaFormateada(dia, mes, año).split("-");

                Calendar mical = new GregorianCalendar(Integer.valueOf(fecI[2]), Integer.valueOf(fecI[1]) - 1, Integer.valueOf(fecI[0]));

                final RadioGroup RgHorasCitas1 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas1);
                final RadioGroup RgHorasCitas2 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas2);

                if (ActCreado > 3 && usuarioInteractuando)
                {
                    usuarioInteractuando = false;

                    RgHorasCitas1.removeAllViews();
                    RgHorasCitas2.removeAllViews();

                    try {
                        ObtenerCitasMedico(fechaConsulta, new Callback<List<String>>() {
                            @Override
                            public void onResponse(List<String> data) {
                                if (!horariosDoctor.isEmpty()) {
                                    horariosDoctor.clear();
                                }

                                horariosDoctor.addAll(data);
                                RadioButton btnAMPM = (RadioButton) RgHorasTurno.findViewById(RgHorasTurno.getCheckedRadioButtonId());
                                String textoAMPPM = "";

                                if (btnAMPM.equals(botonAM))
                                    textoAMPPM = "AM";
                                else
                                    textoAMPPM = "PM";
                                System.out.print(">>>>llamada de spinner mes");
                                llenarRadioButtons(textoAMPPM, RgHorasCitas1, RgHorasCitas2);
                            }
                        });

                    } catch (JSONException | UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }// items.clear();

                    int diasMesdin = mical.getActualMaximum(Calendar.DAY_OF_MONTH);


                    ArrayList<Integer> daysdin = new ArrayList<Integer>();
                    for (int i = 0; i < diasMesdin; i++) {
                        daysdin.add(i + 1);
                    }

                    System.out.println("Mes > dias::::::::::: " + fecI[1] + " > " + daysdin.size() + " dias>" + diasMesdin);
                    ArrayAdapter<Integer> dataAdapterDays = new ArrayAdapter<Integer>(getBaseContext(), R.layout.spinner_item, daysdin);
                    dataAdapterDays.setDropDownViewResource(R.layout.spinner_dropdown_item);
                    dropdownDay.setAdapter(dataAdapterDays);
                    dataAdapterDays.notifyDataSetChanged();

                    int posicion = 0;
                    int meselegido = mical.get(Calendar.MONTH);
                    int diatrans = Integer.valueOf(dia);

                    //verificamos si es febrero
                    if (meselegido == Calendar.FEBRUARY && daysdin.size() == 28) {
                        if (diatrans > 28)
                            diatrans = 28;
                    } else if (meselegido == Calendar.FEBRUARY && daysdin.size() == 29) {
                        if (diatrans > 29)
                            diatrans = 29;
                    }

                    posicion = dataAdapterDays.getPosition(diatrans);
                    dropdownDay.setSelection(posicion, false);
                    dropdownDay.setEnabled(true);


                }//fin de if de actcreado

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        //seteamos el dia

        ArrayAdapter<Integer> dataAdapterDays = new ArrayAdapter<Integer>(this, R.layout.spinner_item, days);
        dataAdapterDays.setDropDownViewResource(R.layout.spinner_dropdown_item);
        dpDay.setAdapter(dataAdapterDays);

        posicionsetear = dataAdapterDays.getPosition(mcal.get(Calendar.DAY_OF_MONTH));
        dpDay.setSelection(posicionsetear,false);
        dpDay.setEnabled(true);

        posicionsetear  = 0;

        dpDay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                ActCreado += 1;
                String año = dropdownYear.getSelectedItem().toString();
                String mes = dropdownMonth.getSelectedItem().toString().toLowerCase();
                String dia = parent.getItemAtPosition(position).toString();
                String fechaConsulta = devolverFechaFormateada(dia, mes, año);
                System.out.println("Horario> Mes::::::::::: " + fechaConsulta);

                String[] fecI = devolverFechaFormateada(dia, mes, año).split("-");

                Calendar mical = new GregorianCalendar(Integer.valueOf(fecI[2]), Integer.valueOf(fecI[1]) - 1, Integer.valueOf(fecI[0]));

                final RadioGroup RgHorasCitas1 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas1);
                final RadioGroup RgHorasCitas2 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas2);

                if (ActCreado > 3 && usuarioInteractuando)
                {

                    usuarioInteractuando = false;

                    RgHorasCitas1.removeAllViews();
                    RgHorasCitas2.removeAllViews();

                    try {
                        ObtenerCitasMedico(fechaConsulta, new Callback<List<String>>() {
                            @Override
                            public void onResponse(List<String> data) {
                                if (!horariosDoctor.isEmpty()) {
                                    horariosDoctor.clear();
                                }

                                horariosDoctor.addAll(data);
                                RadioButton btnAMPM = (RadioButton) RgHorasTurno.findViewById(RgHorasTurno.getCheckedRadioButtonId());
                                String textoAMPPM = "";

                                if (btnAMPM.equals(botonAM))
                                    textoAMPPM = "AM";
                                else
                                    textoAMPPM = "PM";
                                System.out.print(">>>>llamada de spinner dia");
                                llenarRadioButtons(textoAMPPM, RgHorasCitas1, RgHorasCitas2);
                            }
                        });

                    } catch (JSONException | UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }// items.clear();


                }//fin de if de actcreado

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

   }


    public String getMes(int i, Locale loc) {
        DateFormatSymbols symbols = new DateFormatSymbols(loc);
        String[] monthNames = symbols.getMonths();
        return monthNames[i].toUpperCase();
    }


    public void cambiarRadioButton(RadioButton rbelegido, boolean esTrue, String llamada) {
        System.out.println("Valor elegido: " + rbelegido.getText().toString() + " LLAMADA: " + llamada + " Estado: " + String.valueOf(rbelegido.isChecked()));

        if (horarioElegido == null && esTrue) {
            horarioElegido = rbelegido;
            horarioElegido.setTextColor(getResources().getColor(R.color.android_blue));
            botonConfirmacion.setEnabled(true);
            GrActual = llamada;
        } else {
            if (esTrue) {
                horarioElegido.setChecked(false);
                horarioElegido.setTextColor(getResources().getColor(R.color.white));

                horarioAnterior = horarioElegido;
                horarioElegido = null;
                rbelegido.setChecked(true);
                horarioElegido = rbelegido;
                horarioElegido.setTextColor(getResources().getColor(R.color.android_blue));

                System.out.println("llamada anterior: " + GrAnterior + ", llamada actual" + GrActual + "IF1");
                if (!GrActual.equals(llamada)) {
                    GrAnterior = GrActual;
                    GrActual = llamada;
                    horarioAnteriorGRA = horarioAnterior;
                    System.out.println("llamada anterioR CAMBIO EL HORARIO ANTERIORGRA IF1, VALOR HORARIOANTERIORGRA: " + horarioAnteriorGRA.getText().toString());

                }

            } else if (rbelegido.equals(horarioAnterior) && !GrAnterior.equals(GrActual))
            //          else if ((rbelegido.equals(horarioAnterior) && !GrActual.equals(llamada)) || rbelegido.equals(horarioAnteriorGRA)  )
            {
                GrAnterior = GrActual;
                GrActual = llamada;
                horarioAnteriorGRA = horarioAnterior;
                System.out.println("llamada VALOR HORARIOANTERIORGRA en if2: " + horarioAnteriorGRA.getText().toString());

                horarioElegido.setChecked(false);
                horarioElegido.setTextColor(getResources().getColor(R.color.white));
                horarioAnterior = horarioElegido;
                horarioElegido = null;
                horarioElegido = rbelegido;
                horarioElegido.setChecked(true);
                horarioElegido.setTextColor(getResources().getColor(R.color.android_blue));
                System.out.println("llamada anterior: " + GrAnterior + ", llamada actual" + GrActual + "IF2");

            }


        }

    }

    //Setea los horarios de los readiobuttons
    public void cambiarHorariosRadioButton(RadioButton rbelegido) {
        RadioGroup RgHorasCitas1 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas1);
        RadioGroup RgHorasCitas2 = (RadioGroup) findViewById(R.id.RadioGroupHorasCitas2);
        String text = ""; //rbelegido.getText().toString();

        if (rbelegido.equals(botonAM))
            text = "AM";
        else
            text = "PM";

        RgHorasCitas1.removeAllViews();
        RgHorasCitas2.removeAllViews();
        llenarRadioButtons(text, RgHorasCitas1, RgHorasCitas2);

    }


    public void llenarRadioButtons(String Horario, RadioGroup RgHorasCitas1, RadioGroup RgHorasCitas2) {
        SimpleDateFormat df = new SimpleDateFormat("HH:mm");
        GregorianCalendar startTime = new GregorianCalendar();
        final float scale = this.getResources().getDisplayMetrics().density;
        boolean existeCita = false;
        boolean ishackneeded = false;

        ishackneeded = Build.VERSION.SDK_INT > 22;

        if (Horario.equals("AM")) {
            startTime.set(Calendar.HOUR_OF_DAY, 6);
            startTime.set(Calendar.MINUTE, 0);

            for (int i = 0; i < 12; i++) {
                RadioButton btn = new RadioButton(this);
                String hora = df.format(startTime.getTime());
                //para el texto
                //     btn.setText("tiempo "+ String.valueOf(i));

                btn.setTextColor(Color.WHITE);

                if (!horariosDoctor.isEmpty()) {
                    if (horariosDoctor.contains(hora + ":00"))
                        existeCita = true;
                }

                btn.setText(hora);
                btn.setEnabled(!existeCita);
                btn.setButtonDrawable(R.drawable.selector_radiobuttonhorario);

                btn.setTextSize(18.0f);
                btn.setPadding(btn.getPaddingLeft() + (int) (10.0f * scale + 0.5f), 18, 0, 18);

                if (i < 6) {
                    Drawable drawable = getResources().getDrawable(R.drawable.selector_radiobuttonhorario);

                    if (ishackneeded) {
                        drawable.setBounds(0, 0, 120, 40);
                    } else {
                        drawable.setBounds(0, 0, 61, 20);
                    }


                    btn.setButtonDrawable(android.R.color.transparent);
                    btn.setCompoundDrawables(null, null, drawable, null);
                    btn.setCompoundDrawablePadding(btn.getPaddingLeft() + (int) (2.0f * scale + 0.5f));
                    RgHorasCitas1.addView(btn);
                } else {
                    RgHorasCitas2.addView(btn);
                }
                startTime.add(Calendar.MINUTE, 30);
                existeCita = false;
            }


        } else {
            startTime.set(Calendar.HOUR_OF_DAY, 14);
            startTime.set(Calendar.MINUTE, 0);
            for (int i = 0; i < 12; i++) {
                RadioButton btn = new RadioButton(this);
                String hora = df.format(startTime.getTime());
                //para el texto
                //     btn.setText("tiempo "+ String.valueOf(i));

                btn.setTextColor(Color.WHITE);

                if (!horariosDoctor.isEmpty()) {
                    if (horariosDoctor.contains(hora + ":00"))
                        existeCita = true;
                }

                btn.setText(hora);
                btn.setEnabled(!existeCita);
                btn.setTextSize(18.0f);
                btn.setButtonDrawable(R.drawable.selector_radiobuttonhorario);
                btn.setPadding(btn.getPaddingLeft() + (int) (10.0f * scale + 0.5f), 18, 0, 18);

                if (i < 6) {
                    Drawable drawable = getResources().getDrawable(R.drawable.selector_radiobuttonhorario);

                    if (ishackneeded) {
                        drawable.setBounds(0, 0, 120, 40);
                    } else {
                        drawable.setBounds(0, 0, 61, 20);
                    }


                    btn.setButtonDrawable(android.R.color.transparent);
                    btn.setCompoundDrawables(null, null, drawable, null);
                    btn.setCompoundDrawablePadding(btn.getPaddingLeft() + (int) (2.0f * scale + 0.5f));
                    RgHorasCitas1.addView(btn);
                } else {
                    RgHorasCitas2.addView(btn);
                }
                startTime.add(Calendar.MINUTE, 30);
                existeCita = false;
            }
        }
    }


    public void ObtenerCitasMedico(String fechaConsulta, final Callback<List<String>> callback) throws JSONException, UnsupportedEncodingException {
        DatosGlobales DGvar = DatosGlobales.getInstance();

        JSONObject obj = new JSONObject();
        obj.put("doctorID", DGvar.getIdDoctor());
        //    obj.put("doctorID", 1);
        obj.put("hospitalID", DGvar.getIdCentroMedico());
        obj.put("appointmentDateStart", fechaConsulta);
        obj.put("appointmentDateEnd", fechaConsulta);

        System.out.println("Dato enviado>>>>>>>>>>>>>>" + DGvar.getIdDoctor() + " " + DGvar.getIdCentroMedico() + " " + fechaConsulta);

        final List<String> horarios = new ArrayList<String>();

        RestClient.postJson(null, "/doctor/schedules", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                String respuesta = response.toString();
                Gson gson = new Gson();

                DoctorSchedules map = gson.fromJson(respuesta, DoctorSchedules.class);
                for (Appointment p : map.getAppointments()) {
                    horarios.add(p.getHoraInicio());
                }

                if (callback != null) {
                    callback.onResponse(horarios);
                }

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                // Extraemos las provincias que devuelva el WS
                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<DoctorSchedules>>() {
                }.getType();
                Collection<DoctorSchedules> enums = gson.fromJson(respuesta, collectionType);

                DoctorSchedules[] map = enums.toArray(new DoctorSchedules[enums.size()]);
                System.out.println("DEVOLVIO un array>>>>>>>>>>>>>>" + respuesta);

                //  List<DoctorSchedules> prov = new ArrayList<DoctorSchedules>();

                if (callback != null) {
                    callback.onResponse(horarios);
                }


            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);
                //  Toast.makeText(, "Ocurrio un error de conexion", Toast.LENGTH_LONG).show();
            }
        });


    }


    public String devolverFechaFormateada(String dia, String mes, String año) {
        String formatoDia = "";
        String formatoMes = "";
        String fechaTurno = "";

        formatoDia = String.format("%02d", Integer.valueOf(dia));

        if (mes.matches("[0-9]+")) {
            formatoMes = mes;
        } else {
            switch (mes) {
                case "enero":
                    formatoMes = String.format("%02d", 1);
                    break;
                case "febrero":
                    formatoMes = String.format("%02d", 2);
                    break;
                case "marzo":
                    formatoMes = String.format("%02d", 3);
                    break;
                case "abril":
                    formatoMes = String.format("%02d", 4);
                    break;
                case "mayo":
                    formatoMes = String.format("%02d", 5);
                    break;
                case "junio":
                    formatoMes = String.format("%02d", 6);
                    break;
                case "julio":
                    formatoMes = String.format("%02d", 7);
                    break;
                case "agosto":
                    formatoMes = String.format("%02d", 8);
                    break;
                case "septiembre":
                    formatoMes = String.format("%02d", 9);
                    break;
                case "octubre":
                    formatoMes = String.valueOf(10);
                    break;
                case "noviembre":
                    formatoMes = String.valueOf(11);
                    break;
                case "diciembre":
                    formatoMes = String.valueOf(12);
                    break;
                default:
                    formatoMes = String.valueOf(13);             //      "No hay mes";
            }
        }
        fechaTurno = formatoDia + "-" + formatoMes + "-" + año;

        return fechaTurno;

    }

    // interface para hacer un callback al ws
    public interface Callback<T> {
        void onResponse(T t);
    }
}












