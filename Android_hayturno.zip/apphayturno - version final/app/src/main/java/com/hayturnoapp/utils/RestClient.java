package com.hayturnoapp.utils;

import android.content.Context;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import cz.msebera.android.httpclient.entity.ByteArrayEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;


public class RestClient {


   // private static final String servidor = "http://162.243.163.13:8090/DocAppointments/rest";
    private static final String servidor = "http://67.205.136.161:8070/DocAppointments/rest";

    private static AsyncHttpClient client = new AsyncHttpClient();
    private static SyncHttpClient client2 = new SyncHttpClient();

    public static void get(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.get(getAbsoluteUrl(url), params, responseHandler);
    }

    public static void post(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        //    client.addHeader("Content-Type", "application/json");
        client.post(getAbsoluteUrl(url), params, responseHandler);
    }

    public static void postJson(Context con, String url, JSONObject jsonObject, JsonHttpResponseHandler responseHandler) throws JSONException, UnsupportedEncodingException
    {

        ByteArrayEntity entity = new ByteArrayEntity(jsonObject.toString().getBytes("UTF-8"));
        entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));

        client.post(con,getAbsoluteUrl(url),entity,"application/json",responseHandler);

    }

    public static void postFoto(Context con, String url, RequestParams params, JsonHttpResponseHandler responseHandler) throws JSONException, UnsupportedEncodingException
    {
        ByteArrayEntity entity = new ByteArrayEntity(params.toString().getBytes("UTF-8"));
        entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/x-www-form-urlencoded"));

       client.post(con,getAbsoluteUrl(url),entity,"application/x-www-form-urlencoded",responseHandler);
     //   client.post(null,getAbsoluteUrl(url),params,responseHandler);

    }

    public static void postJson2(Context con, String url, JSONObject jsonObject, JsonHttpResponseHandler responseHandler) throws JSONException, UnsupportedEncodingException
    {

        ByteArrayEntity entity = new ByteArrayEntity(jsonObject.toString().getBytes("UTF-8"));
        entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));

        client2.post(con,getAbsoluteUrl(url),entity,"application/json",responseHandler);

    }

    private static String getAbsoluteUrl(String relativeUrl) {
        return servidor + relativeUrl;
    }

    public static String getAbsoluteUrlserver(String relativeUrl) {
        return servidor + relativeUrl;
    }
}


