package com.hayturnoapp.adapters;


import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hayturnoapp.R;

import java.util.List;
import java.util.Map;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    public interface OnItemClickListener
    {
        void  onItemClick(String item);
    }

    private List<String> mItems;
//    private Map<Integer, String> mItems;

    private final OnItemClickListener listener;


    public RecyclerViewAdapter(List<String> items, OnItemClickListener listener) {

            mItems = items;
            this.listener = listener;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i)  {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_row, viewGroup, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
               viewHolder.bind(i, listener);

    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }


    ///// ESTA ES LA CLASE DEL VIEW HOLDER QUE ESTABA BUSCANDOOOOO
    public class ViewHolder extends RecyclerView.ViewHolder
    {

        private final TextView mTextView;

        ViewHolder(View v) {
            super(v);
            mTextView = (TextView)v.findViewById(R.id.list_item);
        }

        public void bind(final int position, final OnItemClickListener listener) {
            String it = mItems.get(position);
            mTextView.setText(it);

            final String dato= mTextView.getText().toString();
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    listener.onItemClick(dato);
                }
            });
        }

    }// Fin del viewholder



}
