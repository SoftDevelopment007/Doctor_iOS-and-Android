package com.hayturnoapp.models;

/**
 * Created by Nicolas on 18/10/2016.
 */

public class DoctorSimple {


    private Integer id;
    private String lastName;
    private Integer personID;
    private Integer specialtyID;
    private Integer assistantID;
    private String name;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPersonID() {
        return personID;
    }

    public void setPersonID(Integer personID) {
        this.personID = personID;
    }

    public Integer getSpecialtyID() {
        return specialtyID;
    }

    public void setSpecialtyID(Integer specialtyID) {
        this.specialtyID = specialtyID;
    }

    public Integer getAssistantID() {
        return assistantID;
    }

    public void setAssistantID(Integer assistantID) {
        this.assistantID = assistantID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() { return lastName;  }

    public void setLastName(String lastName) {  this.lastName = lastName;  }
}
