package com.hayturnoapp.viewholders;

import android.os.Build;
import android.view.View;
import android.view.animation.RotateAnimation;
import android.widget.ImageButton;
import android.widget.TextView;

import com.bignerdranch.expandablerecyclerview.ViewHolder.ParentViewHolder;
import com.hayturnoapp.R;
import com.hayturnoapp.models.MedicoFavorito;

/**
 * Created by Nicolas on 23/10/2016.
 */

public class MedicoFavoritoParentViewHolder extends ParentViewHolder
{
    private static final float INITIAL_POSITION = 0.0f;
    private static final float ROTATED_POSITION = 90.0f;
    public TextView mMedicoTextView;
    public ImageButton mParentDropDownArrow;
    public ImageButton mParentCorazon;

        public MedicoFavoritoParentViewHolder(View itemview)
        {
            super(itemview);

            mMedicoTextView = (TextView) itemview.findViewById( R.id.TextViewMedicoFavorito_parent);
            mParentDropDownArrow =(ImageButton) itemview.findViewById( R.id.ImageButtonMedFavFlecha_parent);
            mParentCorazon =(ImageButton) itemview.findViewById( R.id.ImageButtonMedFavCorazon_parent);

        }

    public void bind (MedicoFavorito mf)
    {
        mMedicoTextView.setText(mf.getTitle());
    }

    @Override
    public void setExpanded(boolean expanded) {
        super.setExpanded(expanded);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
        {
            if(expanded)
            {
                mParentDropDownArrow.setRotation(ROTATED_POSITION);
            }
            else
            {
                mParentDropDownArrow.setRotation(INITIAL_POSITION);
            }
        }

    }


    @Override
    public void onExpansionToggled(boolean expanded)
    {
        super.onExpansionToggled(expanded);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
        {
            RotateAnimation rotateAnimation;
            if(expanded)
            {
                rotateAnimation = new RotateAnimation(ROTATED_POSITION
                                      ,INITIAL_POSITION
                                      ,RotateAnimation.RELATIVE_TO_SELF, 0.5f
                                      ,RotateAnimation.RELATIVE_TO_SELF, 0.5f);
            }
            else
            {
                rotateAnimation = new RotateAnimation(-1* ROTATED_POSITION
                        ,INITIAL_POSITION
                        ,RotateAnimation.RELATIVE_TO_SELF, 0.5f
                        ,RotateAnimation.RELATIVE_TO_SELF, 0.5f);
            }

            rotateAnimation.setDuration(200);
            rotateAnimation.setFillAfter(true);
            mParentDropDownArrow.startAnimation(rotateAnimation);

        }
    }
}
