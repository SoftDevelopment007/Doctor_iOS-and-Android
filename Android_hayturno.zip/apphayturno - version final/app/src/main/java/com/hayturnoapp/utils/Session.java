package com.hayturnoapp.utils;

import  java.util.HashMap;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.hayturnoapp.LoginActivity;


public class Session {

    private SharedPreferences pref;
    private Editor editor;
    private Context contexto;
    private int PRIVATE_MODE = 0;
    private String directorioFoto;

    // Sharedpref file name
    private static final String PREF_NAME = "HayTurnoPref";

    // All Shared Preferences Keys
    private static final String IS_LOGIN = "IsLoggedIn";

    // User name //nombre y apellido
    public static final String KEY_NAME = "name";

    // Email address (make variable public to access from outside)
    public static final String KEY_EMAIL = "email";

    public static final String KEY_ID = "id";

    public static final String KEY_PASSWORD = "psswd";

    public static final String KEY_LOGINPOLICY = "loginPolicy";

    public static final String KEY_DIRECTORIO_FOTO = "directorio";

    public static final String KEY_PROCESO_TERMINADO = "HayTurnoProceso";


    public Session(Context context)
    {
        this.contexto = context;
        pref = contexto.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void crearLoginSession(String name, String email, Integer idUsuario, String loginPolicy,String psswd)
    {
        // Storing login value as TRUE
        editor.putBoolean(IS_LOGIN, true);

        // Storing name in pref
        editor.putString(KEY_NAME, name);

        // Storing email in pref
        editor.putString(KEY_EMAIL, email);

        //Almacenamos el id
        editor.putString(KEY_ID, idUsuario.toString());

        editor.putString(KEY_PASSWORD , psswd);

        editor.putString(KEY_LOGINPOLICY , loginPolicy);

        // commit changes
        editor.apply();
    }

    public HashMap<String, String> getDetalleUsuario()
    {
        HashMap<String, String> user = new HashMap<String, String>();

        user.put(KEY_NAME, pref.getString(KEY_NAME, null));

        user.put(KEY_EMAIL, pref.getString(KEY_EMAIL, null));

        user.put(KEY_ID,    pref.getString(KEY_ID, null));

        user.put(KEY_PASSWORD ,  pref.getString(KEY_PASSWORD, null));

        user.put(KEY_LOGINPOLICY ,  pref.getString(KEY_LOGINPOLICY, null)  );

        // return user
        return user;

    }

    public void checkLogin()
    {
        // Check login status
        if(!this.isLoggedIn()){
            // user is not logged in redirect him to Login Activity
            Intent i = new Intent( contexto, LoginActivity.class);
            // Closing all the Activities
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            // Add new Flag to start new Activity
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |Intent.FLAG_ACTIVITY_CLEAR_TASK );

            // Staring Login Activity
            contexto.startActivity(i);
        }

    }

    public void logoutUser()
    {
        editor.clear();
        editor.commit();

        // After logout redirect user to Loing Activity
        Intent i = new Intent(contexto, LoginActivity.class);
        // Closing all the Activities
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        // Add new Flag to start new Activity
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |Intent.FLAG_ACTIVITY_CLEAR_TASK );

        // Staring Login Activity
        contexto.startActivity(i);
    }

    public void setNombre (String nombre)
    {
        editor.putString(KEY_NAME, nombre);
        editor.commit();
    }

    public void setEmail(String email)
    {
        editor.putString(KEY_EMAIL, email);
        editor.commit();
    }


    public void setDirectorioFotoUsuario(String directorio)
    {
        editor.putString(KEY_DIRECTORIO_FOTO, directorio);
        editor.commit();
    }

    public String getDirectorioFotoUsuario()
    {
        return  pref.getString(KEY_DIRECTORIO_FOTO,null);
    }

    public void setProcesoTerminado()
    {
        editor.putString(KEY_PROCESO_TERMINADO, "1" );
        editor.commit();
    }

    public String getProcesoTerminado() {
        return pref.getString(KEY_PROCESO_TERMINADO, null);
    }

    public boolean isLoggedIn()
    {
        return pref.getBoolean(IS_LOGIN, false);
    }

}
