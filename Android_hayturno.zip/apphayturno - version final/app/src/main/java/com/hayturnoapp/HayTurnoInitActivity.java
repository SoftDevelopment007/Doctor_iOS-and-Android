package com.hayturnoapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hayturnoapp.models.Autorizacion;
import com.hayturnoapp.utils.ExceptionHandler;
import com.hayturnoapp.utils.ProcesoTermindo;
import com.hayturnoapp.utils.RestClient;
import com.hayturnoapp.utils.Session;
import com.hayturnoapp.utils.Utils;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.HashMap;
import java.util.Map;

public class HayTurnoInitActivity extends AppCompatActivity {

    Context mContext = HayTurnoInitActivity.this;
    SharedPreferences appPreferences;
    boolean isAppInstalled = false;

    private TextView txb1;
    private TextView txb2;
    private TextView txh;
    private Button txbb;
    private Session sesion;
    private  ProgressDialog progreso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // manejador de error
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));

        setContentView(R.layout.activity_hay_turno_init);
        appPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        isAppInstalled = appPreferences.getBoolean("isAppInstalled", false);
        setIconHomeScreen(isAppInstalled, appPreferences);

        Typeface custom_font = Typeface.createFromAsset(getAssets(), "fonts/AmpleSoft Medium.otf");
        txb1 = (TextView) findViewById(R.id.bienvenidosTextView01);
        txb1.setTypeface(custom_font);

        custom_font = Typeface.createFromAsset(getAssets(), "fonts/AmpleSoft Bold.otf");
        txb2 = (TextView) findViewById(R.id.bienvenidosTextView02);
        txb2.setTypeface(custom_font);


        custom_font = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Regular.ttf");
        txh= (TextView) findViewById(R.id.headerTextView);
        txh.setTypeface(custom_font);

        custom_font = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Bold.ttf");
        txbb= (Button) findViewById(R.id.buttonComenzar);
        txbb.setTypeface(custom_font);

        progreso = new ProgressDialog(this, R.style.ThemePD2);
        progreso.setMessage("");
        progreso.setIndeterminate(false);
        progreso.setCancelable(false);
        progreso.setProgressStyle(android.R.style.Widget_ProgressBar_Small);

        sesion = new Session(this);
        ProcesoTermindo pt = new ProcesoTermindo(this);

        String proceso= pt.getProcesoTerminado();

        if( sesion.isLoggedIn())
        {
            // bajamos imagen de acuerdo a la data del uusario logeado.
            extraerFoto();
        }
        else if ( isAppInstalled  ) //SI ESTA INSTALADO, LO MANDAMOS A LA PANTALLA DE LOGIN
        {
            if(proceso!= null && !proceso.isEmpty() && proceso.equals("1")  )
            startLogin();
        }

    }

    //--------------------------------------- Utils ------------------------------------------------
    public void startLogin(View view) {
     //   Intent intent = new Intent(this, LoginRegistryActivity.class);
        Intent intent = new Intent(this, BusquedaTurnoActivity.class);
        startActivity(intent);
    }

    public void startHome() {
        Intent intent = new Intent(this, CalendariosTurnoActivity.class);
        startActivity(intent);
    }
    public void startLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }


    /*
    * Setea el icono de la app en la pantalla principal
    * */
    public void setIconHomeScreen(boolean isAppInstalled, SharedPreferences appPreferences) {

        if (isAppInstalled == false) {
            //shorcutIntent object
            Intent shortcutIntent = new Intent(getApplicationContext(),
                    HayTurnoInitActivity.class);

            shortcutIntent.setAction(Intent.ACTION_MAIN);
            //shortcutIntent is added with addIntent
            Intent addIntent = new Intent();
            addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
            addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, "Hay Turno");
            addIntent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
                    Intent.ShortcutIconResource.fromContext(getApplicationContext(),
                            R.mipmap.ic_launcher));

            addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
            // finally broadcast the new Intent
            getApplicationContext().sendBroadcast(addIntent);
        }

        // finally isAppInstalled should be true.
        SharedPreferences.Editor editor = appPreferences.edit();
        editor.putBoolean("isAppInstalled", true);
        editor.commit();

    }


    // funcion para descargar la imagen del usuario
    private void  extraerFoto()
    {
        progreso.show();
        Autorizacion auth = new Autorizacion();
        Gson g = new Gson();
        //Sacamos los datos del paciente
        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));


        Map<String, Object> objetoAuth = new HashMap<>();
        objetoAuth.put("patientID", auth.getPatientID());
        objetoAuth.put("loginPolicy", auth.getLoginPolicy());
        objetoAuth.put("eml", auth.getEml());
        objetoAuth.put("psswd", auth.getPsswd());


        JsonObject jsonobjAuth  = new JsonObject();
        jsonobjAuth.addProperty("patientID", auth.getPatientID());
        jsonobjAuth.addProperty("loginPolicy", auth.getLoginPolicy());
        jsonobjAuth.addProperty("eml", auth.getEml());
        jsonobjAuth.addProperty("psswd", auth.getPsswd());

        String toSend  = g.toJson(jsonobjAuth);
        JsonObject newObj = new JsonParser().parse(toSend).getAsJsonObject();

        JsonObject jsonobj = new JsonObject();
        jsonobj.add("authorization", newObj);
        jsonobj.addProperty("patientID", auth.getPatientID());


        System.out.println("datos usuario a enviar : " + jsonobj);

        Ion.with(this)
                .load("POST", RestClient.getAbsoluteUrlserver("/patient/pic")) //  .progressDialog(dlg)
                .setTimeout(60 * 60 * 1000)
                .setJsonObjectBody(jsonobj)
                .withBitmap().asBitmap()
                .setCallback(new FutureCallback<Bitmap>() {
                    @Override
                    public void onCompleted(Exception e, Bitmap Dfoto)
                    {
                        progreso.dismiss();

                        if(e != null)
                        {
                            Toast.makeText(HayTurnoInitActivity.this, "error de excepcion", Toast.LENGTH_LONG);
                            e.printStackTrace();
                            startHome();
                        }
                        else
                        {
                            // no tiene sentido pasar un proceso de guardado de cadena si no tiene foto....
                            // por lo que pasamos a revisar si hay foto que gaurdar
                            if (Dfoto != null)
                            {
                                // Aqui gaurdaremos la imagen  dentro del dispositivo
                                Utils u = new Utils();
                                String pathFoto = "";
                                //revisamos que no venga vacia la cadena
                                pathFoto =  u.saveToInternalStorage(Dfoto, getApplicationContext());
                                sesion.setDirectorioFotoUsuario(pathFoto);
                            }

                            startHome();
                        }
                    }
                });


    }

}
