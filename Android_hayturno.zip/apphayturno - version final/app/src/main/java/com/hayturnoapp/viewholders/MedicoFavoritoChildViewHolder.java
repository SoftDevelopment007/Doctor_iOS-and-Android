package com.hayturnoapp.viewholders;

import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.bignerdranch.expandablerecyclerview.ViewHolder.ChildViewHolder;

import com.hayturnoapp.R;
import com.hayturnoapp.models.MedicoFavoritoHijo;


public class MedicoFavoritoChildViewHolder extends ChildViewHolder {

    public TextView mTVEspecialidad;
    public TextView mTVHospital;
    public TextView mTVDireccion;
    public TextView mTVFechaTurno;
    public TextView mTVHorario;
    public Button mBtnCancelarCita;
    public ImageButton mBtnGenerarCita;


    public MedicoFavoritoChildViewHolder(View itemView)
    {
        super(itemView);
        mTVEspecialidad = (TextView) itemView.findViewById(R.id.TextViewMedFavChildEspecialidad);
        mTVHospital = (TextView) itemView.findViewById(R.id.TextViewMedFavChildHospital);
        mTVDireccion = (TextView) itemView.findViewById(R.id.TextViewMedFavChildDireccion);
        mTVFechaTurno = (TextView) itemView.findViewById(R.id.TextViewMedFavChildTurno);
        mTVHorario = (TextView) itemView.findViewById(R.id.TextViewMedFavChildHorario);
        mBtnCancelarCita = (Button) itemView.findViewById(R.id.buttonCancelarCitaMedFavorito);
        mBtnGenerarCita = (ImageButton )  itemView.findViewById(R.id.buttonGeneraraCitaNueva);
    }


}
