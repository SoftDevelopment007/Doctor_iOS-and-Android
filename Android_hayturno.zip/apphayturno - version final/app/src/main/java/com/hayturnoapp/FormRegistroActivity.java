package com.hayturnoapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hayturnoapp.utils.DatosUsuarios;
import com.hayturnoapp.utils.ExceptionHandler;
import com.tmxlr.lib.driodvalidatorlight.Form;
import com.tmxlr.lib.driodvalidatorlight.helper.Range;
import com.tmxlr.lib.driodvalidatorlight.helper.RegexTemplate;
import com.tmxlr.lib.driodvalidatorlight.validator.RegExpValidator;

import org.w3c.dom.Text;

public class FormRegistroActivity extends AppCompatActivity {

    private static final String PASSWORD_PATTERN =  "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,20})";
    private Pattern patronPassword;

     @Override
    protected void onCreate(Bundle savedInstanceState) {
        DatosUsuarios duvar = DatosUsuarios.getInstance();

        super.onCreate(savedInstanceState);
         // manejador de error
         Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setContentView(R.layout.activity_form_registro);
        setupToolBar();

         patronPassword = Pattern.compile(PASSWORD_PATTERN);

    }

    //--------------------------------------- Utils ------------------------------------------------
    public void startPersonalData(View view)
    {

        DatosUsuarios duvar = DatosUsuarios.getInstance();
        String nombre = "";
        String apellido= "";
        String email = "";
        String contraseña = "";
        String contraseñaRepetida = "";
        Form form = new Form(this);


        EditText tvnombreUsuario      = (EditText) findViewById(R.id.editTextNombre);
        EditText tvapellidoUsuario    = (EditText) findViewById(R.id.editTextApellido);
        EditText tvnombreEmail        = (EditText) findViewById(R.id.editTextEmail);
        EditText tvcontraseña         = (EditText) findViewById(R.id.editTextPassword);
        EditText tvcontraseñarepetida = (EditText) findViewById(R.id.editTextRePassword);


        nombre = tvnombreUsuario.getText().toString();
        apellido = tvapellidoUsuario.getText().toString();
        email = tvnombreEmail.getText().toString();
        contraseña = tvcontraseña.getText().toString();
        contraseñaRepetida = tvcontraseñarepetida.getText().toString();

        //Validamos

   //     Pattern patronLetras = Pattern.compile("/[^0-9\\.\\,\\\"\\?\\!\\;\\:\\#\\$\\%\\&\\(\\)\\*\\+\\-\\/\\<\\>\\=\\@\\[\\]\\\\\\^\\_\\{\\}\\|\\~]+/");

        String patronPassiguales       = "\\b"+contraseñaRepetida+"\\b";

        Pattern passIguales = Pattern.compile(patronPassiguales);

        form.check(tvnombreUsuario, RegexTemplate.NOT_EMPTY_PATTERN, "El nombre no debe ser vacio");

        form.check(tvapellidoUsuario, RegexTemplate.NOT_EMPTY_PATTERN, "El apellido no debe ser vacio");

        form.check(tvnombreEmail,RegexTemplate.NOT_EMPTY_PATTERN, "El email no debe estar vacio" );
        form.check(tvnombreEmail,RegexTemplate.EMAIL_PATTERN, "Formato incorrecto, ejemplo de formato: Hay.Turno123@gmail.com" );

        form.check(tvcontraseña,RegexTemplate.NOT_EMPTY_PATTERN, "La contraseña no debe ir vacia" );
        form.check(tvcontraseña,patronPassword, "La contraseña debe tener entre 6 y 20 caracteres, una mayuscula , una minuscula y un numero" );
        form.check(tvcontraseña,passIguales, "No coinciden las contraseñas." );

        form.check(tvcontraseñarepetida,RegexTemplate.NOT_EMPTY_PATTERN, "La contraseña no debe ir vacia" );
        form.check(tvcontraseñarepetida,patronPassword, "La contraseña debe tener entre 6 y 20 caracteres, una mayuscula , una minuscula y un numero" );


        if(form.validate())
        {
            duvar.setNombres(nombre);
            duvar.setApellidos(apellido);
            duvar.setEmail(email);
            duvar.setContraseña(contraseña);

            Intent intent = new Intent(this, DatosPersonalesActivity.class);
            startActivity(intent);

        }
        else
        {
            Toast.makeText(this, "Revise la informacion nuevamente", Toast.LENGTH_LONG).show();
        }



    }

    private void setupToolBar() {
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbarFormRegistro);
        setSupportActionBar(myToolbar);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        /*switch (item.getItemId()) {
            case R.id.action_settings:
                // User chose the "Settings" item, show the app settings UI...
                return true;

            *//*case R.id.:
                // User chose the "Favorite" action, mark the current item
                // as a favorite...
                return true;
*//*
            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }*/
        return false;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.action_bar_overflow, menu);
        return true;
    }
}
