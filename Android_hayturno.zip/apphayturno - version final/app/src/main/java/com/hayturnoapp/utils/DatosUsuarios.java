package com.hayturnoapp.utils;

import android.app.Application;

import com.facebook.AccessToken;
import com.facebook.Profile;


public class DatosUsuarios extends Application {

    private String nombres;
    private String apellidos;
    private String celular;
    private String dni;
    private String fechaNacimiento;
    private String genero; // 1 es masculino
    private int patientID;
    private String loginPolicy;
    private String email;
    private Integer sociaSecurityType;
    private long sociaSecurityNumber;

    // datos de FB
    private AccessToken accessTokenFB;
    private Profile profile;

    //datos del Gmail
    private String IdTokenGmail;

    private boolean registroporFB;
    private boolean registroporGmail;
    private boolean registroporApp;

    private boolean registroexitoso;


    private String contraseña;



    private static DatosUsuarios ourInstance = new DatosUsuarios();

    public static DatosUsuarios getInstance() {
        return ourInstance;
    }

    private DatosUsuarios() {
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLoginPolicy() {
        return loginPolicy;
    }

    public void setLoginPolicy(String loginPolicy) {
        this.loginPolicy = loginPolicy;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public boolean isRegistroexitoso() {
        return registroexitoso;
    }

    public void setRegistroexitoso(boolean registroexitoso) {
        this.registroexitoso = registroexitoso;
    }

    public AccessToken getAccessTokenFB() {
        return accessTokenFB;
    }

    public void setAccessTokenFB(AccessToken accessTokenFB) {
        this.accessTokenFB = accessTokenFB;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }

    public boolean isRegistroporFB() {
        return registroporFB;
    }

    public void setRegistroporFB(boolean registroporFB) {
        this.registroporFB = registroporFB;
    }

    public boolean isRegistroporGmail() {
        return registroporGmail;
    }

    public void setRegistroporGmail(boolean registroporGmail) {
        this.registroporGmail = registroporGmail;
    }

    public boolean isRegistroporApp() {
        return registroporApp;
    }

    public void setRegistroporApp(boolean registroporApp) {
        this.registroporApp = registroporApp;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public Integer getSociaSecurityType() {
        return sociaSecurityType;
    }

    public void setSociaSecurityType(Integer sociaSecurityType) {
        this.sociaSecurityType = sociaSecurityType;
    }

    public long getSociaSecurityNumber() {
        return sociaSecurityNumber;
    }

    public void setSociaSecurityNumber( long sociaSecurityNumber) {
        this.sociaSecurityNumber = sociaSecurityNumber;
    }

    public String getIdTokenGmail() {
        return IdTokenGmail;
    }

    public void setIdTokenGmail(String idTokenGmail) {
        IdTokenGmail = idTokenGmail;
    }
}
