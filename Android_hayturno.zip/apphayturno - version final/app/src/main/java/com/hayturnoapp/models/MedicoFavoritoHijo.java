package com.hayturnoapp.models;

import android.content.Context;
import android.widget.TextView;

public class MedicoFavoritoHijo {

    public TextView TVEspecialidad;  //
    public TextView TVHospital;      //
    public TextView TVDireccion;     //
    public TextView TVFechaTurno;
    public TextView TVHorario;
    private Integer IDProximaCita;

    // poner aqui los id necesarios para generar la cita

    private Integer IDprovincia;
    private Integer IDciudad;
    private Integer IDespecialidad;
    private Integer IDhospital;
    private Integer IDdoctor;

    //datos complementarios
    private String nombreProfesional;
    private String telefonoHospital;
    private String nombreProvincia;
    private String nombreCiudad;

    private Context contexto;

    public MedicoFavoritoHijo(TextView TVEspecialidad, TextView TVHospital,   TextView TVDireccion,
                              TextView TVFechaTurno,   TextView TVHorario,     Integer IDCita, Context contexto)
     {
        this.TVEspecialidad = TVEspecialidad;
        this.TVHospital = TVHospital;
        this.TVDireccion = TVDireccion;
        this.TVFechaTurno = TVFechaTurno;
        this.TVHorario = TVHorario;
        this.IDProximaCita = IDCita;
        this.contexto = contexto;
    }

    public TextView getTVEspecialidad() {
        return TVEspecialidad;
    }

    public void setTVEspecialidad(TextView TVEspecialidad) {
        this.TVEspecialidad = TVEspecialidad;
    }

    public TextView getTVHospital() {
        return TVHospital;
    }

    public void setTVHospital(TextView TVHospital) {
        this.TVHospital = TVHospital;
    }

    public TextView getTVFechaTurno() {
        return TVFechaTurno;
    }

    public void setTVFechaTurno(TextView TVFechaTurno) {
        this.TVFechaTurno = TVFechaTurno;
    }

    public TextView getTVDireccion() {
        return TVDireccion;
    }

    public void setTVDireccion(TextView TVDireccion) {
        this.TVDireccion = TVDireccion;
    }

    public TextView getTVHorario() {
        return TVHorario;
    }

    public void setTVHorario(TextView TVHorario) {
        this.TVHorario = TVHorario;
    }

    public Integer getIDProximaCita() {
        return IDProximaCita;
    }

    public void setIDProximaCita(Integer IDProximaCita) {
        this.IDProximaCita = IDProximaCita;
    }

    public Integer getIDprovincia() {
        return IDprovincia;
    }

    public void setIDprovincia(Integer IDprovincia) {
        this.IDprovincia = IDprovincia;
    }

    public Integer getIDciudad() {
        return IDciudad;
    }

    public void setIDciudad(Integer IDciudad) {
        this.IDciudad = IDciudad;
    }

    public Integer getIDespecialidad() {
        return IDespecialidad;
    }

    public void setIDespecialidad(Integer IDespecialidad) {
        this.IDespecialidad = IDespecialidad;
    }

    public Integer getIDhospital() {
        return IDhospital;
    }

    public void setIDhospital(Integer IDhospital) {
        this.IDhospital = IDhospital;
    }

    public Integer getIDdoctor() {
        return IDdoctor;
    }

    public void setIDdoctor(Integer IDdoctor) {
        this.IDdoctor = IDdoctor;
    }

    public String getNombreProfesional() {
        return nombreProfesional;
    }

    public void setNombreProfesional(String nombreProfesional) {
        this.nombreProfesional = nombreProfesional;
    }

    public String getTelefonoHospital() {
        return telefonoHospital;
    }

    public void setTelefonoHospital(String telefonoHospital) {
        this.telefonoHospital = telefonoHospital;
    }

    public String getNombreProvincia() {
        return nombreProvincia;
    }

    public void setNombreProvincia(String nombreProvincia) {
        this.nombreProvincia = nombreProvincia;
    }

    public String getNombreCiudad() {
        return nombreCiudad;
    }

    public void setNombreCiudad(String nombreCiudad) {
        this.nombreCiudad = nombreCiudad;
    }

    public Context getContexto() {
        return contexto;
    }
}
