package com.hayturnoapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by Nicolas on 09/11/2016.
 */

public class ActivityError extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_error);

        TextView tverror = (TextView) findViewById(R.id.errorTextView);
       String error =  getIntent().getStringExtra("error_app");
        tverror.setText(error);
    }

}
