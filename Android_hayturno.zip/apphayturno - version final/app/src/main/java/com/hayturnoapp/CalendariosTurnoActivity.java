package com.hayturnoapp;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.sundeepk.compactcalendarview.CompactCalendarView;
import com.github.sundeepk.compactcalendarview.domain.Event;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hayturnoapp.models.Appointment;
import com.hayturnoapp.models.Autorizacion;
import com.hayturnoapp.models.JsResId;
import com.hayturnoapp.utils.DatosCitas;
import com.hayturnoapp.utils.DatosUsuarios;
import com.hayturnoapp.utils.RestClient;
import com.hayturnoapp.utils.Session;
import com.hayturnoapp.utils.Utils;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import cz.msebera.android.httpclient.Header;


public class CalendariosTurnoActivity extends AppCompatActivity {

    private CompactCalendarView calendario;
    private SimpleDateFormat dateFormatForDisplaying = new SimpleDateFormat("dd-M-yyyy hh:mm:ss a", Locale.getDefault());
    private SimpleDateFormat dateFormatForMonth = new SimpleDateFormat("MMMM", Locale.getDefault());
    private SimpleDateFormat dateFormatForYear = new SimpleDateFormat("yyyy", Locale.getDefault());
    private TextView TxViewMes;
    private TextView TxViewAño;
    private Calendar currentCalender = Calendar.getInstance(Locale.getDefault());
    private TableLayout tablacitas;
    private TextView noHayTurno;
    private Button BtnCancelarCita;
    private Event eventoDiaElegido;
    private Session sesion;
    private Drawer resultDrawer;
    private AccountHeader headerResult;
    private String[] activityTitles;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario_turnos);

        activityTitles = getResources().getStringArray(R.array.nav_item_activity_titles);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_menu);

        tablacitas = (TableLayout) findViewById(R.id.TablaDetalleCita);
        noHayTurno = (TextView) findViewById(R.id.TextViewSinData);
        BtnCancelarCita = (Button) findViewById(R.id.buttonCancelarCita);
        tablacitas.setVisibility(View.GONE);
        noHayTurno.setVisibility(View.GONE);
        BtnCancelarCita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog();
            }
        });

        sesion = new Session(this);

        String directorioFotoUsuario = "";


        sesion.checkLogin();

        if (sesion.isLoggedIn()) {
            Utils u = new Utils();
            HashMap<String, String> user = sesion.getDetalleUsuario();
            final ProfileDrawerItem datoUsuario = new ProfileDrawerItem();
            datoUsuario.withName(user.get(sesion.KEY_NAME));


            directorioFotoUsuario = sesion.getDirectorioFotoUsuario();

            if (directorioFotoUsuario == null)
                directorioFotoUsuario = "";


            if (!directorioFotoUsuario.isEmpty())
                datoUsuario.withIcon(u.loadImageFromStorage(directorioFotoUsuario));
            else
                datoUsuario.withIcon(getResources().getDrawable(R.drawable.foto_persona));

            headerResult = new AccountHeaderBuilder()
                    .withActivity(this)
                    .withHeaderBackground(R.color.colorBackBlueLight)
                    .addProfiles(datoUsuario)
                    .withSelectionListEnabledForSingleProfile(false)
                    .build();


            //agregamos el menu de navegacion
            resultDrawer = new DrawerBuilder()
                    .withActivity(this)
                    .withToolbar(toolbar)
                    .withAccountHeader(headerResult)
                    .addDrawerItems(
                            new PrimaryDrawerItem().withName(activityTitles[0]).withIcon(R.drawable.icon_search).withIdentifier(1),
                            new PrimaryDrawerItem().withName(activityTitles[1]).withIcon(R.drawable.icon_agenda).withIdentifier(2),
                            new PrimaryDrawerItem().withName(activityTitles[2]).withIcon(R.drawable.icon_mis_medicos).withIdentifier(3),
                            new PrimaryDrawerItem().withName(activityTitles[3]).withIcon(R.drawable.icon_datos_personales).withIdentifier(4),
                            new PrimaryDrawerItem().withName(activityTitles[4]).withIcon(R.drawable.icon_close_session).withIdentifier(5)
                    )
                    .withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
                        @Override
                        public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                            //revisamos si drawerItem esta seteado
                            //drawerItem puede ser nulo por diferentes razones
                            //--> click en encaebzado
                            //--> click en el pie
                            // esos items no contiene drawerItem
                            if (drawerItem != null) {
                                Intent intent = null;
                                int identificador = (int) drawerItem.getIdentifier();
                                switch (identificador) {
                                    case 1:
                                        intent = new Intent(CalendariosTurnoActivity.this, BusquedaTurnoActivity.class);
                                        break;
                                    case 2:

                                        break;
                                    case 3:
                                        intent = new Intent(CalendariosTurnoActivity.this, MisMedicosActivity.class);
                                        break;
                                    case 4:
                                        intent = new Intent(CalendariosTurnoActivity.this, DatosPersonalesModificacionActivity.class);
                                        break;
                                    case 5:
                                        signOut();
                                        break;

                                }

                                if (intent != null) {
                                    CalendariosTurnoActivity.this.startActivity(intent);
                                }
                            }
                            return false;
                        }
                    }) //fin del OnDrawerItemClickListener
                    .build();
        } // fin del seteo de la barra



        inicializarCalendar();

        //  System.out.println("directorio: " + directorioFotoUsuario);

    }

    private void showDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.confirmar_cancelar_turno);

        Button dialogButtonSi = (Button) dialog.findViewById(R.id.btnCancelarSi);
        Button dialogButtonNo = (Button) dialog.findViewById(R.id.btnCancelarNo);

        dialogButtonSi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    dialog.dismiss();
                    cancelCita();
                } catch (JSONException | UnsupportedEncodingException e) {
                    e.getStackTrace();
                }
            }
        });


        dialogButtonNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void cancelCita() throws JSONException, UnsupportedEncodingException {
        TextView txViewIDTurno = (TextView) findViewById(R.id.TextViewIDTurno);
        Integer IdCitaCancelar = Integer.valueOf(txViewIDTurno.getText().toString());

        System.out.println("se cancelo la cita >>>>>>>>" + txViewIDTurno.getText().toString());

        Autorizacion auth = new Autorizacion();

        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        //sacamos los datos del paciente de la sesion
        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));


        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID());
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if (auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if (auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());


        System.out.println("Objeto autorizacion>>>>>>" + objAuth.toString());

        JSONObject obj = new JSONObject();
        obj.put("authorization", objAuth);
        obj.put("appointmentID", IdCitaCancelar);
        obj.put("patientID", auth.getPatientID());


        System.out.println("Objeto a enviar>>>>>>" + obj.toString());

        RestClient.postJson(null, "/appointment/cancel", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                //  "STATUS": "SUCCESS",
                //   "MSG_": "El turno ha sido cancelado exitosamente"
                //Extraigo la respuesrta
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsResId jsSimple = gson.fromJson(respuesta, JsResId.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                if (jsSimple.getSTATUS().equals("SUCCESS")) {
                    calendario.removeEvent(eventoDiaElegido, true);
                    tablacitas.setVisibility(View.GONE);
                    noHayTurno.setVisibility(View.VISIBLE);
                } else {

                    Toast.makeText(getApplicationContext(), "Ocurrio un error, Intentelo más tarde", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsResId jsSimple = gson.fromJson(respuesta, JsResId.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                if (jsSimple.getSTATUS().equals("SUCCESS")) {
                    calendario.removeEvent(eventoDiaElegido, true);
                    tablacitas.setVisibility(View.GONE);
                    noHayTurno.setVisibility(View.VISIBLE);
                } else {

                    Toast.makeText(getApplicationContext(), "Ocurrio un error, Intentelo más tarde", Toast.LENGTH_LONG).show();
                }


            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);
                Toast.makeText(getApplicationContext(), "Ocurrio un error cancelando la cita, Intentelo más tarde", Toast.LENGTH_LONG).show();
            }
        });

    }


    public void inicializarCalendar() {
        calendario = (CompactCalendarView) findViewById(R.id.compactcalendar_view);
        TxViewMes = (TextView) findViewById(R.id.textViewMesCalendario);
        TxViewAño = (TextView) findViewById(R.id.textViewAñoCalendario);

        TxViewMes.setText(dateFormatForMonth.format(calendario.getFirstDayOfCurrentMonth()).toUpperCase());
        TxViewAño.setText(dateFormatForYear.format(calendario.getFirstDayOfCurrentMonth()));


        //seteamos el mes dependiendo del donde se deslize
        calendario.setListener(new CompactCalendarView.CompactCalendarViewListener() {

            @Override
            public void onDayClick(Date dateClicked) {
                List<Event> bookingsFromMap = calendario.getEvents(dateClicked);


                Log.d("Calendario", "inside onclick " + dateFormatForDisplaying.format(dateClicked));
                if (bookingsFromMap != null) {
                    Log.d("Calendario", bookingsFromMap.toString());

                    for (Event booking : bookingsFromMap) {
                        Log.d("CalendarioMutable", booking.getData().toString());
                        setearEventos(booking.getData().toString());
                        eventoDiaElegido = booking;
                    }
                }

                //Actualizamos visibilidad de la tabla
                if (bookingsFromMap.toString().equals("[]")) {
                    tablacitas.setVisibility(View.GONE);
                    noHayTurno.setVisibility(View.VISIBLE);
                } else {
                    tablacitas.setVisibility(View.VISIBLE);
                    noHayTurno.setVisibility(View.GONE);
                }


            }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {
                TxViewMes.setText(dateFormatForMonth.format(firstDayOfNewMonth).toUpperCase());
                TxViewAño.setText(dateFormatForYear.format(firstDayOfNewMonth));
            }
        });

        try {
            loadEvents();
        } catch (JSONException | UnsupportedEncodingException e) {
            e.getStackTrace();
        }

    }


    /*
    *
    * Inicializa los eventos(citas en este caso) que se mostraran dentro del calendario
    * en este punto se llama los eventos registrados por el usuario
    * */
    private void loadEvents() throws JSONException, UnsupportedEncodingException {

        DatosUsuarios duvar = DatosUsuarios.getInstance();
        Autorizacion auth = new Autorizacion();
        Gson gson = new Gson();

        String autorizacion = "";

        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));
/*
        auth.setPatientID(1);
        auth.setLoginPolicy("USRPASSWD");
        auth.setEml("juanperez@gmail.com");
        auth.setPsswd("Prueba123");
*/
        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID());
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if (auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if (auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());


        JSONObject obj = new JSONObject();
        obj.put("authorization", objAuth);
        obj.put("patientID", auth.getPatientID());
        //    obj.put("patientID", 1);

        RestClient.postJson(null, "/appointment/all", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected JSONArray

                DatosCitas dcvar = DatosCitas.getInstance();
                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<Appointment>>() {
                }.getType();
                Collection<Appointment> enums = gson.fromJson(respuesta, collectionType);
                Appointment[] map = enums.toArray(new Appointment[enums.size()]);

                System.out.println("DEVOLVIO un Object Appointmentes>>>>>>>>>>>>>>" + respuesta);

/*
                // List<String> prov = new ArrayList<String>();
                List<ValorFiltros> prov = new ArrayList<ValorFiltros>();*/

                dcvar.setCitasUsuario(new ArrayList<String>());

                for (Appointment p : map) {
                    String evento = "";
                    evento = p.getFecha() + "|" + p.getHoraInicio();
                    evento += "|" + p.getSpecialty().getNombre();
                    evento += "|" + p.getHospital().getNombre();
                    evento += "|" + p.getHospital().getDireccion();
                    evento += "|" + p.getDoctor().getName() + " " + p.getDoctor().getLastName();
                    evento += "|" + p.getId();
                    dcvar.getCitasUsuario().add(evento);
                }
                agregarEventosCalendario();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                // Extraemos las provincias que devuelva el WS
                DatosCitas dcvar = DatosCitas.getInstance();
                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<Appointment>>() {
                }.getType();
                Collection<Appointment> enums = gson.fromJson(respuesta, collectionType);
                Appointment[] map = enums.toArray(new Appointment[enums.size()]);

                System.out.println("DEVOLVIO un Object Appointmentes>>>>>>>>>>>>>>" + respuesta);

                dcvar.setCitasUsuario(new ArrayList<String>());

                // primero: la hora segundo: especialidad   tercero: hospital   cuarto: direccion  quinto: profesional
                for (Appointment p : map) {
                    //     String evento = p.getFecha() + "|" + p.getHoraInicio();
                    String evento = p.getFecha() + "|" + p.obtenerHorarioInicioFormateado();
                    evento += "|" + p.getSpecialty().getNombre();
                    evento += "|" + p.getHospital().getNombre();
                    evento += "|" + p.getHospital().getDireccion();
                    evento += "|" + p.getDoctor().getName() + " " + p.getDoctor().getLastName();
                    evento += "|" + p.getId();
                    dcvar.getCitasUsuario().add(evento);
                }
                agregarEventosCalendario();

            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);

            }
        });

        //----------------------------------------------------------------------------------------

    }

    /*
    *  se utiliza para cargar los eventos extraidos del WS  al calendario de acuerdo al formato dl calendario
    * */
    private void agregarEventosCalendario() {
        DatosCitas dcvar = DatosCitas.getInstance();

        //evento = p.getFecha() + "|" + p.getHoraInicio();
        for (String cita : dcvar.getCitasUsuario()) {
            String[] mcita = cita.split("\\|");
            String[] mfecha = mcita[0].split("-");

            addEvents(Integer.valueOf(mfecha[0]), Integer.valueOf(mfecha[1]) - 1, Integer.valueOf(mfecha[2]), cita);
        }
    }

    private void addEvents(int day, int month, int year, String hora) {

        currentCalender.setTime(new Date());
        currentCalender.set(Calendar.DAY_OF_MONTH, 1);
        Date firstDayOfMonth = currentCalender.getTime();

        currentCalender.setTime(firstDayOfMonth);

        currentCalender.set(Calendar.MONTH, month);
        currentCalender.set(Calendar.ERA, GregorianCalendar.AD);
        currentCalender.set(Calendar.YEAR, year);
        currentCalender.add(Calendar.DATE, day - 1);

        setToMidnight(currentCalender);
        long timeInMillis = currentCalender.getTimeInMillis();

        List<Event> events = getEvents(timeInMillis, day - 1, hora);

        calendario.addEvents(events);
    }

    // primero: la hora segundo: especialidad   tercero: hospital   cuarto: direccion  quinto: profesional
    //String data tendracomo separador |

    private void setearEventos(String data) {
        TextView txViewEspecialidadHospital = (TextView) findViewById(R.id.TextViewCitaEspecilidadHospital);
        TextView txViewCitaDireccion = (TextView) findViewById(R.id.TextViewCitaDireccion);
        TextView txViewCitaHorario = (TextView) findViewById(R.id.TextViewCitaHorario);
        TextView txViewCitaProfesional = (TextView) findViewById(R.id.TextViewCitaProfesional);
        TextView txViewIDTurno = (TextView) findViewById(R.id.TextViewIDTurno);

        String[] mcita = data.split("\\|");

        String EspecilidadHospital = mcita[2] + " / " + mcita[3];

        txViewCitaHorario.setText(mcita[1]);
        txViewEspecialidadHospital.setText(EspecilidadHospital);
        txViewCitaDireccion.setText(mcita[4]);
        txViewCitaProfesional.setText(mcita[5]);
        txViewIDTurno.setText(mcita[6]);


    }


    private List<Event> getEvents(long timeInMillis, int day, String data) {
        // return Arrays.asList(new Event(Color.CYAN, timeInMillis, "Event at " + new Date(timeInMillis)    )    );
        return Arrays.asList(new Event(Color.CYAN, timeInMillis, data));
    }

    private void setToMidnight(Calendar calendar) {
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
    }


    private void signOut()
    {
        sesion.logoutUser();
    }


}






