package com.hayturnoapp.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Nicolas on 27/04/2017.
 */

public class ProcesoTermindo {

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private Context contexto;
    private int PRIVATE_MODE = 0;

    // Sharedpref file name
    private static final String PREF_NAME = "HayTurnoProc";

    // All Shared Preferences Keys
    private static final String HAS_ID= "IsFinished";

    public ProcesoTermindo(Context context)
    {
        this.contexto = context;
        pref = contexto.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void setProcesoTerminado()
    {
        editor.putString(HAS_ID, "1" );
        editor.commit();
    }

    public String getProcesoTerminado() {
        return pref.getString(HAS_ID, null);
    }

}
