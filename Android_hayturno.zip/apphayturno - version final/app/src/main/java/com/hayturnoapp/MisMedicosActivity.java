package com.hayturnoapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter;
import com.bignerdranch.expandablerecyclerview.Model.ParentListItem;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hayturnoapp.adapters.ExtendableRecyclerViewMedFav;
import com.hayturnoapp.models.Autorizacion;
import com.hayturnoapp.models.MedicoFavorito;
import com.hayturnoapp.models.MedicoFavoritoHijo;
import com.hayturnoapp.models.MedicoFavoritoJson;
import com.hayturnoapp.models.MisMedicosArrayList;
import com.hayturnoapp.utils.ExceptionHandler;
import com.hayturnoapp.utils.RestClient;
import com.hayturnoapp.utils.Session;
import com.hayturnoapp.utils.Utils;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import cz.msebera.android.httpclient.Header;

/**
 * Created by Nicolas on 17/11/2016.
 */

public class MisMedicosActivity extends AppCompatActivity {

    private String[] activityTitles;
    private Session sesion;
    private Drawer resultDrawer;
    private AccountHeader headerResult;
    private LinearLayout llsinmedico;

    private RecyclerView mRecyclerView;
    private List<ParentListItem> meds;
    private ProgressDialog progreso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medico_favorito);

        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));

        activityTitles = getResources().getStringArray(R.array.nav_item_activity_titles);
        llsinmedico = (LinearLayout) findViewById(R.id.layoutSinMedicos);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_menu);

        sesion = new Session(this);
        sesion.checkLogin();
        meds = new ArrayList<ParentListItem>();


        //inicializamos progress dialog
        progreso = new ProgressDialog(this, R.style.ThemePD);
        progreso.setMessage("");
        progreso.setIndeterminate(false);
        progreso.setCancelable(false);
        progreso.setProgressStyle(android.R.style.Widget_ProgressBar_Small);


        // seteamos side bar app
        if (sesion.isLoggedIn()) {
            HashMap<String, String> user = sesion.getDetalleUsuario();
            String directorioFotoUsuario = "";
            Utils u = new Utils();
            final ProfileDrawerItem datoUsuario = new ProfileDrawerItem();
            datoUsuario.withName(user.get(sesion.KEY_NAME));

            directorioFotoUsuario =  sesion.getDirectorioFotoUsuario();

            if( directorioFotoUsuario == null)
                directorioFotoUsuario = "";

            if( !directorioFotoUsuario.isEmpty() )
                datoUsuario.withIcon(u.loadImageFromStorage(directorioFotoUsuario));
            else
                datoUsuario.withIcon(getResources().getDrawable(R.drawable.foto_persona));

            headerResult = new AccountHeaderBuilder()
                    .withActivity(this)
                    .withHeaderBackground(R.color.colorBackBlueLight)
                    .addProfiles(datoUsuario)
                    .withSelectionListEnabledForSingleProfile(false)
                    .build();


            //agregamos el menu de navegacion
            resultDrawer = new DrawerBuilder()
                    .withActivity(this)
                    .withToolbar(toolbar)
                    .withAccountHeader(headerResult)
                    .addDrawerItems(
                            new PrimaryDrawerItem().withName(activityTitles[0]).withIcon(R.drawable.icon_search).withIdentifier(1),
                            new PrimaryDrawerItem().withName(activityTitles[1]).withIcon(R.drawable.icon_agenda).withIdentifier(2),
                            new PrimaryDrawerItem().withName(activityTitles[2]).withIcon(R.drawable.icon_mis_medicos).withIdentifier(3),
                            new PrimaryDrawerItem().withName(activityTitles[3]).withIcon(R.drawable.icon_datos_personales).withIdentifier(4),
                            new PrimaryDrawerItem().withName(activityTitles[4]).withIcon(R.drawable.icon_close_session).withIdentifier(5)
                    )
                    .withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
                        @Override
                        public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                            //revisamos si drawerItem esta seteado
                            //drawerItem puede ser nulo por diferentes razones
                            //--> click en encaebzado
                            //--> click en el pie
                            // esos items no contiene drawerItem
                            if (drawerItem != null) {
                                Intent intent = null;
                                int identificador = (int) drawerItem.getIdentifier();
                                switch (identificador) {
                                    case 1:
                                        intent = new Intent(MisMedicosActivity.this, BusquedaTurnoActivity.class);
                                        break;
                                    case 2:
                                        intent = new Intent(MisMedicosActivity.this, CalendariosTurnoActivity.class);
                                        break;
                                    case 3:
                                        break;
                                    case 4:
                                        intent = new Intent(MisMedicosActivity.this, DatosPersonalesModificacionActivity.class);
                                        break;
                                    case 5:
                                        signOut();
                                        break;

                                }

                                if (intent != null) {
                                    MisMedicosActivity.this.startActivity(intent);
                                }
                            }
                            return false;
                        }
                    }) //fin del OnDrawerItemClickListener
                    .build();
        } // fin del seteo del la side bar app

        //seteamos los medicos
        try {
            extraerMedicos(new Callback<List<ParentListItem>>() {
                @Override
                public void onResponse(List<ParentListItem> listadoMedicosFavoritosPaciente) {
                    progreso.show();
                    meds.addAll(listadoMedicosFavoritosPaciente);
                    System.out.println("OJO>>>>>Llego a llamar al callback");
                    System.out.println("NUMERO DE OBJETOS: " + String.valueOf(meds.size()));
                    inicializarRecyclerview();
                    progreso.dismiss();
                }
            });
        } catch (JSONException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }


    }


    public void inicializarRecyclerview() {
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerviewMedFav);
        ExtendableRecyclerViewMedFav adapter = new ExtendableRecyclerViewMedFav(this, meds);
        adapter.setExpandCollapseListener(new ExpandableRecyclerAdapter.ExpandCollapseListener() {
            @Override
            public void onListItemExpanded(int position) {

            }

            @Override
            public void onListItemCollapsed(int position) {

            }
        });
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    public void extraerMedicos(final Callback<List<ParentListItem>> callback) throws JSONException, UnsupportedEncodingException {

        Autorizacion auth = new Autorizacion();

        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));


        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID());
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if(auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());


        JSONObject obj = new JSONObject();
        obj.put("authorization", objAuth);
        obj.put("patientID", auth.getPatientID());


        RestClient.postJson(null, "/patient/favorite/all", obj, new JsonHttpResponseHandler() {

            List<ParentListItem> listadoMedicosFavoritos = new ArrayList<ParentListItem>();


            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                String respuesta = response.toString();
                Gson gson = new Gson();

                MisMedicosArrayList map = gson.fromJson(respuesta, MisMedicosArrayList.class);

                if (map.getListadoMedicos().isEmpty()) {   //aqui ponemos el texto visisble
                    llsinmedico.setVisibility(View.VISIBLE);

                } else {

                    for (MedicoFavoritoJson p : map.getListadoMedicos()) {
                        Integer IdCita = 0;
                        Integer IdProvinicia = 0;
                        Integer IdCiudad = 0;
                        Integer IdEspecialidad = 0;
                        Integer IdHospital = 0;
                        Integer IdDoctor = 0;
                        String telefono = "";
                        String nombreprofesional = "";
                        String nombreCiudad = "";
                        String nombreProvincia = "";

                        TextView tv1 = new TextView(getApplicationContext()); // especialidad
                        TextView tv2 = new TextView(getApplicationContext()); // nombrew Hospital
                        TextView tv3 = new TextView(getApplicationContext()); // direccion del hospital
                        TextView tv4 = new TextView(getApplicationContext()); // fecha de la siguiente cita
                        TextView tv5 = new TextView(getApplicationContext()); // horario de la cita

                        tv1.setText(p.getSpeciality().getNombre());
                        tv2.setText(p.getHospital().getNombre());
                        tv3.setText(p.getHospital().getDireccion());
                        tv4.setText(p.getNextAppointment().getFecha());
                        tv5.setText(p.getNextAppointment().getHoraInicio());
                        IdCita = p.getNextAppointment().getId();


                        IdProvinicia = p.getInformation().getProvinceID();
                        IdCiudad = p.getInformation().getLocationID();
                        IdEspecialidad = p.getSpeciality().getId();
                        IdHospital = p.getHospital().getId();
                        IdDoctor = p.getDoctorID();
                        nombreprofesional = p.getInformation().getNombre() + " " + p.getInformation().getApellido();
                        telefono = p.getHospital().getTelefono();

                        //Incializamos un objeto hijo que obtendra informacion del medico en cuestion
                        MedicoFavoritoHijo subdata = new MedicoFavoritoHijo(tv1, tv2, tv3, tv4, tv5, IdCita, MisMedicosActivity.this);
                        subdata.setIDprovincia(IdProvinicia);
                        subdata.setIDciudad(IdCiudad);
                        subdata.setIDespecialidad(IdEspecialidad);
                        subdata.setIDhospital(IdHospital);
                        subdata.setIDdoctor(IdDoctor);
                        subdata.setNombreProfesional(nombreprofesional);
                        subdata.setTelefonoHospital(telefono);


                        ArrayList<MedicoFavoritoHijo> hijomed = new ArrayList<MedicoFavoritoHijo>();
                        hijomed.add(subdata);

                        //luego metemos los datos dentro del parent object para asociarlo
                        MedicoFavorito md = new MedicoFavorito(hijomed,nombreprofesional);

                        //...  y para terminar, lo agregamos al listado de objetos
                        listadoMedicosFavoritos.add(md);

                        //al final... limpiamos
                        tv1.setText("");
                        tv2.setText("");
                        tv3.setText("");
                        tv4.setText("");
                        tv5.setText("");
                    }

                }

                if (callback != null) {
                    callback.onResponse(listadoMedicosFavoritos);
                }

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<MedicoFavoritoJson>>() {
                }.getType();
                Collection<MedicoFavoritoJson> enums = gson.fromJson(respuesta, collectionType);
                MedicoFavoritoJson[] map = enums.toArray(new MedicoFavoritoJson[enums.size()]);

                if (map.length == 0)
                {   //aqui ponemos el texto visisble
                    llsinmedico.setVisibility(View.VISIBLE);

                } else
                {

                    for (MedicoFavoritoJson p : map)
                    {
                        Integer IdCita = 0;
                        Integer IdProvinicia = 0;
                        Integer IdCiudad = 0;
                        Integer IdEspecialidad = 0;
                        Integer IdHospital = 0;
                        Integer IdDoctor = 0;
                        String telefono = "";
                        String nombreprofesional = "";

                        TextView tv1 = new TextView(getApplicationContext()); // especialidad
                        TextView tv2 = new TextView(getApplicationContext()); // nombrew Hospital
                        TextView tv3 = new TextView(getApplicationContext()); // direccion del hospital
                        TextView tv4 = new TextView(getApplicationContext()); // fecha de la siguiente cita
                        TextView tv5 = new TextView(getApplicationContext()); // horario de la cita

                        tv1.setText(p.getSpeciality().getNombre());
                        tv2.setText(p.getHospital().getNombre());
                        tv3.setText(p.getHospital().getDireccion());
                        tv4.setText(p.getNextAppointment().getFecha());
                        tv5.setText(p.getNextAppointment().getHoraInicio());
                        IdCita = p.getNextAppointment().getId();

                        IdProvinicia = p.getInformation().getProvinceID();
                        IdCiudad = p.getInformation().getLocationID();
                        IdEspecialidad = p.getSpeciality().getId();
                        IdHospital = p.getHospital().getId();
                        IdDoctor = p.getDoctorID();
                        nombreprofesional = p.getInformation().getNombre() + " " + p.getInformation().getApellido();
                        telefono = p.getHospital().getTelefono();

                        //Incializamos un objeto hijo que obtendra informacion del medico en cuestion
                        MedicoFavoritoHijo subdata = new MedicoFavoritoHijo(tv1, tv2, tv3, tv4, tv5, IdCita,MisMedicosActivity.this);
                        subdata.setIDprovincia(IdProvinicia);
                        subdata.setIDciudad(IdCiudad);
                        subdata.setIDespecialidad(IdEspecialidad);
                        subdata.setIDhospital(IdHospital);
                        subdata.setIDdoctor(IdDoctor);
                        subdata.setNombreProfesional(nombreprofesional);
                        subdata.setTelefonoHospital(telefono);

                        ArrayList<MedicoFavoritoHijo> hijomed = new ArrayList<MedicoFavoritoHijo>();
                        hijomed.add(subdata);

                        //luego metemos los datos dentro del parent object para asociarlo
                        MedicoFavorito md = new MedicoFavorito(hijomed, nombreprofesional);
                        //...  y para terminar, lo agregamos al listado de objetos
                        listadoMedicosFavoritos.add(md);

                    }
                }

                if (callback != null) {
                    callback.onResponse(listadoMedicosFavoritos);
                }


            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);
                Toast.makeText(getApplicationContext(), "Ocurrio un error de conexion", Toast.LENGTH_LONG).show();
            }
        });

    }

    // interface para hacer un callback al ws
    public interface Callback<T> {
        void onResponse(T t);
    }

    private void signOut()
    {
        sesion.logoutUser();
    }
}
