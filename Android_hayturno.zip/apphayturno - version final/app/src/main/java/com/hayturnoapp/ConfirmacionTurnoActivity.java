package com.hayturnoapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hayturnoapp.models.Autorizacion;
import com.hayturnoapp.models.JsonResSimple;
import com.hayturnoapp.models.MedicoFavoritoJson;
import com.hayturnoapp.models.MisMedicosArrayList;
import com.hayturnoapp.utils.DatosGlobales;
import com.hayturnoapp.utils.DatosUsuarios;
import com.hayturnoapp.utils.ExceptionHandler;
import com.hayturnoapp.utils.RestClient;
import com.hayturnoapp.utils.Session;
import com.hayturnoapp.utils.Utils;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import cz.msebera.android.httpclient.Header;

public class ConfirmacionTurnoActivity extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private Session sesion;
    private ImageButton Btncorazon;
    private ImageButton BtncorazonEliminar;

    private HashMap<String,Integer> listadoMedicosFav;

    private Drawer resultDrawer;
    private AccountHeader headerResult;
    private String[] activityTitles;
    private Integer IdfavoritoARemover;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // manejador de error
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setContentView(R.layout.activity_confirmacion_cita);


        activityTitles = getResources().getStringArray(R.array.nav_item_activity_titles);

        listadoMedicosFav =new HashMap<String,Integer>();

        DatosGlobales var = DatosGlobales.getInstance();

        sesion = new Session(this);

        IdfavoritoARemover = 0;

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);


        TextView TvCiudad = (TextView) findViewById(R.id.TextViewCiudadConfirmacion);
        TextView TvCentroMedico = (TextView) findViewById(R.id.TextViewCentroMedicoConfirmacion);
        TextView TvDireccion = (TextView) findViewById(R.id.TextViewDireccionCentroMedico);
        TextView TvTelefono = (TextView) findViewById(R.id.TextViewTelefonoCentroMedico);
        TextView TvEspecialidad = (TextView) findViewById(R.id.TextViewEspecilidadConfirmacion);
        TextView TvEspecialista = (TextView) findViewById(R.id.TextViewEspecilistaConfirmacion);
        TextView TvFechaTurno = (TextView) findViewById(R.id.TextViewFechaTurno);
        TextView TvHorarioInicio = (TextView) findViewById(R.id.TextViewHorarioTurno);
        Btncorazon = (ImageButton) findViewById(R.id.buttonAgregarMedico);
        BtncorazonEliminar = (ImageButton)  findViewById(R.id.buttonEliminarMedico);

        TvCiudad.setText(var.getNombreCiudad());
        TvEspecialidad.setText(var.getNombreEspecialidad());
        TvCentroMedico.setText(var.getNombreCentroMedico());
        TvEspecialista.setText(var.getNombreDoctor());
        TvTelefono.setText(var.getTelefonoCentroMedico());
        TvDireccion.setText(var.getDireccionCentroMedico());
        TvFechaTurno.setText(var.getFecha_turno());
        // TvHorarioInicio.setText(var.getHorario_Inicio());

        var.getHorario_Inicio();
        String[] hora = var.getHorario_Inicio().split("\\:");
        String horaConfirmacion = "";

        if (Integer.valueOf(hora[0]) < 13)
            horaConfirmacion = var.getHorario_Inicio() + " AM";
        else
            horaConfirmacion = var.getHorario_Inicio() + " PM";

        TvHorarioInicio.setText(horaConfirmacion);

        // REVISAMOS SI EL CLIENTE ESTA O NO LOGEADO, ademas revisamos si ya esta agregado o no el doctor
        if (!sesion.isLoggedIn())
        {
            Btncorazon.setVisibility(View.INVISIBLE);
            BtncorazonEliminar.setVisibility(View.INVISIBLE);
        }
        else
        {
            // extraemos los medicos favoritos  y los cargamos de nuestro lado
            try
            {
                extraerMedicos(new Callback< HashMap<String, Integer> >() {
                    @Override
                    public void onResponse( HashMap<String, Integer> listadoMF)
                    {
                        DatosGlobales var = DatosGlobales.getInstance();

                        for(Map.Entry<String, Integer> entry: listadoMF.entrySet() )
                        {
                            String  llave = entry.getKey();
                            Integer valor = entry.getValue();

                            listadoMedicosFav.put(llave, valor);
                        }

                        //revisamos si no viene vacio
                        if (listadoMedicosFav.isEmpty())
                        {
                            Btncorazon.setVisibility(View.VISIBLE);
                            BtncorazonEliminar.setVisibility(View.GONE);
                        }
                        else
                        {
                           String llaveDoctor = var.getIdProvinciaSelecta().toString()+"-"
                                    + var.getIdCiudadSelecta().toString()   +"-"
                                    + var.getIdEspecialidad().toString()  +"-"
                                    + var.getIdCentroMedico().toString()  +"-"
                                    + var.getIdDoctor().toString() ;


                            //si lo encuentra siginifca que contiene a ese doctor
                            if(listadoMedicosFav.containsKey(llaveDoctor))
                            {
                                Btncorazon.setVisibility(View.GONE);
                                BtncorazonEliminar.setVisibility(View.VISIBLE);
                                IdfavoritoARemover = listadoMedicosFav.get(llaveDoctor);
                            }
                            else
                            {
                                Btncorazon.setVisibility(View.VISIBLE);
                                BtncorazonEliminar.setVisibility(View.GONE);
                            }

                        }
                    }
                });
            }
            catch (UnsupportedEncodingException|JSONException e)
            {
                e.printStackTrace();
            }

        }// terminamos de determinar el favorito

        //seteamos lascciones correspondiente a cada doctor
        Btncorazon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    agregarMedicoFavorito();

                } catch (JSONException | UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

            }
        });

        BtncorazonEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    eliminarMedicoFavorito();

                } catch (JSONException | UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        });


        if (sesion.isLoggedIn())
        {
            toolbar.setNavigationIcon(R.drawable.ic_menu);
            HashMap<String, String> user = sesion.getDetalleUsuario();
            String directorioFotoUsuario = "";
            Utils u = new Utils();
            final ProfileDrawerItem datoUsuario = new ProfileDrawerItem();
            datoUsuario.withName(user.get(sesion.KEY_NAME));

            directorioFotoUsuario =  sesion.getDirectorioFotoUsuario();

            if( directorioFotoUsuario == null)
                directorioFotoUsuario = "";

            if( !directorioFotoUsuario.isEmpty() )
                datoUsuario.withIcon(u.loadImageFromStorage(directorioFotoUsuario));
            else
                datoUsuario.withIcon(getResources().getDrawable(R.drawable.foto_persona));

            headerResult = new AccountHeaderBuilder()
                    .withActivity(this)
                    .withHeaderBackground(R.color.colorBackBlueLight)
                    .addProfiles(datoUsuario)
                    .withSelectionListEnabledForSingleProfile(false)
                    .build();


            //agregamos el menu de navegacion
            resultDrawer = new DrawerBuilder()
                    .withActivity(this)
                    .withToolbar(toolbar)
                    .withAccountHeader(headerResult)
                    .addDrawerItems(
                            new PrimaryDrawerItem().withName( activityTitles[0]).withIcon(R.drawable.icon_search).withIdentifier(1),
                            new PrimaryDrawerItem().withName( activityTitles[1]).withIcon(R.drawable.icon_agenda).withIdentifier(2),
                            new PrimaryDrawerItem().withName( activityTitles[2]).withIcon(R.drawable.icon_mis_medicos).withIdentifier(3),
                            new PrimaryDrawerItem().withName( activityTitles[3]).withIcon(R.drawable.icon_datos_personales).withIdentifier(4),
                            new PrimaryDrawerItem().withName( activityTitles[4]).withIcon(R.drawable.icon_close_session).withIdentifier(5)
                    ).withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
                        @Override
                        public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                            //revisamos si drawerItem esta seteado
                            //drawerItem puede ser nulo por diferentes razones
                            //--> click en encaebzado
                            //--> click en el pie
                            // esos items no contiene drawerItem
                            if (drawerItem != null) {
                                Intent intent = null;
                                int identificador = (int) drawerItem.getIdentifier();
                                switch (identificador) {
                                    case 1:
                                        intent = new Intent(ConfirmacionTurnoActivity.this, BusquedaTurnoFinalActivity.class);
                                        break;
                                    case 2:
                                        intent = new Intent(ConfirmacionTurnoActivity.this, CalendariosTurnoActivity.class);
                                        break;
                                    case 3:
                                        intent = new Intent(ConfirmacionTurnoActivity.this, MisMedicosActivity.class);
                                        break;
                                    case 4:
                                        intent = new Intent(ConfirmacionTurnoActivity.this, DatosPersonalesModificacionActivity.class);
                                        break;
                                    case 5:
                                        signOut();
                                        break;

                                }

                                if (intent != null) {
                                    ConfirmacionTurnoActivity.this.startActivity(intent);
                                }
                            }
                            return false;
                        }
                    })
                    .build();
        }
    }

    //--------------------------------------- Utils ------------------------------------------------
    public void startPersonalData(View view) {
        Intent intent = new Intent(this, DatosPersonalesActivity.class);
        startActivity(intent);
    }

    //modificacion a startLogin para que tome encuenta si esta logeado el paciente
    public void startLogin(View view) {
        // si tenemos una sesion logeada.... intentamos registrar la cita
        if (sesion.isLoggedIn()) {
            try {
                registrarCita();
            } catch (JSONException | UnsupportedEncodingException e) {
                e.getStackTrace();
            }
        } else //si no, lo mandamos a que se registre
        {
            Intent intent = new Intent(this, LoginRegistryActivity.class);
            startActivity(intent);
        }

    }

/*
    private void setupToolBar() {
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbarConfirmacion);
        setSupportActionBar(myToolbar);

    }*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
            case R.id.action_settings:
                return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void agregarMedicoFavorito() throws JSONException, UnsupportedEncodingException
    {
        DatosGlobales dgvar = DatosGlobales.getInstance();
        DatosUsuarios duvar = DatosUsuarios.getInstance();
        Autorizacion auth = new Autorizacion();
        Gson gson = new Gson();


        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));

        String autorizacion = "";
        //---------------------------------

        autorizacion = gson.toJson(auth);

        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID());
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if(auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());


        System.out.println("JSON interno de datos::::::::" + autorizacion);

        JSONObject obj = new JSONObject();
        //    obj.put("doctorID", DGvar.getIdDoctor());
        obj.put("authorization", objAuth);
        obj.put("patientID", auth.getPatientID());
        obj.put("doctorID", dgvar.getIdDoctor());
        obj.put("hospitalID", dgvar.getIdCentroMedico());

        System.out.println("JSON ENVIADO de datos::::::::" + obj.toString());
        RestClient.postJson(null, "/patient/favorite/add", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsonResSimple jsSimple = gson.fromJson(respuesta, JsonResSimple.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                if (jsSimple.getSTATUS().equals("SUCCESS")) {
                    Btncorazon.setVisibility(View.GONE);
                    BtncorazonEliminar.setVisibility(View.VISIBLE);
                    Toast.makeText(getApplicationContext(), "Doctor agregado con exito", Toast.LENGTH_LONG).show();

                } else {

                    Toast.makeText(getApplicationContext(), "No se pudo agregar al medico, Intentelo más tarde", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                DatosUsuarios duvar = DatosUsuarios.getInstance();
                String respString = responseString;
                Toast.makeText(getApplicationContext(), "Ocurrio un error al agregar al medico, Intentelo más tarde", Toast.LENGTH_LONG).show();
                duvar.setRegistroexitoso(false);
            }
        });


    }

    private void eliminarMedicoFavorito() throws JSONException, UnsupportedEncodingException
    {
        DatosGlobales dgvar = DatosGlobales.getInstance();
        DatosUsuarios duvar = DatosUsuarios.getInstance();
        Autorizacion auth = new Autorizacion();
        Gson gson = new Gson();


        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));

        String autorizacion = "";
        //---------------------------------

        autorizacion = gson.toJson(auth);

        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID());
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if(auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());

        System.out.println("JSON interno de datos::::::::" + autorizacion);

        JSONObject obj = new JSONObject();
        //    obj.put("doctorID", DGvar.getIdDoctor());
        obj.put("authorization", objAuth);
        obj.put("favoriteID", IdfavoritoARemover);
        obj.put("patientID",auth.getPatientID() );


        System.out.println("JSON ENVIADO de datos::::::::" + obj.toString());
        RestClient.postJson(null, "/patient/favorite/remove", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsonResSimple jsSimple = gson.fromJson(respuesta, JsonResSimple.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                if (jsSimple.getSTATUS().equals("SUCCESS")) {
                    Btncorazon.setVisibility(View.VISIBLE);
                    BtncorazonEliminar.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(), "Doctor eliminado de favorito", Toast.LENGTH_LONG).show();

                } else {

                    Toast.makeText(getApplicationContext(), "No se pudo eliminar al medico, Intentelo más tarde", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                DatosUsuarios duvar = DatosUsuarios.getInstance();
                String respString = responseString;
                Toast.makeText(getApplicationContext(), "Ocurrio un error al eliminar al medico, Intentelo más tarde", Toast.LENGTH_LONG).show();
                duvar.setRegistroexitoso(false);
            }
        });


    }


    public void extraerMedicos(final Callback< HashMap<String, Integer> >  callback) throws JSONException, UnsupportedEncodingException {

        Autorizacion auth = new Autorizacion();

        HashMap<String, String> usuario = sesion.getDetalleUsuario();


        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));


        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID());
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if(auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());


        JSONObject obj = new JSONObject();
        obj.put("authorization", objAuth);
        obj.put("patientID", auth.getPatientID());

        System.out.println("Objeto enviado:::::::::: " + obj.toString());

        RestClient.postJson(null, "/patient/favorite/all", obj, new JsonHttpResponseHandler() {

         //   ArrayList<String> doctores = new ArrayList<String>();

            HashMap<String,Integer> doctores = new HashMap<String, Integer>();

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                String respuesta = response.toString();
                Gson gson = new Gson();

                MisMedicosArrayList map = gson.fromJson(respuesta, MisMedicosArrayList.class);

                    for (MedicoFavoritoJson p : map.getListadoMedicos())
                    {
                        Integer IdProvinicia = 0;
                        Integer IdCiudad = 0;
                        Integer IdEspecialidad = 0;
                        Integer IdHospital = 0;
                        Integer IdDoctor = 0;

                        IdProvinicia = p.getInformation().getProvinceID();
                        IdCiudad = p.getInformation().getLocationID();
                        IdEspecialidad = p.getSpeciality().getId();
                        IdHospital = p.getHospital().getId();
                        IdDoctor = p.getDoctorID();

                        String llaveDoctor =   IdProvinicia.toString()+"-"
                                             + IdCiudad.toString()+"-"
                                             + IdEspecialidad.toString()+"-"
                                             + IdHospital.toString()+"-"
                                             + IdDoctor.toString();

                        doctores.put(llaveDoctor, p.getFavoriteID());

          //              doctores.add(llaveDoctor);

                 }

                if (callback != null)
                {
                    callback.onResponse(doctores);
                }

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                String respuesta = response.toString();
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<MedicoFavoritoJson>>() {
                }.getType();
                Collection<MedicoFavoritoJson> enums = gson.fromJson(respuesta, collectionType);
                MedicoFavoritoJson[] map = enums.toArray(new MedicoFavoritoJson[enums.size()]);

                //     MisMedicosArrayList map = gson.fromJson(respuesta, MisMedicosArrayList.class);

                    for ( MedicoFavoritoJson p :map )
                    {
                        Integer IdProvinicia = 0;
                        Integer IdCiudad = 0;
                        Integer IdEspecialidad = 0;
                        Integer IdHospital = 0;
                        Integer IdDoctor = 0;

                        IdProvinicia = p.getInformation().getProvinceID();
                        IdCiudad = p.getInformation().getLocationID();
                        IdEspecialidad = p.getSpeciality().getId();
                        IdHospital = p.getHospital().getId();
                        IdDoctor = p.getDoctorID();

                         String llaveDoctor =   IdProvinicia.toString()+"-"
                            + IdCiudad.toString()+"-"
                            + IdEspecialidad.toString()+"-"
                            + IdHospital.toString()+"-"
                            + IdDoctor.toString();
                        doctores.put(llaveDoctor, p.getFavoriteID());
                //        doctores.add(llaveDoctor);
                    }


                if (callback != null)
                {
                    callback.onResponse(doctores);
                }

            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);
                Toast.makeText(getApplicationContext(), "Ocurrio un error de conexion", Toast.LENGTH_LONG).show();
            }
        });

    }

    // interface para hacer un callback al ws
    public interface Callback<T> {
        void onResponse(T t);
    }

    private void registrarCita() throws JSONException, UnsupportedEncodingException
    {
        DatosGlobales dgvar = DatosGlobales.getInstance();
        Autorizacion auth = new Autorizacion();
        Gson gson = new Gson();

       /*String autorizacion = "";
        auth.setPatientID(1);
        auth.setLoginPolicy("USRPASSWD");
        auth.setEml("juanperez@gmail.com");
        auth.setPsswd("Prueba123");*/

        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));

        String autorizacion = "";
        //---------------------------------

        autorizacion = gson.toJson(auth);

        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID());
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if(auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());


        System.out.println("TOKEN::::::::" +auth.getPsswd());
        System.out.println("JSON interno de datos::::::::" + autorizacion);

        JSONObject obj = new JSONObject();
        //    obj.put("doctorID", DGvar.getIdDoctor());
        obj.put("authorization", objAuth);
        obj.put("patientID", auth.getPatientID());
        obj.put("date", dgvar.getFecha_turno());
        obj.put("startTime", dgvar.getHorario_Inicio() + ":00");
        obj.put("endTime", dgvar.getHorario_Fin() + ":00");
        obj.put("hospitalID", dgvar.getIdCentroMedico());
        obj.put("doctorID", dgvar.getIdDoctor());

        System.out.println("JSON ENVIADO de datos::::::::" + obj.toString());
        RestClient.postJson(null, "/appointment/schedule", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                DatosUsuarios duvar = DatosUsuarios.getInstance();
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsonResSimple jsSimple = gson.fromJson(respuesta, JsonResSimple.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                System.out.println("Recibio mensaje de: " + jsSimple.getMSG_());
                if (jsSimple.getSTATUS().equals("SUCCESS")) {
                    duvar.setRegistroexitoso(true);

                    Intent intent = new Intent(getApplicationContext(), AprobacionTurnoActivity.class);
                    startActivity(intent);
                } else {
                    duvar.setRegistroexitoso(false);
                    System.out.println("error creando la cita (onSuccess)>>> " + jsSimple.getMSG_());
                    Toast.makeText(getApplicationContext(), "Ocurrio un error, Intentelo más tarde", Toast.LENGTH_LONG).show();
                }

                System.out.println("seteado el datos personales a" + duvar.isRegistroexitoso());
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                DatosUsuarios duvar = DatosUsuarios.getInstance();
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsonResSimple jsSimple = gson.fromJson(respuesta, JsonResSimple.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                System.out.println("Recibio mensaje de: " + jsSimple.getMSG_());
                if (jsSimple.getSTATUS().equals("SUCCESS")) {
                    duvar.setRegistroexitoso(true);

                    Intent intent = new Intent(getApplicationContext(), AprobacionTurnoActivity.class);
                    startActivity(intent);
                } else {
                    duvar.setRegistroexitoso(false);
                    System.out.println("error creando la cita (onSuccess)>>> " + jsSimple.getMSG_());
                    Toast.makeText(getApplicationContext(), "Ocurrio un error, Intentelo más tarde", Toast.LENGTH_LONG).show();
                }

                System.out.println("seteado el datos personales a" + duvar.isRegistroexitoso());
            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                DatosUsuarios duvar = DatosUsuarios.getInstance();
                String respString = responseString;
                System.out.println("error creando la cita (onFailure)>>> " + responseString);
                Toast.makeText(getApplicationContext(), "Ocurrio un error, Intentelo más tarde", Toast.LENGTH_LONG).show();
                duvar.setRegistroexitoso(false);
            }
        });

    }

    private void signOut()
    {
        sesion.logoutUser();
    }

}
