package com.hayturnoapp.models;

/**
 * Created by Nicolas on 02/10/2016.
 */

public class JsResId {
    private String STATUS;
    private String MSG_;
    private Integer patientID;

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    public String getMSG_() {
        return MSG_;
    }

    public void setMSG_(String MSG_) {
        this.MSG_ = MSG_;
    }

    public Integer getPatientID() {
        return patientID;
    }

    public void setPatientID(Integer patientID) {
        this.patientID = patientID;
    }
}
