package com.hayturnoapp.utils;

import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormatSymbols;
import java.util.Locale;

public class Utils {

    public static CharSequence getActualTitlePager (int position){

        StringBuilder title = new StringBuilder();
        position++;
        switch (position)  {
            case 1:
                title.append(position);
            break;

            case 2:
                title.append(position);
            break;

            case 3:
                title.append(position);
            break;

            case 4:
                title.append(position);
            break;

            case 5:
                title.append(position);
            break;
            default:
                title.append("Page ").append(position);
            break;
        }
        return title;
    }


    public boolean esBisiesto(int year)
    {
        //if year is divisible by 4, it is a leap year
        if((year % 400 == 0) || ((year % 4 == 0) && (year % 100 != 0)))
          return true;
        else
          return false;
    }

    public String formatMonth(int month, Locale locale) {
        DateFormatSymbols symbols = new DateFormatSymbols(locale);
        String[] monthNames = symbols.getMonths();
        return monthNames[month - 1];
    }

    public String obtenerStringdeBitmap(Bitmap bitmapPicture)
    {
        final int COMPRESSION_QUALITY = 100;
        String encodedImage;
        ByteArrayOutputStream byteArrayBitmapStream = new ByteArrayOutputStream();
        bitmapPicture.compress(Bitmap.CompressFormat.PNG, COMPRESSION_QUALITY,
                byteArrayBitmapStream);
        byte[] b = byteArrayBitmapStream.toByteArray();
        encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
        return encodedImage;
    }

    public Bitmap obtenerBitmapdeString(String jsonString) {

        byte[] decodedString = Base64.decode(jsonString, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        return decodedByte;
    }

    public String saveToInternalStorage(Bitmap bitmapImage, Context contexto)
    {
        ContextWrapper cw = new ContextWrapper(contexto);
        // path to /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("HayTurnoFotoDir", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath=new File(directory,"fotoUsuario.png");

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }

    public Bitmap loadImageFromStorage(String path)
    {

        try {
            File f=new File(path, "fotoUsuario.png");
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            return b;

        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            return null;
        }

    }

    public File getFilefromPath(String path)
    {
        if(path.isEmpty())
            return null;
        else
        {
           File f = new File(path, "fotoUsuario.png");
           return f;
        }
    }


    // esta funcion se utiliza para redimensinar la fotografia a un menor tamano
    public File saveBitmapToFile(File file){
        try {

            // BitmapFactory options to downsize the image
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            o.inSampleSize = 6;
            // factor of downsizing the image

            FileInputStream inputStream = new FileInputStream(file);
            //Bitmap selectedBitmap = null;
            BitmapFactory.decodeStream(inputStream, null, o);
            inputStream.close();

            // The new size we want to scale to
            final int REQUIRED_SIZE=75;

            // Find the correct scale value. It should be the power of 2.
            int scale = 1;
            while(o.outWidth / scale / 2 >= REQUIRED_SIZE &&
                    o.outHeight / scale / 2 >= REQUIRED_SIZE) {
                scale *= 2;
            }

            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            inputStream = new FileInputStream(file);

            Bitmap selectedBitmap = BitmapFactory.decodeStream(inputStream, null, o2);
            inputStream.close();

            // here i override the original image file
            file.createNewFile();
            FileOutputStream outputStream = new FileOutputStream(file);

            selectedBitmap.compress(Bitmap.CompressFormat.PNG, 100 , outputStream);

            return file;
        } catch (Exception e) {
            return null;
        }
    }


}
