package com.hayturnoapp.models;

/**
 * Created by Nicolas on 17/10/2016.
 */

public class ObraSocial {
    private Integer id;    //"id": 1,
    private String nombre; // "nombre": "Boreal",
    private String estado; // "estado": "ACT"

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String toString() {
        return nombre;
    }
}
