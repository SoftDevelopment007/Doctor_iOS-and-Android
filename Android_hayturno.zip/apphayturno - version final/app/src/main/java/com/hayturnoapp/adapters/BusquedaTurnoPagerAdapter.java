package com.hayturnoapp.adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hayturnoapp.BusquedaTurnoActivity;
import com.hayturnoapp.R;
import com.hayturnoapp.models.ValorFiltros;
import com.hayturnoapp.utils.Utils;

public class BusquedaTurnoPagerAdapter extends FragmentStatePagerAdapter {

    public BusquedaTurnoPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {

        return BusquedaTurnoActivity.BusquedaTurnoFragment.newInstance(position);
    }

    @Override
    public int getCount() {
        return 5;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return Integer.toString(position+1);
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

}
