package com.hayturnoapp.models;


public class Autorizacion {
       private Integer patientID; //": 1,
       private String  loginPolicy; // "USRPASSWD",
       private String  eml; // "juanperez@gmail.com",
       private String   psswd; // "psswd":"Prueba123"


    public Integer getPatientID() {
        return patientID;
    }

    public void setPatientID(Integer patientID) {
        this.patientID = patientID;
    }

    public String getLoginPolicy() {
        return loginPolicy;
    }

    public void setLoginPolicy(String loginPolicy) {
        this.loginPolicy = loginPolicy;
    }

    public String getEml() {
        return eml;
    }

    public void setEml(String eml) {
        this.eml = eml;
    }

    public String getPsswd() {
        return psswd;
    }

    public void setPsswd(String psswd) {
        this.psswd = psswd;
    }
}
