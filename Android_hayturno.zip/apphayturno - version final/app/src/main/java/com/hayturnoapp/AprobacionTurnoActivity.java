package com.hayturnoapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.hayturnoapp.utils.ExceptionHandler;

public class AprobacionTurnoActivity extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // manejador de error

        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setContentView(R.layout.activity_aprobacion_turno);
      //  setupToolBar();

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

    }

    //--------------------------------------- Utils ------------------------------------------------
    public void startPersonalData(View view) {
        Intent intent = new Intent(this, DatosPersonalesActivity.class);
        startActivity(intent);
    }

    // ese enva al actvity principal de la aplicacion
    public void startCalendarioTurnos(View view) {
        Intent intent = new Intent(this, CalendariosTurnoActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
            case R.id.action_settings:
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
