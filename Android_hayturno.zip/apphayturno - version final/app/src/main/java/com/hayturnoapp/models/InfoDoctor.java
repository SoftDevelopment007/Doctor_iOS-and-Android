package com.hayturnoapp.models;

/**
 * Created by Nicolas on 18/09/2016.
 */
public class InfoDoctor {
   // private Integer id;
    private String  nombre ;
    private String  apellido;
    private String  dni;
    private String  sexo;
    private String  fechaNacimiento;
    private String  telefono;
    private String  celular;
    private String  email;
    private Integer estado;
    //------------ nuevos---------

    private Integer numObraSocial;
    private Integer assistantID;
    private String obraSocialInfo;
    private String  personType;
    private Integer  doctorID;

    private Integer hospitalID;
    private Integer patientID;
    private Integer personID;
    //--------------------------
    private String  urlFotoPerfil;
    private String  facebookToken;
    private String  googleToken ;
    private String  fechacreacion;
    private Integer locationID;
    private Integer provinceID;


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getEstado() {
        return estado;
    }

    public void setEstado(Integer estado) {
        this.estado = estado;
    }

    public String getUrlFotoPerfil() {
        return urlFotoPerfil;
    }

    public void setUrlFotoPerfil(String urlFotoPerfil) {
        this.urlFotoPerfil = urlFotoPerfil;
    }

    public String getFacebookToken() {
        return facebookToken;
    }

    public void setFacebookToken(String facebookToken) {
        this.facebookToken = facebookToken;
    }

    public String getGoogleToken() {
        return googleToken;
    }

    public void setGoogleToken(String googleToken) {
        this.googleToken = googleToken;
    }

    public String getFechacreacion() {
        return fechacreacion;
    }

    public void setFechacreacion(String fechacreacion) {
        this.fechacreacion = fechacreacion;
    }

    public Integer getLocationID() {
        return locationID;
    }

    public void setLocationID(Integer locationID) {
        this.locationID = locationID;
    }

    public Integer getProvinceID() {
        return provinceID;
    }

    public void setProvinceID(Integer provinceID) {
        this.provinceID = provinceID;
    }


    public Integer getNumObraSocial() {
        return numObraSocial;
    }

    public void setNumObraSocial(Integer numObraSocial) {
        this.numObraSocial = numObraSocial;
    }

    public Integer getAssistantID() {
        return assistantID;
    }

    public void setAssistantID(Integer assistantID) {
        this.assistantID = assistantID;
    }

    public String getObraSocialInfo() {
        return obraSocialInfo;
    }

    public void setObraSocialInfo(String obraSocialInfo) {
        this.obraSocialInfo = obraSocialInfo;
    }

    public String getPersonType() {
        return personType;
    }

    public void setPersonType(String personType) {
        this.personType = personType;
    }

    public Integer getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(Integer doctorID) {
        this.doctorID = doctorID;
    }

    public Integer getHospitalID() {
        return hospitalID;
    }

    public void setHospitalID(Integer hospitalID) {
        this.hospitalID = hospitalID;
    }

    public Integer getPatientID() {
        return patientID;
    }

    public void setPatientID(Integer patientID) {
        this.patientID = patientID;
    }

    public Integer getPersonID() {
        return personID;
    }

    public void setPersonID(Integer personID) {
        this.personID = personID;
    }
}
