package com.hayturnoapp;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hayturnoapp.models.Autorizacion;
import com.hayturnoapp.models.JsResId;
import com.hayturnoapp.models.JsonResSimple;
import com.hayturnoapp.models.ObraSocial;
import com.hayturnoapp.utils.DatosGlobales;
import com.hayturnoapp.utils.DatosUsuarios;
import com.hayturnoapp.utils.ExceptionHandler;
import com.hayturnoapp.utils.ProcesoTermindo;
import com.hayturnoapp.utils.RestClient;
import com.hayturnoapp.utils.Session;
import com.hayturnoapp.utils.Utils;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.koushikdutta.ion.Response;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.mindorks.paracamera.Camera;
import com.tmxlr.lib.driodvalidatorlight.Form;
import com.tmxlr.lib.driodvalidatorlight.helper.Range;
import com.tmxlr.lib.driodvalidatorlight.helper.RegexTemplate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;

import cz.msebera.android.httpclient.Header;

public class DatosPersonalesActivity extends AppCompatActivity {

 //   static final int REQUEST_IMAGE_CAPTURE = 1;
 //   private Bitmap mImageBitmap;
 //   private String mCurrentPhotoPath;
 //   private ImageView mImageView;

    private EditText etFechaNacimiento;
    private SimpleDateFormat dateFormatter;
    private DatePickerDialog dpdFechaNacimiento;
    private Spinner dropdownObraSocial;
    private Spinner dropdownGenero;
    private EditText etDni;
    private EditText etCelular;
    private EditText etNoAfiliado;

    private Camera camera;
    private ImageView img1;

    ProgressDialog dlg;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        // manejador de error
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setContentView(R.layout.activity_datos_personales);


        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        img1 = (ImageView) findViewById(R.id.logoImageView);
        Glide.with(this).load("").centerCrop().placeholder(R.drawable.foto_persona_v2).into(img1);

        dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        dropdownObraSocial = (Spinner) findViewById(R.id.spinnerObrasocial);
        dropdownGenero     = (Spinner) findViewById(R.id.spinnerGenero);
        etDni              = (EditText) findViewById(R.id.editTextDni);
        etCelular          = (EditText) findViewById(R.id.editTextCelular);
        etNoAfiliado       = (EditText) findViewById(R.id.editTextNoAfiliado);
        camera = new Camera(this);

        DatosUsuarios duvar = DatosUsuarios.getInstance();


        TextView tvNombre = (TextView) findViewById(R.id.editTextNombreApellido);
        TextView tvCorreo = (TextView) findViewById(R.id.editTextMail);

        String nombre= "";
        String correo = "";

        if(duvar.isRegistroporFB() || duvar.isRegistroporGmail())
        {
            nombre = duvar.getNombres()+" "+ duvar.getApellidos();
            correo = duvar.getEmail();

            if(duvar.isRegistroporFB())
                System.out.println("token fb>" + duvar.getAccessTokenFB().getToken());
            else
                System.out.println("token g>" +duvar.getIdTokenGmail());

        }
        else if (duvar.isRegistroporApp() )
        {
            nombre = duvar.getNombres()+" "+ duvar.getApellidos();
            correo = duvar.getEmail();
        }

        tvNombre.setText(nombre);
        tvCorreo.setText(correo);



        camera.builder()
                .resetToCorrectOrientation(true)// it will rotate the camera bitmap to the correct orientation from meta data
                .setDirectory("pics")
                .setName("HayTurno_" + System.currentTimeMillis())
                .setImageFormat(Camera.IMAGE_PNG)
                .setCompression(75)
                .setImageHeight(1000);// it will try to achieve this height as close as possible maintaining the aspect ratio;


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                try {
                    camera.takePicture();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        llenarSpinner();
        setearFechasDatepicker();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == Camera.REQUEST_TAKE_PHOTO){
            Bitmap bitmap = camera.getCameraBitmap();
            if(bitmap != null)
            {
                ImageView fotoperfil = (ImageView) findViewById(R.id.logoImageView);
                Glide.with(this).load(camera.getCameraBitmapPath()).centerCrop().fitCenter().into(fotoperfil);

            }else{
                Toast.makeText(this.getApplicationContext(),"No se tomo la foto!",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        camera.deleteImage(); //Borramos imagen
    }

    private void setearFechasDatepicker()
    {
        etFechaNacimiento = (EditText)findViewById(R.id.editTextFechaNacimiento);
        etFechaNacimiento.setInputType(InputType.TYPE_NULL);
        etFechaNacimiento.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                dpdFechaNacimiento.show();
            }
        });

        Calendar calendario =  Calendar.getInstance();
        dpdFechaNacimiento = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener(){

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth)
            {
                    Calendar fecha = Calendar.getInstance();
                    fecha.set( year,  monthOfYear, dayOfMonth);
                    etFechaNacimiento.setText(dateFormatter.format(fecha.getTime()));
            }

        }, calendario.get(Calendar.YEAR), calendario.get(Calendar.MONTH), calendario.get(Calendar.DAY_OF_MONTH));
    }


    private void llenarSpinner()
    {
        try
        {
            llenarSpinnerObraSocial();
        }
        catch (  JSONException | UnsupportedEncodingException e )
        {
            e.printStackTrace();
        }


        ArrayList<String > generoList = new ArrayList<String>();
        generoList.add("M");
        generoList.add("F");
        ArrayAdapter<String> dataAdapterGenero = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, generoList);
        dataAdapterGenero.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        dropdownGenero.setAdapter(dataAdapterGenero);

    }


    public void startAprobacion( final View view) throws JSONException, UnsupportedEncodingException
    {
        Form form = new Form(this);

        // validamos formulario
        form.check(etFechaNacimiento, RegexTemplate.NOT_EMPTY_PATTERN, "Debe Ingresar fecha de nacimiento");

        form.check(etCelular,RegexTemplate.NOT_EMPTY_PATTERN, "El celular no debe ir vacio" );

        form.check(etDni,RegexTemplate.NOT_EMPTY_PATTERN, "El dni no debe estar vacio" );
        form.checkLength(etDni, Range.equalOrLess(10), "El dni no debe ser mayor a 10 digitos" );

        form.check(etNoAfiliado,RegexTemplate.NOT_EMPTY_PATTERN, "El numero de afiliado no debe estar vacio" );

        if(form.validate())
        {
            registrarUsuario(view, new Callback<Integer>()
            {
                @Override
                public void onResponse(Integer integer)
                {
                    DatosUsuarios dgvari = DatosUsuarios.getInstance();
                    dgvari.setPatientID(integer);
                    //invocar aqui la session
                    generarSesion();
                    try{
                        registrarCita(view);
                    }
                    catch ( JSONException| UnsupportedEncodingException e)
                    {e.printStackTrace();}

                }
            });
        }
        else
        {
            Toast.makeText(this, "Por favor, revise sus datos.", Toast.LENGTH_LONG).show();
        }

    }

    /*  Primer paso que se hace el registro de usuario, ya que se necesita los datos del usuario
     *  para
     */
    private void registrarUsuario(final View view, final Callback<Integer> callback) throws   JSONException, UnsupportedEncodingException
    {
        DatosGlobales dgvar = DatosGlobales.getInstance();
        DatosUsuarios duvar = DatosUsuarios.getInstance();
        long noAfiliado = 0;
        String genero  = dropdownGenero.getSelectedItem().toString();
        String DNI     = etDni.getText().toString();
        String celular = etCelular.getText().toString();
        String fechaNacimiento = etFechaNacimiento.getText().toString();

        Integer generoID = 0;
        String loginPolicy = "";

        JSONObject obj = new JSONObject();

        if (  duvar.isRegistroporFB()   )
            loginPolicy = "FB";
        else if (  duvar.isRegistroporGmail()  )
            loginPolicy = "G";
        else
            loginPolicy = "USRPASSWD";


        if(genero.equals("M"))
            generoID =1;
        else
            generoID =2;

        ObraSocial obraElegida = (ObraSocial) dropdownObraSocial.getSelectedItem();

        duvar.setGenero(generoID.toString());
        duvar.setDni(DNI);
        duvar.setCelular(celular );
        duvar.setFechaNacimiento(fechaNacimiento);
        duvar.setLoginPolicy(loginPolicy);
        duvar.setSociaSecurityType(obraElegida.getId());
        duvar.setSociaSecurityNumber(noAfiliado);


        if(duvar.getDni().isEmpty())
            duvar.setDni("00000");

        if ( !etNoAfiliado.getText().toString().isEmpty() )
        {
            String value = etNoAfiliado.getText().toString().trim();
            noAfiliado = Long.parseLong(value);
            duvar.setSociaSecurityNumber(noAfiliado);
        }

        obj.put("firstName", duvar.getNombres());
        obj.put("lastName", duvar.getApellidos());
        obj.put("cellPhone", duvar.getCelular());
        obj.put("dni", Long.parseLong(duvar.getDni()));
        obj.put("birthDate", duvar.getFechaNacimiento());
        obj.put("gender", Integer.valueOf(duvar.getGenero()));
        obj.put("locationID", dgvar.getIdCiudadSelecta());
        obj.put("provinceID", dgvar.getIdProvinciaSelecta());
        obj.put("telephone", duvar.getCelular() );
        obj.put("loginPolicy", duvar.getLoginPolicy() );
        obj.put("email", duvar.getEmail());

        if (  duvar.isRegistroporFB()   )
        {
            obj.put("facebooktoken",duvar.getAccessTokenFB().getToken() );
            duvar.setContraseña(duvar.getAccessTokenFB().getToken());
        }
        else if (  duvar.isRegistroporGmail()   )
        {
            obj.put("googletoken", duvar.getIdTokenGmail());
            duvar.setContraseña(duvar.getIdTokenGmail());
        }
        else
        {
            obj.put("password", duvar.getContraseña());
        }
        obj.put("socialSecurityType", duvar.getSociaSecurityType());
        obj.put("socialSecurityNumber", duvar.getSociaSecurityNumber());



        System.out.println("JSON ENVIADO de datos::::::::"+obj.toString());
        RestClient.postJson(null, "/patient/user/add", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                System.out.println("Llamo al object::::::");
                Integer id= 0;

                // extraigo el Id
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsResId jsSimple = gson.fromJson(respuesta,  JsResId.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                System.out.println("Recibio estatus de: " + jsSimple.getMSG_());
                if( jsSimple.getSTATUS().equals("SUCCESS")){
                    if (callback != null) {
                        id =  jsSimple.getPatientID();
                        callback.onResponse(id);
                    }
                }
                else {

                    Toast.makeText(getApplicationContext(), jsSimple.getMSG_(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                System.out.println("Llamo al array::::::");
                Integer id= 0;

                // extraigo el Id
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsResId jsSimple = gson.fromJson(respuesta,  JsResId.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                if( jsSimple.getSTATUS().equals("SUCCESS")){
                    if (callback != null) {
                        id =  jsSimple.getPatientID();
                        callback.onResponse(id);
                    }
                }
                else {

                    Toast.makeText(getApplicationContext(), jsSimple.getMSG_(), Toast.LENGTH_LONG).show();
                }
                if (callback != null) {
                    callback.onResponse(id);
                }
            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

                System.out.print("error de creacion: " + responseString);
                Toast.makeText(getApplicationContext(), "Ocurrio un error, Intentelo más tarde..." , Toast.LENGTH_SHORT).show();

            }
        });
    }

    /*   Registro de la cita creada en la primera interaccion del usuario.
     *
     */
    private void registrarCita(final View view) throws   JSONException, UnsupportedEncodingException
    {
        DatosGlobales dgvar = DatosGlobales.getInstance();
        DatosUsuarios duvar = DatosUsuarios.getInstance();
        Autorizacion auth = new Autorizacion();
        Gson gson = new Gson();

        String autorizacion = "";
        auth.setPatientID(duvar.getPatientID());
        auth.setLoginPolicy(duvar.getLoginPolicy());
        auth.setEml(duvar.getEmail());
        auth.setPsswd(duvar.getContraseña());
        //---------------------------------

        autorizacion = gson.toJson(auth);

        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID() );
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if(auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());

        System.out.println("JSON interno de datos::::::::"+ autorizacion);

        JSONObject obj = new JSONObject();
        //    obj.put("doctorID", DGvar.getIdDoctor());
        obj.put("authorization", objAuth);
        obj.put("patientID", duvar.getPatientID()); // este dato es recien generado, primero hay que hacer insert de paciente
        obj.put("date", dgvar.getFecha_turno());
        obj.put("startTime",dgvar.getHorario_Inicio()+":00");
        obj.put("endTime", dgvar.getHorario_Fin()+":00");
        obj.put("hospitalID", dgvar.getIdCentroMedico());
        obj.put("doctorID", dgvar.getIdDoctor());

        System.out.println("JSON ENVIADO de datos::::::::"+obj.toString());
        RestClient.postJson(null, "/appointment/schedule", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                DatosUsuarios duvar = DatosUsuarios.getInstance();
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsonResSimple jsSimple = gson.fromJson(respuesta, JsonResSimple.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                System.out.println("Recibio mensaje de : " + jsSimple.getMSG_());
                if( jsSimple.getSTATUS().equals("SUCCESS")){
                    duvar.setRegistroexitoso(true);

                   //mandamos a subir foto, ese metodo se encargara de mandar a llamar el siguiente activity

                    Intent intent = new Intent(view.getContext() , AprobacionTurnoActivity.class);
                    startActivity(intent);
                }
                else {
                    duvar.setRegistroexitoso(false);
                    System.out.println("DPA1 Error creando la cita: " + jsSimple.getMSG_() );
                    Toast.makeText(getApplicationContext(), "Ocurrio un error creando la cita, Intentelo más tarde", Toast.LENGTH_LONG).show();
                }

                System.out.println("seteado el datos personales a" + duvar.isRegistroexitoso());
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                DatosUsuarios duvar = DatosUsuarios.getInstance();
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsonResSimple jsSimple = gson.fromJson(respuesta, JsonResSimple.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS().equals("SUCCESS"));
                System.out.println("Recibio mensaje de : " + jsSimple.getMSG_());
                if( jsSimple.getSTATUS().equals("SUCCESS"))
                {
                    duvar.setRegistroexitoso(true);
                    if(camera != null)
                       subirFoto();
                    else
                    {
                        Intent intent = new Intent(view.getContext(), AprobacionTurnoActivity.class);
                        startActivity(intent);
                    }

                }
                else
                {
                    duvar.setRegistroexitoso(false);
                    System.out.println("DPA2 Error creando la cita: " + jsSimple.getMSG_() );
                    Toast.makeText(getApplicationContext(), "Ocurrio un error creando la cita, Intentelo más tarde", Toast.LENGTH_LONG).show();
                    if(camera != null)
                        subirFoto();
                    else
                    {
                        Intent intent = new Intent(view.getContext(), AprobacionTurnoActivity.class);
                        startActivity(intent);
                    }
                }

            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                DatosUsuarios duvar = DatosUsuarios.getInstance();
                System.out.println("DPA3 Error creando la cita: " + responseString );
                Toast.makeText(getApplicationContext(), "Ocurrio un error registrando la cita, Intentelo más tarde", Toast.LENGTH_LONG).show();
                duvar.setRegistroexitoso(false);
            }
        });


    }

    private void llenarSpinnerObraSocial() throws JSONException, UnsupportedEncodingException
    {
        JSONObject obj = new JSONObject();
        obj.put("s","s");

        //   System.out.println(">>>>>>>>>"+obj);

        RestClient.postJson(null,"/patient/obrasocial/all",obj, new JsonHttpResponseHandler(){

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response)
            {
                String respuesta = response.toString();
                System.out.println("DEVOLVIO un array>>>>>>>>>>>>>>" + respuesta);
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<ObraSocial>>(){}.getType();
                Collection<ObraSocial> enums = gson.fromJson(respuesta, collectionType);
                ObraSocial[] map = enums.toArray(new ObraSocial[enums.size()]);

                ArrayList<ObraSocial> obras = new ArrayList<>();
                for (ObraSocial p: map)
                {
                    obras.add(p);
                }
                ArrayAdapter<ObraSocial> dataAdapterYers = new ArrayAdapter<ObraSocial>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item, obras);
                  dropdownObraSocial.setAdapter(dataAdapterYers);

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response)
            {
                String respuesta = response.toString();
                System.out.println("DEVOLVIO un array>>>>>>>>>>>>>>" + respuesta);
                Gson gson = new Gson();

                Type collectionType = new TypeToken<Collection<ObraSocial>>(){}.getType();
                Collection<ObraSocial> enums = gson.fromJson(respuesta, collectionType);
               ObraSocial[] map = enums.toArray(new ObraSocial[enums.size()]);

                ArrayList<ObraSocial> obras = new ArrayList<>();
                for (ObraSocial p: map)
                {
                    obras.add(p);
                }
                ArrayAdapter<ObraSocial> dataAdapterYers = new ArrayAdapter<ObraSocial>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item, obras);
                dataAdapterYers.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                dropdownObraSocial.setAdapter(dataAdapterYers);

            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                String respString = responseString;
                System.out.println("Error>>>>>>>>>"+respString );
                Toast.makeText(getBaseContext().getApplicationContext(), "Ocurrio un error de conexion", Toast.LENGTH_LONG).show();
            }
        });

    }

    //se llama cuando confirmamos que hubo exito en la session
    private void generarSesion()
    {
        DatosUsuarios duvar = DatosUsuarios.getInstance();

        String nombrePaciente =  duvar.getNombres()+" "+duvar.getApellidos();
        //termino Proceso
        ProcesoTermindo pt = new ProcesoTermindo(DatosPersonalesActivity.this);
        pt.setProcesoTerminado();

        Session sesion = new Session(this);
        sesion.crearLoginSession(nombrePaciente,duvar.getEmail(),duvar.getPatientID(),duvar.getLoginPolicy(),duvar.getContraseña());
    }

    /*
    *Este metodo cargara la foto del ususario y nos enviara al siguiente activity
    * */
    private void subirFoto()
    {
        Autorizacion auth = new Autorizacion();
        Session sesion = new Session(this);
        //Sacamos los datos del paciente
        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));

        Utils u  = new Utils();

        File fotoaComprimir = new File(camera.getCameraBitmapPath());
        File foto =  u.saveBitmapToFile(fotoaComprimir);

        //guardamos la imagen antes de


        //mostrando progres
        dlg = new ProgressDialog(this);
        dlg.setTitle("Cargando Foto...");
        dlg.setIndeterminate(false);
        dlg.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dlg.show();

        String pswdParameterJson = "";

        if(auth.getLoginPolicy().equals("FB"))
            pswdParameterJson = "facebooktoken";   //       objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            pswdParameterJson = "googletoken";     //  objAuth.put("googletoken", auth.getPsswd());
        else
            pswdParameterJson = "psswd";           //objAuth.put("psswd", auth.getPsswd());



        Ion.with(this)
                .load("POST", RestClient.getAbsoluteUrlserver("/patient/pic/add"))
                .progressDialog(dlg)
                .setTimeout(60 * 60 * 1000)
                .setMultipartParameter("patientID", auth.getPatientID().toString())
                .setMultipartParameter("loginPolicy", auth.getLoginPolicy())
                .setMultipartParameter("eml", auth.getEml())
                .setMultipartParameter(pswdParameterJson, auth.getPsswd())
                .setMultipartFile("pic", "image/png", foto)
                .asString()
                .withResponse()
                .setCallback(new FutureCallback<Response<String>>() {
                    @Override
                    public void onCompleted(Exception e, Response<String> result)
                    {
                        dlg.cancel();

                        if(e  != null)
                        {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                        else
                        {                            // print the response code, ie, 200
                            System.out.println(result.getHeaders().code());
                            // print the String that was downloaded
                            Toast.makeText(getApplicationContext(), result.getResult(), Toast.LENGTH_LONG).show();
                            System.out.println(result.getResult());
                        }

                        Intent intent = new Intent(getApplicationContext(), AprobacionTurnoActivity.class);
                        startActivity(intent);

                    }
                });

    }

    public interface Callback<T> {
        void onResponse(T t);
    }
}
