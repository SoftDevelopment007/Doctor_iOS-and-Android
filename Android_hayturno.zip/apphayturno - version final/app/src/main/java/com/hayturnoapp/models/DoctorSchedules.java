package com.hayturnoapp.models;

import java.util.ArrayList;

public class DoctorSchedules {

    private ArrayList<Appointment> appointments;
    private ArrayList<HorariosDoctor> schedules;

    public ArrayList<Appointment> getAppointments() {
        return appointments;
    }

    public void setAppointments(ArrayList<Appointment> appointments) {
        this.appointments = appointments;
    }

    public ArrayList<HorariosDoctor> getSchedules() {
        return schedules;
    }

    public void setSchedules(ArrayList<HorariosDoctor> schedules) {
        this.schedules = schedules;
    }
}
