package com.hayturnoapp.utils;



import android.content.Context;
import android.util.ArrayMap;

import org.json.*;
import com.loopj.android.http.*;

import java.io.UnsupportedEncodingException;
import cz.msebera.android.httpclient.Header;


public class RestClientInterface {

    private boolean statusLlamada;
    private String stringJson;
    private Context contexto;

    public RestClientInterface()
    {
        this.statusLlamada = false;
        stringJson = "";
    }

    public String obtenerProvincias() throws JSONException, UnsupportedEncodingException
    {
        JSONObject obj = new JSONObject();
        obj.put("s","s");
        String respuestaJsonInt="";
     //   System.out.println(">>>>>>>>>"+obj);

        RestClient.postJson(getContexto(),"/location/provinces/all",obj, new JsonHttpResponseHandler(){

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected JSONArray
                String respuesta = response.toString();
                System.out.println("DEVOLVIO>>>>>>>>>>>>>>" + respuesta);
                //setStringJson( respuesta);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                // Extraemos las provincias que devuelva el WS

                String respuesta = response.toString();
                System.out.println("DEVOLVIO>>>>>>>>>>>>>>" + respuesta);
                //setStringJson( respuesta);

            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                //setStatusLlamada(true); //indicamos que fallo la llamada
                String respString = responseString;
                System.out.println("Error>>>>>>>>>"+respString );

                //setStringJson("");
            }
        });

        return getStringJson();
    }

    //getters and setters

    public boolean isStatusLlamada() {
        return statusLlamada;
    }

    public void setStatusLlamada(boolean statusLlamada) {
        this.statusLlamada = statusLlamada;
    }

    public String getStringJson() {
        return stringJson;
    }

    public void setStringJson(String stringJson) {
        this.stringJson = stringJson;
    }

    public Context getContexto() {
        return contexto;
    }

    public void setContexto(Context contexto) {
        this.contexto = contexto;
    }
}
