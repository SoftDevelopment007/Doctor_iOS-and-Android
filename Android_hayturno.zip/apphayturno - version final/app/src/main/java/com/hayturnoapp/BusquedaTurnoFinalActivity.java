package com.hayturnoapp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.hayturnoapp.utils.DatosGlobales;
import com.hayturnoapp.utils.ExceptionHandler;
import com.hayturnoapp.utils.Session;
import com.hayturnoapp.utils.Utils;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IProfile;

import java.util.HashMap;

public class BusquedaTurnoFinalActivity extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private LinearLayout linearLayoutProvincia;
    private LinearLayout linearLayoutCiudad;
    private LinearLayout linearLayoutEspecialidad;
    private LinearLayout linearLayoutInstituto;
    private LinearLayout linearLayoutEspecialista;

    //elementos del Drawer
    private Drawer resultDrawer;
    private AccountHeader headerResult;

    private String[] activityTitles;

    private Session sesion;

    public void startConfirmacion(View view) {

        Intent intent = new Intent(this, ConfirmacionTurnoActivity.class);
        startActivity(intent);
    }

    public void startBuscarHorario(View view) {
        Intent intent = new Intent(this, BuscarHorarioActivity.class);
        startActivity(intent);
    }


    public void enviarFiltros(View view, int filtro) {
        DatosGlobales var = DatosGlobales.getInstance();
        var.setFiltroNuevo(filtro);
        var.setRevisarFiltro(true);
        Intent intent = new Intent(this, BusquedaTurnoActivity.class);
        startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // manejador de error
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setContentView(R.layout.activity_busqueda_turno_final);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        //   setSupportActionBar(toolbar);

        DatosGlobales var = DatosGlobales.getInstance();

        activityTitles = getResources().getStringArray(R.array.nav_item_activity_titles);
        sesion = new Session(this);

        linearLayoutProvincia     = (LinearLayout) findViewById(R.id.ContainerProvinciabtf);
        linearLayoutCiudad        = (LinearLayout) findViewById(R.id.ContainerCiudadbtf);
        linearLayoutEspecialidad  = (LinearLayout) findViewById(R.id.ContainerEspecialidadbtf);
        linearLayoutInstituto     = (LinearLayout) findViewById(R.id.ContainerHospitalbtf);
        linearLayoutEspecialista  = (LinearLayout) findViewById(R.id.ContainerEspecialistabtf);


        TextView TvProvincia    = (TextView) findViewById(R.id.textViewProvincia);
        TextView TvCiudad       = (TextView) findViewById(R.id.textViewCiudad);
        TextView TvEspecialidad = (TextView) findViewById(R.id.textViewEspecialidad);
        TextView TvCentroMedico = (TextView) findViewById(R.id.textViewCentroMedico);
        TextView TvDoctor       = (TextView) findViewById(R.id.textViewEspecilalista);


        TvProvincia.setText(var.getNombreProvincia());
        setRobotoFont(TvProvincia);
        TvCiudad.setText(var.getNombreCiudad());
        setRobotoFont(TvCiudad);
        TvEspecialidad.setText(var.getNombreEspecialidad());
        setRobotoFont(TvEspecialidad);
        TvCentroMedico.setText(var.getNombreCentroMedico());
        setRobotoFont(TvCentroMedico);
        TvDoctor.setText(var.getNombreDoctor());
        setRobotoFont(TvDoctor);

        System.out.println("ID DEL DOC:::::" + var.getIdDoctor().toString());


        linearLayoutProvincia.setOnClickListener(new LinearLayout.OnClickListener() {
            @Override
            public void onClick(View view) {
                enviarFiltros(view, 1);
            }
        });

        linearLayoutCiudad.setOnClickListener(new LinearLayout.OnClickListener() {
            @Override
            public void onClick(View view) {
                enviarFiltros(view, 2);
            }
        });

        linearLayoutEspecialidad.setOnClickListener(new LinearLayout.OnClickListener() {
            @Override
            public void onClick(View view) {
                enviarFiltros(view, 3);
            }
        });

        linearLayoutInstituto.setOnClickListener(new LinearLayout.OnClickListener() {
            @Override
            public void onClick(View view) {
                enviarFiltros(view, 4);
            }
        });

        linearLayoutEspecialista.setOnClickListener(new LinearLayout.OnClickListener() {
            @Override
            public void onClick(View view) {
                enviarFiltros(view, 5);
            }
        });


        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);


        if (sesion.isLoggedIn())
        {
            toolbar.setNavigationIcon(R.drawable.ic_menu);
            HashMap<String, String> user = sesion.getDetalleUsuario();

            String directorioFotoUsuario = "";
            Utils u = new Utils();
            final ProfileDrawerItem datoUsuario = new ProfileDrawerItem();
            datoUsuario.withName(user.get(sesion.KEY_NAME));

            directorioFotoUsuario =  sesion.getDirectorioFotoUsuario();

            if( directorioFotoUsuario == null)
                directorioFotoUsuario = "";

            if( !directorioFotoUsuario.isEmpty() )
                datoUsuario.withIcon(u.loadImageFromStorage(directorioFotoUsuario));
            else
                datoUsuario.withIcon(getResources().getDrawable(R.drawable.foto_persona));

            headerResult = new AccountHeaderBuilder()
                    .withActivity(this)
                    .withHeaderBackground(R.color.colorBackBlueLight)
                    .addProfiles(datoUsuario)
                    .withSelectionListEnabledForSingleProfile(false)
                    .build();


            //agregamos el menu de navegacion
            resultDrawer = new DrawerBuilder()
                    .withActivity(this)
                    .withToolbar(toolbar)
                    .withAccountHeader(headerResult)
                    .addDrawerItems(
                            new PrimaryDrawerItem().withName( activityTitles[0]).withIcon(R.drawable.icon_search).withIdentifier(1),
                            new PrimaryDrawerItem().withName( activityTitles[1]).withIcon(R.drawable.icon_agenda).withIdentifier(2),
                            new PrimaryDrawerItem().withName( activityTitles[2]).withIcon(R.drawable.icon_mis_medicos).withIdentifier(3),
                            new PrimaryDrawerItem().withName( activityTitles[3]).withIcon(R.drawable.icon_datos_personales).withIdentifier(4),
                            new PrimaryDrawerItem().withName( activityTitles[4]).withIcon(R.drawable.icon_close_session).withIdentifier(5)
                    ).withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
                        @Override
                        public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                            //revisamos si drawerItem esta seteado
                            //drawerItem puede ser nulo por diferentes razones
                            //--> click en encaebzado
                            //--> click en el pie
                            // esos items no contiene drawerItem
                            if (drawerItem != null) {
                                Intent intent = null;
                                int identificador = (int) drawerItem.getIdentifier();
                                switch (identificador) {
                                    case 1:
                                        intent = new Intent(BusquedaTurnoFinalActivity.this, BusquedaTurnoFinalActivity.class);
                                        break;
                                    case 2:
                                        intent = new Intent(BusquedaTurnoFinalActivity.this, CalendariosTurnoActivity.class);
                                        break;
                                    case 3:
                                        intent = new Intent(BusquedaTurnoFinalActivity.this, MisMedicosActivity.class);
                                        break;
                                    case 4:
                                        intent = new Intent(BusquedaTurnoFinalActivity.this, DatosPersonalesModificacionActivity.class);
                                        break;
                                    case 5:
                                        signOut();
                                        break;

                                }

                                if (intent != null) {
                                    BusquedaTurnoFinalActivity.this.startActivity(intent);
                                }
                            }
                            return false;
                        }
                    })
                    .build();
        }
    }

    private void signOut()
    {
        sesion.logoutUser();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
            case R.id.action_settings:
                return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void setRobotoFont(TextView dato) {
        Typeface custom_font = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Bold.ttf");
        dato.setTypeface(custom_font);
    }

}
