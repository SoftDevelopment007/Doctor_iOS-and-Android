package com.hayturnoapp.models;

/**
 * Created by Nicolas on 30/09/2016.
 */

public class   Appointment {
            private Integer id; //: 3,
            private String fecha;  //: "12-08-2016",
            private String horaInicio;  //": "11:00:00",
            private String horaFin; //": "11:30:00",
            private String fechaCreacion; //": "09-08-2016 00:00:00",
            private DoctorSimple  doctor;
            private Integer estado; //": 1,
            private Integer doctorID;  //": 1
            private Integer hospitalID;  //": 1,
            private Integer patientID; //": 1,
            private Especialidad specialty;
            private Hospital hospital;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Integer getEstado() {
        return estado;
    }

    public void setEstado(Integer estado) {
        this.estado = estado;
    }

    public String getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(String fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Integer getPatientID() {
        return patientID;
    }

    public void setPatientID(Integer patientID) {
        this.patientID = patientID;
    }

    public Integer getHospitalID() {
        return hospitalID;
    }

    public void setHospitalID(Integer hospitalID) {
        this.hospitalID = hospitalID;
    }

    public Integer getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(Integer doctorID) {
        this.doctorID = doctorID;
    }

    public DoctorSimple getDoctor() {
        return doctor;
    }

    public void setDoctor(DoctorSimple doctor) {
        this.doctor = doctor;
    }

    public Especialidad getSpecialty() {
        return specialty;
    }

    public void setSpecialty(Especialidad specialty) {
        this.specialty = specialty;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }


    // horario es un string HH:MM:SS solo es de remover :SS
    public  String obtenerHorarioInicioFormateado()
    {
          return formatearhorario(horaInicio);
    }

    // horario es un string HH:MM:SS solo es de remover :SS
    public String obtenerHorarioFinFormateado()
    {
          return formatearhorario(horaFin);
    }

    private String formatearhorario (String horario)
    {
        String cadenaformateada = "";

        if (!horario.isEmpty())
        {
            String [] horariotemp = horario.split("\\:");
            cadenaformateada = horariotemp[0]+":"+horariotemp[1];
        }

        return cadenaformateada;
    }
}
