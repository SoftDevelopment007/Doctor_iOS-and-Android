package com.hayturnoapp.models;

/**
 * Created by Nicolas on 02/11/2016.
 */

public class MedicoFavoritoJson {

    private Especialidad specialty;
    private Integer favoriteID;
    private Integer doctorID;
    private InfoDoctor information;
    private Hospital hospital;
    private Appointment nextAppointment;

    public Especialidad getSpeciality() {
        return specialty;
    }

    public void setSpeciality(Especialidad speciality) {
        this.specialty = speciality;
    }

    public Integer getFavoriteID() {
        return favoriteID;
    }

    public void setFavoriteID(Integer favoriteID) {
        this.favoriteID = favoriteID;
    }

    public Integer getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(Integer doctorID) {
        this.doctorID = doctorID;
    }

    public InfoDoctor getInformation() {
        return information;
    }

    public void setInformation(InfoDoctor information) {
        this.information = information;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }

    public Appointment getNextAppointment() {
        return nextAppointment;
    }

    public void setNextAppointment(Appointment nextAppointment) {
        this.nextAppointment = nextAppointment;
    }
}
