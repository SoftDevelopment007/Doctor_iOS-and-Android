package com.hayturnoapp.adapters;


import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

import com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter;
import com.bignerdranch.expandablerecyclerview.Model.ParentListItem;
import com.google.gson.Gson;
import com.hayturnoapp.BuscarHorarioActivity;
import com.hayturnoapp.R;
import com.hayturnoapp.models.Autorizacion;
import com.hayturnoapp.models.JsResId;
import com.hayturnoapp.models.MedicoFavorito;
import com.hayturnoapp.models.MedicoFavoritoHijo;
import com.hayturnoapp.utils.DatosGlobales;
import com.hayturnoapp.utils.RestClient;
import com.hayturnoapp.utils.Session;
import com.hayturnoapp.viewholders.MedicoFavoritoChildViewHolder;
import com.hayturnoapp.viewholders.MedicoFavoritoParentViewHolder;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class ExtendableRecyclerViewMedFav extends ExpandableRecyclerAdapter<MedicoFavoritoParentViewHolder, MedicoFavoritoChildViewHolder> {

    private LayoutInflater mInflater;


    public ExtendableRecyclerViewMedFav(Context context, List<ParentListItem> parentItemList) {
        super(parentItemList);
        mInflater = LayoutInflater.from(context);

    }


    @Override
    public MedicoFavoritoParentViewHolder onCreateParentViewHolder(ViewGroup viewGroup) {

        View view = mInflater.inflate(R.layout.parent_med_favorito, viewGroup, false);
        return new MedicoFavoritoParentViewHolder(view);
    }

    @Override
    public void onBindParentViewHolder(MedicoFavoritoParentViewHolder medicoFavoritoParentViewHolder, int i, ParentListItem o) {
        MedicoFavorito medfav = (MedicoFavorito) o;
        medicoFavoritoParentViewHolder.bind(medfav);
    }

    @Override
    public MedicoFavoritoChildViewHolder onCreateChildViewHolder(ViewGroup viewGroup) {
        View view = mInflater.inflate(R.layout.child_med_favorito, viewGroup, false);
        return new MedicoFavoritoChildViewHolder(view);
    }

    @Override
    public void onBindChildViewHolder(MedicoFavoritoChildViewHolder medicoFavoritoChildViewHolder, int i, Object o) {
        MedicoFavoritoHijo medfavhijo = (MedicoFavoritoHijo) o;
        final Integer IdProximaCita= medfavhijo.getIDProximaCita();
        medicoFavoritoChildViewHolder.mTVEspecialidad.setText(medfavhijo.getTVEspecialidad().getText().toString());
        medicoFavoritoChildViewHolder.mTVHorario.setText(medfavhijo.getTVHorario().getText().toString());
        medicoFavoritoChildViewHolder.mTVHospital.setText(medfavhijo.getTVHospital().getText().toString());
        medicoFavoritoChildViewHolder.mTVFechaTurno.setText(medfavhijo.getTVFechaTurno().getText().toString());
        medicoFavoritoChildViewHolder.mTVDireccion.setText(medfavhijo.getTVDireccion().getText().toString());

        final MedicoFavoritoChildViewHolder clone_mfcvw = medicoFavoritoChildViewHolder;
        final MedicoFavoritoHijo medfavhijocopy = medfavhijo;



        medicoFavoritoChildViewHolder.mBtnCancelarCita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("CANCELAR CITA para el medico>>>>>  " + IdProximaCita.toString());
               // Toast.makeText(medfavhijocopy.getContexto(), "PRUEBA CONTEXTO", Toast.LENGTH_LONG).show();
                    showDialog( medfavhijocopy.getContexto() , IdProximaCita,clone_mfcvw );

            }
        });

        medicoFavoritoChildViewHolder.mBtnGenerarCita.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                generarCita(medfavhijocopy.getContexto() , medfavhijocopy );
            }
        });


    }//Fin de  onBindChildViewHolder

    /*
    * este metodo invoca ala ventana de dialogo que confirma la cancelacion de la cita, el metodo
    * que cancela la cita tambien es invocado dentro
    * @param a          el contexto de en el que se encuentra la aplicacion
    * @param IDCita     el id de la cita que se quiere cancelar
    * @param mvh        el childviewholder del detalle de la cita que se quiere cancelar
    * */
    private void showDialog(final Context contexto, final Integer IDCita, final MedicoFavoritoChildViewHolder mvh)
    {
        final Dialog dialog = new Dialog(contexto);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.confirmar_cancelar_turno);

        Button dialogButtonSi = (Button) dialog.findViewById(R.id.btnCancelarSi);
        Button dialogButtonNo = (Button) dialog.findViewById(R.id.btnCancelarNo);

        dialogButtonSi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                try
                {
                    dialog.dismiss();
                    cancelCita(contexto,IDCita, mvh);
                }
                catch (JSONException | UnsupportedEncodingException e)
               {
                    e.getStackTrace();
               }
            }
        });

        dialogButtonNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
            }
        });

        dialog.show();
    }


    private void cancelCita(final Context contexto,Integer IDCita, final MedicoFavoritoChildViewHolder mvh ) throws JSONException , UnsupportedEncodingException
    {
         System.out.println("se cancelo la cita >>>>>>>>" + IDCita.toString());

        Autorizacion auth = new Autorizacion();
        Session sesion = new Session(contexto);

        HashMap<String, String> usuario = sesion.getDetalleUsuario();

        auth.setPatientID(Integer.valueOf(usuario.get(sesion.KEY_ID)));
        auth.setLoginPolicy(usuario.get(sesion.KEY_LOGINPOLICY));
        auth.setEml(usuario.get(sesion.KEY_EMAIL));
        auth.setPsswd(usuario.get(sesion.KEY_PASSWORD));

        JSONObject objAuth = new JSONObject();
        objAuth.put("patientID", auth.getPatientID());
        objAuth.put("loginPolicy", auth.getLoginPolicy());
        objAuth.put("eml", auth.getEml());

        if(auth.getLoginPolicy().equals("FB"))
            objAuth.put("facebooktoken", auth.getPsswd());
        else if(auth.getLoginPolicy().equals("G"))
            objAuth.put("googletoken", auth.getPsswd());
        else
            objAuth.put("psswd", auth.getPsswd());


        JSONObject obj = new JSONObject();
        obj.put("authorization", objAuth);
        obj.put("appointmentID", IDCita );
        obj.put("patientID", auth.getPatientID());

        RestClient.postJson(null, "/appointment/cancel", obj, new JsonHttpResponseHandler() {

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response)
            {
                //  "STATUS": "SUCCESS",
                //   "MSG_": "El turno ha sido cancelado exitosamente"
                //Extraigo la respuesrta
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsResId jsSimple = gson.fromJson(respuesta,  JsResId.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                if( jsSimple.getSTATUS().equals("SUCCESS"))
                {
                    mvh.mTVFechaTurno.setText("");
                    mvh.mTVHorario.setText("");
                    Toast.makeText(contexto, "Cita Cancelada", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(contexto, "Ocurrio un error, Intentelo más tarde", Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response)
            {
                String respuesta = response.toString();
                Gson gson = new Gson();

                JsResId jsSimple = gson.fromJson(respuesta,  JsResId.class);
                System.out.println("Recibio estatus de: " + jsSimple.getSTATUS());
                if( jsSimple.getSTATUS().equals("SUCCESS"))
                {
                    mvh.mTVFechaTurno.setText("");
                    mvh.mTVHorario.setText("");
                    Toast.makeText(contexto, "Cita Cancelada", Toast.LENGTH_LONG).show();
                }
                else {

                    Toast.makeText(contexto, "Ocurrio un error, Intentelo más tarde", Toast.LENGTH_LONG).show();
                }
            }

            //hacer acciones dependiendo del tipo de status
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

                String respString = responseString;
                System.out.println("Error>>>>>>>>>" + respString);
                Toast.makeText(contexto, "Ocurrio un error cancelando la cita, Intentelo más tarde", Toast.LENGTH_LONG).show();
            }
        });

    }


    private void generarCita(Context contexto,  MedicoFavoritoHijo mfh)
    {
        DatosGlobales var = DatosGlobales.getInstance();
        Intent intent = new Intent(contexto, BuscarHorarioActivity.class);

        var.setIdProvinciaSelecta(mfh.getIDprovincia());
        var.setIdCiudadSelecta(mfh.getIDciudad());
        var.setIdEspecialidad(mfh.getIDespecialidad());
        var.setIdCentroMedico(mfh.getIDhospital());
        var.setIdDoctor(mfh.getIDdoctor());

        //seteamos los nombre
        //TODO preguntale a Oscar si me puede hacer el favor
        var.setNombreCiudad("Ciudad");
        var.setNombreEspecialidad(mfh.getTVEspecialidad().getText().toString());
        var.setDireccionCentroMedico(mfh.getTVDireccion().getText().toString());
        var.setNombreDoctor(mfh.getNombreProfesional());
        var.setTelefonoCentroMedico(mfh.getTelefonoHospital());
        var.setNombreEspecialidad(mfh.getTVEspecialidad().getText().toString());
        var.setNombreCentroMedico(mfh.getTVHospital().getText().toString());

        // podemos pasar al bsucar Horario con los datos necesarios seteados
        contexto.startActivity(intent);

    }


}
