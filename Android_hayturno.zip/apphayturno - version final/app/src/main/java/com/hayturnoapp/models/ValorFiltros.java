package com.hayturnoapp.models;

public class ValorFiltros {

    private Integer llave;
    private String  valor;
    private String  valordir1;
    private String  valordir2;


    public ValorFiltros(Integer llave, String valor) {
        this.llave = llave;
        this.valor = valor;
        this.valordir1 = "";
        this.valordir2 = "";
    }

    public Integer getLlave() {
        return llave;
    }

    public void setLlave(Integer llave) {
        this.llave = llave;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getValordir1() {
        return valordir1;
    }

    public void setValordir1(String valordir1) {
        this.valordir1 = valordir1;
    }

    public String getValordir2() {
        return valordir2;
    }

    public void setValordir2(String valordir2) {
        this.valordir2 = valordir2;
    }
}
