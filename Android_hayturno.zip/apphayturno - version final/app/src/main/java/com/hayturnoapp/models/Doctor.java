package com.hayturnoapp.models;

/**
 * Created by Nicolas on 18/09/2016.
 */
public class Doctor {

    private Especialidad speciality;
    private Integer doctorId;  //me imagino que es el Id del doctor segun especialidad
    private InfoDoctor information;

    public Especialidad getSpeciality() {
        return speciality;
    }

    public void setSpeciality(Especialidad speciality) {
        this.speciality = speciality;
    }

    public Integer getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Integer doctorId) {
        this.doctorId = doctorId;
    }

    public InfoDoctor getInformation() {
        return information;
    }

    public void setInformation(InfoDoctor information) {
        this.information = information;
    }
}
